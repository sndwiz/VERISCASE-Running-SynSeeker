# VERICASE Email Intelligence Module — Drop-In Integration Guide

## What This Is
A drop-in email intelligence engine for your existing VERICASE app. It reads emails, extracts dates/context/emotion, detects upset/angry clients, auto-links to matters, tracks multi-matter clients, profiles psychological patterns, spots deception tactics, and immediately notifies Lauren (Admin) when something's wrong.

**Zero new dependencies required.** Uses your existing Express + Drizzle + PostgreSQL + React stack.

---

## Files To Copy

```
YOUR REPLIT PROJECT
├── shared/models/tables.ts          ← ADD table definitions from email-intel-tables.ts
├── shared/schema.ts                 ← ADD schemas from email-intel-schemas.ts  
├── server/services/email-intel-engine.ts  ← COPY (new file)
├── server/routes/email-intel.ts           ← COPY (new file)
├── server/routes/index.ts                 ← EDIT (2 lines)
├── client/src/components/email-intel-dashboard.tsx  ← COPY (new file)
└── client/src/App.tsx                     ← EDIT (add route + sidebar)
```

---

## Step 1: Database Tables

### Option A: Drizzle Push (Recommended)
Add the table definitions from `email-intel-tables.ts` to the **bottom** of your `shared/models/tables.ts` file, then run:

```bash
npm run db:push
```

### Option B: Raw SQL
Run `migration.sql` against your PostgreSQL database directly.

---

## Step 2: Add Table Definitions to shared/models/tables.ts

Open `shared/models/tables.ts` and add this at the **bottom** of the file (after the last table):

```typescript
// ============ EMAIL INTELLIGENCE ============

export const analyzedEmails = pgTable("analyzed_emails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subject: varchar("subject", { length: 500 }).notNull().default("(No Subject)"),
  sender: varchar("sender", { length: 500 }).notNull(),
  senderName: varchar("sender_name", { length: 255 }),
  senderDomain: varchar("sender_domain", { length: 255 }),
  recipients: jsonb("recipients").default([]),
  cc: jsonb("cc").default([]),
  direction: varchar("direction", { length: 20 }).default("inbound"),
  emailDate: timestamp("email_date"),
  bodyText: text("body_text").default(""),
  bodyPreview: varchar("body_preview", { length: 500 }).default(""),
  attachments: jsonb("attachments").default([]),
  threadId: varchar("thread_id", { length: 255 }),
  urgency: varchar("urgency", { length: 20 }).default("normal"),
  urgencyScore: integer("urgency_score").default(0),
  sentiment: varchar("sentiment", { length: 30 }).default("formal_neutral"),
  sentimentScores: jsonb("sentiment_scores").default({}),
  deceptionFlags: jsonb("deception_flags").default([]),
  deceptionScore: integer("deception_score").default(0),
  datesMentioned: jsonb("dates_mentioned").default([]),
  deadlines: jsonb("deadlines").default([]),
  caseNumbers: jsonb("case_numbers").default([]),
  moneyAmounts: jsonb("money_amounts").default([]),
  isLawyerComm: boolean("is_lawyer_comm").default(false),
  actionItems: jsonb("action_items").default([]),
  keyPhrases: jsonb("key_phrases").default([]),
  psychologicalProfile: jsonb("psychological_profile").default({}),
  riskLevel: varchar("risk_level", { length: 20 }).default("low"),
  matterId: varchar("matter_id"),
  clientId: varchar("client_id"),
  autoLinked: boolean("auto_linked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("IDX_analyzed_emails_matter_id").on(table.matterId),
  index("IDX_analyzed_emails_client_id").on(table.clientId),
  index("IDX_analyzed_emails_sender").on(table.sender),
  index("IDX_analyzed_emails_urgency").on(table.urgency),
  index("IDX_analyzed_emails_sentiment").on(table.sentiment),
  index("IDX_analyzed_emails_risk_level").on(table.riskLevel),
  index("IDX_analyzed_emails_email_date").on(table.emailDate),
]);

export type AnalyzedEmail = typeof analyzedEmails.$inferSelect;
export type InsertAnalyzedEmail = typeof analyzedEmails.$inferInsert;

export const adminAlerts = pgTable("admin_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  emailId: varchar("email_id").notNull(),
  alertType: varchar("alert_type", { length: 50 }).notNull(),
  priority: varchar("priority", { length: 20 }).notNull(),
  message: text("message").notNull(),
  triggers: jsonb("triggers").default([]),
  senderName: varchar("sender_name", { length: 255 }),
  senderEmail: varchar("sender_email", { length: 255 }),
  emailSubject: varchar("email_subject", { length: 500 }),
  matterId: varchar("matter_id"),
  acknowledged: boolean("acknowledged").default(false),
  acknowledgedBy: varchar("acknowledged_by", { length: 255 }),
  acknowledgedAt: timestamp("acknowledged_at"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("IDX_admin_alerts_email_id").on(table.emailId),
  index("IDX_admin_alerts_acknowledged").on(table.acknowledged),
  index("IDX_admin_alerts_priority").on(table.priority),
  index("IDX_admin_alerts_matter_id").on(table.matterId),
]);

export type AdminAlert = typeof adminAlerts.$inferSelect;
export type InsertAdminAlert = typeof adminAlerts.$inferInsert;

export const emailContacts = pgTable("email_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email", { length: 255 }).notNull().unique(),
  names: jsonb("names").default([]),
  domains: jsonb("domains").default([]),
  isLawyer: boolean("is_lawyer").default(false),
  totalEmails: integer("total_emails").default(0),
  matterIds: jsonb("matter_ids").default([]),
  clientId: varchar("client_id"),
  dominantSentiment: varchar("dominant_sentiment", { length: 30 }),
  avgDeceptionScore: real("avg_deception_score").default(0),
  alertCount: integer("alert_count").default(0),
  riskAssessment: varchar("risk_assessment", { length: 20 }).default("low"),
  behaviorTimeline: jsonb("behavior_timeline").default([]),
  firstSeen: timestamp("first_seen"),
  lastSeen: timestamp("last_seen"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  index("IDX_email_contacts_email").on(table.email),
  index("IDX_email_contacts_client_id").on(table.clientId),
  index("IDX_email_contacts_is_lawyer").on(table.isLawyer),
]);

export type EmailContact = typeof emailContacts.$inferSelect;
export type InsertEmailContact = typeof emailContacts.$inferInsert;
```

---

## Step 3: Copy Service File

Copy `server/services/email-intel-engine.ts` into your `server/services/` folder.

**No changes needed** — it's a pure analysis engine with zero imports from your codebase.

---

## Step 4: Copy Route File

Copy `server/routes/email-intel.ts` into your `server/routes/` folder.

**One import to verify** — the route file imports from your existing tables:
```typescript
import { analyzedEmails, adminAlerts, emailContacts } from "@shared/models/tables";
import { matters, clients } from "@shared/models/tables";
```
These should resolve correctly since you added the tables in Step 2.

---

## Step 5: Register Routes (2 Lines)

Open `server/routes/index.ts` and add:

```typescript
// At the top with other imports:
import { registerEmailIntelRoutes } from "./email-intel";

// Inside registerAllRoutes(), add at the bottom:
registerEmailIntelRoutes(app);
```

Your registerAllRoutes function should look like:
```typescript
export function registerAllRoutes(app: Express): void {
  // ... all your existing routes ...
  
  // Email Intelligence Module
  registerEmailIntelRoutes(app);
}
```

---

## Step 6: Add Frontend Component

Copy `client/src/components/email-intel-dashboard.tsx` into your components folder.

### Add to Sidebar Navigation
In `client/src/components/app-sidebar.tsx`, add the Email Intelligence nav item wherever your sidebar items are defined:

```tsx
{
  title: "Email Intelligence",
  icon: Brain, // from lucide-react
  url: "/email-intel",
}
```

### Add Route to App.tsx
In `client/src/App.tsx`, add:

```tsx
import EmailIntelDashboard from "@/components/email-intel-dashboard";

// Inside your router/switch:
<Route path="/email-intel" component={EmailIntelDashboard} />
```

(If using wouter, which your project does):
```tsx
<Route path="/email-intel">
  <EmailIntelDashboard />
</Route>
```

---

## Step 7: Push Database & Test

```bash
# Push new tables
npm run db:push

# Restart dev server
npm run dev
```

Then navigate to `/email-intel` in your app.

---

## API Endpoints Created

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/api/email-intel/analyze` | Analyze email (text or .eml upload) |
| GET | `/api/email-intel/emails` | List analyzed emails (filter: all/inbound/outbound/alerts) |
| GET | `/api/email-intel/emails/:id` | Email detail with full intelligence |
| POST | `/api/email-intel/emails/:id/link` | Manually link email to matter |
| GET | `/api/email-intel/alerts` | Lauren's alert feed |
| POST | `/api/email-intel/alerts/:id/acknowledge` | Acknowledge single alert |
| POST | `/api/email-intel/alerts/acknowledge-all` | Acknowledge all alerts |
| GET | `/api/email-intel/contacts` | Contact intelligence list |
| GET | `/api/email-intel/contacts/:email` | Contact detail + behavior timeline |
| GET | `/api/email-intel/dashboard` | Aggregate stats |
| GET | `/api/email-intel/timeline` | Chronological event timeline |
| GET | `/api/email-intel/matter/:matterId/emails` | All emails for a matter |
| GET | `/api/email-intel/search?q=` | Full-text email search |
| GET | `/api/email-intel/reference/utah-rules` | Utah filing deadlines |

---

## What It Does Automatically

### On Every Email Analyzed:
1. **Extracts**: case numbers, money amounts, dates, deadlines, action items, key legal phrases
2. **Scores**: urgency (0-10), sentiment (7 categories), deception (0-10 with 6 tactic types)
3. **Profiles**: communication style, power dynamics, emotional state, manipulation risk
4. **Links**: auto-matches to existing matters by case number, or to clients by email address
5. **Alerts Lauren**: immediately creates admin alerts for angry/upset clients, billing disputes, deadline risks, opposing counsel threats, or high manipulation scores
6. **Tracks contacts**: builds behavior timeline, detects multi-matter clients, assigns risk assessment

### Lauren Alert Triggers:
| Alert Type | Priority | Trigger |
|-----------|----------|---------|
| angry_client | CRITICAL | "furious", "fire you", "malpractice", "bar association", etc. (1 match) |
| upset_client | HIGH | "frustrated", "still waiting", "scared", "overwhelmed", etc. (2 matches) |
| billing_dispute | HIGH | "overcharged", "billing error", "refund", etc. (1 match) |
| deadline_risk | CRITICAL | "statute of limitations", "expires today", "missed deadline", etc. (1 match) |
| opposing_threat | HIGH | "sanctions", "contempt", "default judgment", etc. (1 match) |
| manipulation_detected | HIGH | Deception score ≥ 4/10 |

---

## Future Enhancements (Not Included Yet)
- **Gmail/IMAP auto-ingestion** — poll inbox automatically
- **Real AI analysis** — swap keyword engine for Claude/GPT API calls for deeper insights
- **Socket.io integration** — real-time alert push to Lauren's screen (your app already has socket.io)
- **Utah case law search** — connect to court API for real-time filing status
- **Board auto-creation** — auto-create Monday-style board items from email action items

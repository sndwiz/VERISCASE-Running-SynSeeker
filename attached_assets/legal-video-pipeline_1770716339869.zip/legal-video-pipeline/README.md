# Legal Video-to-Document Pipeline

**iPhone screen recording → Structured legal document in minutes. Fully offline. Air-gapped.**

Processes screen recordings of legal filings (scrolling through documents on an iPhone) into clean, searchable, entity-tagged documents. Zero cloud dependency — everything runs locally on dual RTX Pro 6000 GPUs.

---

## Pipeline Architecture

```
iPhone .mov → Validate → Extract Frames → Deduplicate → Preprocess
    → OCR (GPU 1) → Stitch (GPU 2) → Extract Entities → Output
```

### Stage Ordering (Best Practices)

| # | Stage | GPU | Rationale |
|---|-------|-----|-----------|
| 1 | **Validate** | CPU | Fail fast — catch bad files before any processing |
| 2 | **Extract Frames** | CPU | Pull frames at optimal adaptive FPS |
| 3 | **Deduplicate** | CPU | Remove 70-85% of frames (biggest efficiency win) |
| 4 | **Preprocess** | CPU | Clean images = 20-40% better OCR accuracy |
| 5 | **OCR** | GPU 1 | Vision model extracts text from each frame |
| 6 | **Stitch** | GPU 2 | LLM merges overlapping fragments into document |
| 7 | **Entities** | GPU 2 | Hybrid regex + LLM extracts structured metadata |
| 8 | **Output** | CPU | Generate PDF, DOCX, JSON, TXT + auto-file |

---

## Hardware Requirements

- **2x RTX Pro 6000** (96GB VRAM each, 192GB total)
- GPU 1: Qwen2.5-VL-72B (vision OCR) — ~75GB VRAM
- GPU 2: Qwen2.5-72B (text stitching + entities) — ~75GB VRAM
- **CPU**: Any modern multi-core (frame extraction is CPU-bound)
- **Storage**: ~10GB per recording processed (temp), outputs much smaller
- **RAM**: 64GB+ recommended

---

## Quick Start

### 1. Clone and install

```bash
git clone <repo-url>
cd legal-video-pipeline
pip install -r requirements.txt
```

### 2. Start model servers (Docker)

```bash
# Set your Hugging Face token
export HF_TOKEN=your_token_here

# Launch both GPU models + pipeline
docker-compose up -d
```

### 3. Process a recording

```bash
# Single file
python pipeline.py /path/to/recording.mov

# Watch folder (auto-process new recordings)
python pipeline.py --watch

# Validate only (dry run)
python pipeline.py recording.mov --dry-run

# Force reprocess (ignore cache)
python pipeline.py recording.mov --force
```

### 4. Output

Files are automatically organized by case number:

```
/output/documents/
  └── case_2-24-cv-01234/
      ├── recording_20240315_143000.txt      # Plain text
      ├── recording_20240315_143000.json     # Structured JSON + entities
      ├── recording_20240315_143000.docx     # Word document
      ├── recording_20240315_143000.pdf      # PDF
      └── recording_20240315_143000_confidence_report.json
```

---

## Key Features

### Checkpoint/Resume
Pipeline crashes mid-OCR? Just re-run — it picks up exactly where it left off. Content-addressable caching means identical files are never reprocessed.

### Confidence Gating
OCR results are scored for quality. Low-confidence frames automatically retry with different preprocessing strategies.

### Adaptive FPS
Short recordings → higher frame rate. Long recordings → lower. Maximizes content capture without wasting processing on redundant frames.

### Audit Trail
Every file processed, every stage executed, every output generated is logged with timestamps. Critical for legal chain-of-custody requirements.

### Entity Extraction
Automatically extracts: case numbers, party names, court, judge, filing dates, dollar amounts, statute citations, case citations, deadlines, and attorney names.

---

## Configuration

All settings in `config/settings.py`. Key tuning parameters:

```python
# Frame extraction
ExtractionConfig.fps = 2.0           # Base FPS (adaptive adjusts this)
ExtractionConfig.adaptive_fps = True  # Auto-adjust based on duration

# Deduplication
DeduplicationConfig.threshold = 12    # Lower = more aggressive dedup
DeduplicationConfig.hash_size = 16    # Higher = more sensitive

# Preprocessing
PreprocessConfig.contrast_factor = 1.5   # Boost for dim recordings
PreprocessConfig.crop_status_bar = True  # Remove iPhone UI

# OCR
OCRConfig.confidence_threshold = 0.7    # Min acceptable quality
OCRConfig.batch_size = 4               # Concurrent OCR requests
OCRConfig.max_retries = 2             # Retries on low confidence
```

---

## Without Docker (Direct vLLM)

```bash
# Terminal 1: OCR model on GPU 0
CUDA_VISIBLE_DEVICES=0 python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-VL-72B-Instruct \
    --gpu-memory-utilization 0.9 \
    --port 8001

# Terminal 2: Stitch model on GPU 1
CUDA_VISIBLE_DEVICES=1 python -m vllm.entrypoints.openai.api_server \
    --model Qwen/Qwen2.5-72B-Instruct \
    --gpu-memory-utilization 0.9 \
    --max-model-len 16384 \
    --port 8002

# Terminal 3: Run pipeline
python pipeline.py recording.mov
```

---

## Security

- **Air-gapped**: No internet required after model download
- **No cloud APIs**: Everything local
- **Attorney-client privilege**: Zero data leaves the machine
- **Auto-purge**: Temp frames deleted after successful processing
- **Audit logging**: Full chain-of-custody trail
- **Encrypted output**: Mount output folder on encrypted volume

---

## Performance

| Recording Length | Frames | Unique | Pipeline Time |
|-----------------|--------|--------|---------------|
| 30 seconds | ~60 | ~15 | ~1-2 min |
| 60 seconds | ~120 | ~25 | ~2-4 min |
| 120 seconds | ~240 | ~45 | ~4-7 min |
| 300 seconds | ~600 | ~80 | ~8-15 min |

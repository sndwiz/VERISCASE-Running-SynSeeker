"""
Pipeline Configuration
All tunable parameters in one place. Override via environment variables or config file.
"""
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class PathConfig:
    """File system paths"""
    intake_dir: Path = Path(os.getenv("INTAKE_DIR", "/intake/recordings"))
    output_dir: Path = Path(os.getenv("OUTPUT_DIR", "/output/documents"))
    temp_dir: Path = Path(os.getenv("TEMP_DIR", "/tmp/pipeline"))
    checkpoint_dir: Path = Path(os.getenv("CHECKPOINT_DIR", "/tmp/pipeline/checkpoints"))
    log_dir: Path = Path(os.getenv("LOG_DIR", "/var/log/legal-pipeline"))

    def ensure_dirs(self):
        for p in [self.intake_dir, self.output_dir, self.temp_dir,
                  self.checkpoint_dir, self.log_dir]:
            p.mkdir(parents=True, exist_ok=True)


@dataclass
class ExtractionConfig:
    """Frame extraction settings"""
    fps: float = 2.0                    # Frames per second to extract
    min_fps: float = 1.0                # Floor for adaptive FPS
    max_fps: float = 5.0                # Ceiling for adaptive FPS
    adaptive_fps: bool = True           # Auto-adjust based on scroll speed
    output_format: str = "png"          # png for OCR quality, jpg for speed
    quality: int = 2                    # FFmpeg quality (1=best, 31=worst)
    supported_formats: tuple = (".mov", ".mp4", ".m4v", ".avi", ".mkv")


@dataclass
class DeduplicationConfig:
    """Frame deduplication settings"""
    hash_algorithm: str = "phash"       # phash, ahash, dhash, whash
    hash_size: int = 16                 # Higher = more sensitive (default 8)
    threshold: int = 12                 # Hamming distance threshold
    min_unique_frames: int = 3          # Minimum frames to keep (safety net)
    detect_popups: bool = True          # Filter notification overlays
    detect_zoom: bool = True            # Handle pinch-to-zoom moments


@dataclass
class PreprocessConfig:
    """Image preprocessing before OCR"""
    enabled: bool = True
    grayscale: bool = True              # Convert to grayscale
    contrast_enhance: bool = True       # Auto contrast stretching
    contrast_factor: float = 1.5        # Contrast enhancement multiplier
    denoise: bool = True                # Remove noise
    denoise_strength: int = 10          # Denoising strength (higher = more)
    sharpen: bool = False               # Generally avoid for OCR per research
    deskew: bool = True                 # Correct slight rotation
    deskew_threshold: float = 0.5       # Min angle to trigger deskew (degrees)
    upscale: bool = False               # Upscale small images
    upscale_target_dpi: int = 300       # Target DPI if upscaling
    binarize: bool = False              # Adaptive binarization (use cautiously)
    crop_status_bar: bool = True        # Remove iPhone status bar area
    status_bar_height_pct: float = 0.06 # % of image height for status bar


@dataclass
class OCRConfig:
    """Vision model OCR settings"""
    model_endpoint: str = os.getenv("OCR_ENDPOINT", "http://localhost:8001/v1")
    model_name: str = os.getenv("OCR_MODEL", "Qwen/Qwen2.5-VL-72B-Instruct")
    max_tokens: int = 4096              # Max output tokens per frame
    temperature: float = 0.1            # Low temp for accuracy
    timeout: int = 60                   # Seconds per frame timeout
    max_retries: int = 2                # Retries on failure
    retry_with_alt_preprocess: bool = True  # Try different preprocessing on retry
    confidence_threshold: float = 0.7   # Minimum acceptable confidence
    batch_size: int = 4                 # Concurrent OCR requests
    system_prompt: str = """You are a legal document OCR specialist. Extract ALL text from this 
screenshot of a legal document exactly as it appears. 

PRESERVE:
- Exact paragraph structure and indentation
- Case citations (format: Party v. Party, Vol. Reporter Page (Court Year))
- Page numbers, headers, and footers
- Numbered lists and lettered sub-sections
- Bold, italic, or underlined formatting indicators
- Any stamps, signatures, or handwritten annotations (describe in [BRACKETS])

OUTPUT RULES:
- Use [PAGE HEADER] and [FOOTER] tags for headers/footers
- Use [HANDWRITTEN: description] for handwritten content
- Use [STAMP: description] for stamps or seals
- Use [UNCLEAR: best guess] for text you cannot read with confidence
- Preserve line breaks within paragraphs as they appear
- Do NOT add any commentary or interpretation"""


@dataclass
class StitchingConfig:
    """Text stitching LLM settings"""
    model_endpoint: str = os.getenv("STITCH_ENDPOINT", "http://localhost:8002/v1")
    model_name: str = os.getenv("STITCH_MODEL", "Qwen/Qwen2.5-72B-Instruct")
    max_tokens: int = 8192
    temperature: float = 0.1
    timeout: int = 120
    overlap_window: int = 3             # Number of fragments to overlap for context
    chunk_size: int = 5                 # Process N fragments at a time
    system_prompt: str = """You are reconstructing a legal document from overlapping OCR fragments 
extracted from a screen recording scroll. The fragments are in scroll order but have significant 
overlap between consecutive frames.

CRITICAL RULES:
1. MERGE overlapping content — do NOT duplicate paragraphs or sentences
2. PRESERVE exact legal language — do NOT paraphrase, summarize, or correct legal terms
3. MAINTAIN document structure (headings, numbered paragraphs, citations, indentation)
4. Flag gaps where content may be missing with [POSSIBLE GAP]
5. Flag any [UNCLEAR] tags from OCR — preserve them as-is
6. Remove any [PAGE HEADER] / [FOOTER] duplicates but note page transitions
7. Output clean, continuous document text

OVERLAP HANDLING:
- When you see the same text in consecutive fragments, keep ONE copy
- Use the version with higher apparent quality (more complete sentences)
- If fragments disagree on specific characters, flag as [OCR CONFLICT: version1 | version2]"""


@dataclass
class EntityConfig:
    """Entity extraction settings"""
    enabled: bool = True
    use_spacy: bool = True              # Fast pass with spaCy
    use_llm: bool = True                # Deep pass with LLM
    spacy_model: str = "en_core_web_trf"  # Transformer-based for accuracy
    entities: list = field(default_factory=lambda: [
        "case_number", "party_names", "court", "judge", "filing_date",
        "filing_type", "dollar_amounts", "statute_citations",
        "case_citations", "deadlines", "attorney_names", "bar_numbers"
    ])
    system_prompt: str = """Extract structured metadata from this legal document. 
Return ONLY valid JSON with the following fields (use null if not found):

{
    "case_number": "string or null",
    "court": "string or null",
    "judge": "string or null",
    "filing_date": "YYYY-MM-DD or null",
    "filing_type": "string (e.g., Motion to Dismiss, Complaint) or null",
    "parties": {
        "plaintiff": ["list of names"],
        "defendant": ["list of names"],
        "other": ["list of names with roles"]
    },
    "attorneys": [
        {"name": "string", "bar_number": "string or null", "firm": "string or null", "representing": "string"}
    ],
    "citations": {
        "case_citations": ["Party v. Party, Vol. Reporter Page (Court Year)"],
        "statute_citations": ["42 U.S.C. § 1983"]
    },
    "dollar_amounts": [{"amount": "string", "context": "brief description"}],
    "deadlines": [{"date": "YYYY-MM-DD or description", "action": "what is due"}],
    "key_dates": [{"date": "string", "event": "description"}]
}"""


@dataclass
class OutputConfig:
    """Output generation settings"""
    generate_pdf: bool = True
    generate_docx: bool = True
    generate_json: bool = True
    generate_txt: bool = True
    auto_file_by_case: bool = True      # Auto-organize into case folders
    include_confidence_report: bool = True
    include_source_frames: bool = False  # Attach original frames to output


@dataclass
class PipelineConfig:
    """Master configuration"""
    paths: PathConfig = field(default_factory=PathConfig)
    extraction: ExtractionConfig = field(default_factory=ExtractionConfig)
    dedup: DeduplicationConfig = field(default_factory=DeduplicationConfig)
    preprocess: PreprocessConfig = field(default_factory=PreprocessConfig)
    ocr: OCRConfig = field(default_factory=OCRConfig)
    stitching: StitchingConfig = field(default_factory=StitchingConfig)
    entities: EntityConfig = field(default_factory=EntityConfig)
    output: OutputConfig = field(default_factory=OutputConfig)

    # Pipeline behavior
    max_concurrent_files: int = 3       # Process up to N files simultaneously
    cleanup_temp_on_success: bool = True
    cleanup_temp_on_failure: bool = False  # Keep for debugging
    enable_checkpoints: bool = True
    audit_logging: bool = True

    def init(self):
        self.paths.ensure_dirs()
        return self

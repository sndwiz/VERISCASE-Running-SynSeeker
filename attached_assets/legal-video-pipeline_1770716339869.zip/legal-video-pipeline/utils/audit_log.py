"""
Audit Logger — Every file processed, every stage run, every output generated.
Critical for legal chain-of-custody requirements.
"""
import json
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class AuditLogger:
    """Structured audit logging for legal compliance"""

    def __init__(self, log_dir: Path, job_id: str):
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.job_id = job_id
        self.events = []

        # File logger
        self.logger = logging.getLogger(f"legal-pipeline.{job_id}")
        self.logger.setLevel(logging.DEBUG)

        # Audit log file (one per job)
        fh = logging.FileHandler(log_dir / f"{job_id}_audit.log")
        fh.setLevel(logging.DEBUG)
        fmt = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        fh.setFormatter(fmt)
        self.logger.addHandler(fh)

        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter("%(message)s"))
        self.logger.addHandler(ch)

    def log_event(self, event_type: str, stage: str, message: str,
                  data: Optional[dict] = None):
        """Log a structured audit event"""
        event = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "job_id": self.job_id,
            "event_type": event_type,
            "stage": stage,
            "message": message,
            "data": data or {}
        }
        self.events.append(event)

        level_map = {
            "start": logging.INFO,
            "complete": logging.INFO,
            "skip": logging.INFO,
            "warn": logging.WARNING,
            "error": logging.ERROR,
            "metric": logging.DEBUG,
        }
        level = level_map.get(event_type, logging.INFO)
        self.logger.log(level, f"[{stage}] {message}")

    def stage_start(self, stage: str, details: str = ""):
        self.log_event("start", stage, f"▶ Starting {stage}. {details}")

    def stage_complete(self, stage: str, duration: float, metrics: dict = None):
        self.log_event("complete", stage,
                       f"✅ Completed {stage} in {duration:.2f}s",
                       {"duration_seconds": duration, "metrics": metrics or {}})

    def stage_skip(self, stage: str, reason: str):
        self.log_event("skip", stage, f"⏭️  Skipping {stage}: {reason}")

    def stage_error(self, stage: str, error: str):
        self.log_event("error", stage, f"❌ Error in {stage}: {error}")

    def stage_warn(self, stage: str, warning: str):
        self.log_event("warn", stage, f"⚠️  {stage}: {warning}")

    def metric(self, stage: str, key: str, value):
        self.log_event("metric", stage, f"📊 {key}: {value}",
                       {"metric_key": key, "metric_value": value})

    def save_manifest(self):
        """Save complete audit trail as JSON"""
        manifest_path = self.log_dir / f"{self.job_id}_manifest.json"
        manifest_path.write_text(json.dumps(self.events, indent=2))
        return manifest_path

    def get_summary(self) -> dict:
        """Get pipeline execution summary"""
        stages = {}
        for event in self.events:
            stage = event["stage"]
            if stage not in stages:
                stages[stage] = {"status": "unknown"}
            if event["event_type"] == "complete":
                stages[stage] = {
                    "status": "success",
                    "duration": event["data"].get("duration_seconds", 0)
                }
            elif event["event_type"] == "error":
                stages[stage] = {"status": "failed", "error": event["message"]}
            elif event["event_type"] == "skip":
                stages[stage] = {"status": "skipped"}

        total_duration = sum(
            s.get("duration", 0) for s in stages.values()
        )
        return {
            "job_id": self.job_id,
            "stages": stages,
            "total_duration_seconds": round(total_duration, 2),
            "total_events": len(self.events)
        }

"""
Checkpoint System — Resume pipeline from where it left off on crash/restart.
Uses content-addressable storage so re-running on the same file skips completed stages.
"""
import json
import hashlib
import time
from pathlib import Path
from typing import Any, Optional
from dataclasses import dataclass, asdict


@dataclass
class StageResult:
    """Result of a pipeline stage execution"""
    stage: str
    status: str  # "success", "failed", "skipped"
    started_at: float
    completed_at: float
    duration_seconds: float
    input_hash: str
    output_path: Optional[str] = None
    output_data: Optional[dict] = None
    error: Optional[str] = None
    metrics: Optional[dict] = None


class CheckpointManager:
    """
    Content-addressable checkpointing.
    Each file gets a unique job ID based on its content hash.
    Each stage stores its results keyed by (job_id, stage_name).
    """

    def __init__(self, checkpoint_dir: Path):
        self.checkpoint_dir = checkpoint_dir
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def get_file_hash(self, file_path: Path) -> str:
        """Generate content hash for a file (first 10MB for speed on large videos)"""
        hasher = hashlib.sha256()
        chunk_size = 1024 * 1024  # 1MB chunks
        max_bytes = 10 * 1024 * 1024  # 10MB cap
        bytes_read = 0
        with open(file_path, "rb") as f:
            while bytes_read < max_bytes:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                hasher.update(chunk)
                bytes_read += len(chunk)
        # Also include file size for uniqueness
        hasher.update(str(file_path.stat().st_size).encode())
        return hasher.hexdigest()[:16]

    def get_job_dir(self, job_id: str) -> Path:
        """Get the checkpoint directory for a specific job"""
        job_dir = self.checkpoint_dir / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        return job_dir

    def stage_completed(self, job_id: str, stage: str) -> bool:
        """Check if a stage has already been completed for this job"""
        checkpoint_file = self.get_job_dir(job_id) / f"{stage}.json"
        if not checkpoint_file.exists():
            return False
        try:
            data = json.loads(checkpoint_file.read_text())
            return data.get("status") == "success"
        except (json.JSONDecodeError, KeyError):
            return False

    def get_stage_result(self, job_id: str, stage: str) -> Optional[StageResult]:
        """Retrieve cached result for a stage"""
        checkpoint_file = self.get_job_dir(job_id) / f"{stage}.json"
        if not checkpoint_file.exists():
            return None
        try:
            data = json.loads(checkpoint_file.read_text())
            return StageResult(**data)
        except (json.JSONDecodeError, TypeError):
            return None

    def save_stage_result(self, job_id: str, result: StageResult):
        """Save stage result to checkpoint"""
        checkpoint_file = self.get_job_dir(job_id) / f"{result.stage}.json"
        checkpoint_file.write_text(json.dumps(asdict(result), indent=2, default=str))

    def get_job_manifest(self, job_id: str) -> dict:
        """Get full status of all stages for a job"""
        job_dir = self.get_job_dir(job_id)
        manifest = {}
        for f in job_dir.glob("*.json"):
            stage = f.stem
            try:
                data = json.loads(f.read_text())
                manifest[stage] = {
                    "status": data.get("status"),
                    "duration": data.get("duration_seconds"),
                    "completed_at": data.get("completed_at")
                }
            except json.JSONDecodeError:
                manifest[stage] = {"status": "corrupted"}
        return manifest

    def clear_job(self, job_id: str):
        """Remove all checkpoints for a job"""
        import shutil
        job_dir = self.get_job_dir(job_id)
        if job_dir.exists():
            shutil.rmtree(job_dir)


def run_stage(checkpoint: CheckpointManager, job_id: str, stage_name: str,
              func, *args, **kwargs) -> StageResult:
    """
    Execute a pipeline stage with checkpoint support.
    Skips if already completed successfully.
    """
    # Check for existing successful result
    if checkpoint.stage_completed(job_id, stage_name):
        cached = checkpoint.get_stage_result(job_id, stage_name)
        if cached:
            print(f"  ⏭️  [{stage_name}] Skipping — already completed "
                  f"({cached.duration_seconds:.1f}s cached)")
            return cached

    # Execute the stage
    start_time = time.time()
    try:
        output = func(*args, **kwargs)
        end_time = time.time()

        result = StageResult(
            stage=stage_name,
            status="success",
            started_at=start_time,
            completed_at=end_time,
            duration_seconds=round(end_time - start_time, 2),
            input_hash=job_id,
            output_data=output if isinstance(output, dict) else None,
            output_path=str(output) if isinstance(output, (str, Path)) else None,
            metrics=output.get("metrics") if isinstance(output, dict) else None
        )
    except Exception as e:
        end_time = time.time()
        result = StageResult(
            stage=stage_name,
            status="failed",
            started_at=start_time,
            completed_at=end_time,
            duration_seconds=round(end_time - start_time, 2),
            input_hash=job_id,
            error=str(e)
        )

    # Save checkpoint
    checkpoint.save_stage_result(job_id, result)
    return result

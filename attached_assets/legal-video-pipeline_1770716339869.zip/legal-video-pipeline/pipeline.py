#!/usr/bin/env python3
"""
Legal Video-to-Document Pipeline — Main Orchestrator

Processes iPhone screen recordings of legal documents into structured,
searchable, entity-tagged documents. All processing runs locally on
dual RTX Pro 6000 GPUs. Zero cloud dependency.

Pipeline Order (with best-practice rationale):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 1. VALIDATE      → Fail fast. Don't waste GPU on bad input.
 2. EXTRACT       → CPU-only. Pull frames at optimal FPS.
 3. DEDUPLICATE   → Remove 70-85% of frames. Biggest efficiency win.
 4. PREPROCESS    → Clean images = 20-40% better OCR accuracy.
 5. OCR (GPU 1)   → Vision model extracts text from each frame.
 6. STITCH (GPU 2)→ LLM merges overlapping fragments into document.
 7. ENTITIES      → Hybrid regex+LLM extracts structured metadata.
 8. OUTPUT        → Generate PDF, DOCX, JSON, TXT + auto-file by case.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Usage:
    # Process single file
    python pipeline.py /path/to/recording.mov

    # Watch folder for new files
    python pipeline.py --watch

    # Reprocess (ignore checkpoints)
    python pipeline.py /path/to/recording.mov --force

    # Dry run (validate only)
    python pipeline.py /path/to/recording.mov --dry-run
"""
import argparse
import sys
import time
import shutil
from pathlib import Path

from config.settings import PipelineConfig
from utils.checkpoint import CheckpointManager, run_stage
from utils.audit_log import AuditLogger

from stages.s1_validate import validate_and_extract_metadata
from stages.s2_extract_frames import extract_frames
from stages.s3_deduplicate import deduplicate_frames
from stages.s4_preprocess import preprocess_frames
from stages.s5_ocr import ocr_frames
from stages.s6_stitch import stitch_fragments
from stages.s7_entities import extract_entities
from stages.s8_output import generate_outputs


def process_file(file_path: Path, config: PipelineConfig,
                  force: bool = False, dry_run: bool = False) -> dict:
    """
    Process a single video file through the complete pipeline.

    Returns dict with results, metrics, and output paths.
    """
    pipeline_start = time.time()
    config.init()

    # --- Initialize checkpoint and audit ---
    checkpoint = CheckpointManager(config.paths.checkpoint_dir)
    job_id = checkpoint.get_file_hash(file_path)

    if force:
        checkpoint.clear_job(job_id)

    logger = AuditLogger(config.paths.log_dir, job_id)
    logger.log_event("start", "pipeline",
                     f"Processing: {file_path.name} (job: {job_id})")

    # Job-specific temp directory
    job_temp = config.paths.temp_dir / job_id
    job_temp.mkdir(parents=True, exist_ok=True)

    all_metrics = {}
    warnings = []

    try:
        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 1: VALIDATION — Fail Fast                    ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("validate", f"Checking {file_path.name}")

        result = run_stage(
            checkpoint, job_id, "validate",
            validate_and_extract_metadata,
            file_path, config.extraction.supported_formats
        )

        if result.status == "failed":
            logger.stage_error("validate", result.error)
            return {"status": "failed", "stage": "validate", "error": result.error}

        validation = result.output_data
        if not validation["valid"]:
            errors = "; ".join(validation["errors"])
            logger.stage_error("validate", errors)
            return {"status": "failed", "stage": "validate", "error": errors}

        video_meta = validation["metadata"]
        warnings.extend(validation.get("warnings", []))
        all_metrics["validate"] = validation.get("metrics", {})
        logger.stage_complete("validate", result.duration_seconds, all_metrics["validate"])

        if dry_run:
            logger.log_event("complete", "pipeline", "Dry run — validation only")
            return {
                "status": "dry_run",
                "metadata": video_meta,
                "warnings": warnings,
                "job_id": job_id
            }

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 2: FRAME EXTRACTION — CPU Only               ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("extract", f"FPS target: {config.extraction.fps}")

        frames_dir = job_temp / "frames_raw"
        result = run_stage(
            checkpoint, job_id, "extract",
            extract_frames,
            file_path, frames_dir, config.extraction, video_meta
        )

        if result.status == "failed":
            logger.stage_error("extract", result.error)
            return {"status": "failed", "stage": "extract", "error": result.error}

        extraction = result.output_data
        all_metrics["extract"] = extraction.get("metrics", {})
        logger.stage_complete("extract", result.duration_seconds, all_metrics["extract"])
        logger.metric("extract", "frames_extracted", extraction["frame_count"])

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 3: DEDUPLICATION — Biggest Efficiency Win     ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("deduplicate", f"Input: {extraction['frame_count']} frames")

        result = run_stage(
            checkpoint, job_id, "deduplicate",
            deduplicate_frames,
            extraction["frame_paths"], config.dedup
        )

        if result.status == "failed":
            logger.stage_error("deduplicate", result.error)
            return {"status": "failed", "stage": "deduplicate", "error": result.error}

        dedup = result.output_data
        all_metrics["deduplicate"] = dedup.get("metrics", {})
        logger.stage_complete("deduplicate", result.duration_seconds, all_metrics["deduplicate"])
        logger.metric("deduplicate", "reduction",
                       f"{dedup['metrics']['reduction_percent']}%")

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 4: PREPROCESSING — Clean Images for OCR       ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("preprocess", f"Processing {dedup['unique_count']} frames")

        preprocessed_dir = job_temp / "frames_preprocessed"
        result = run_stage(
            checkpoint, job_id, "preprocess",
            preprocess_frames,
            dedup["unique_frames"], preprocessed_dir, config.preprocess
        )

        if result.status == "failed":
            logger.stage_error("preprocess", result.error)
            # Non-fatal: fall back to unpreprocessed frames
            logger.stage_warn("preprocess", "Falling back to raw frames")
            preprocessed_data = dedup["unique_frames"]
        else:
            preprocess_result = result.output_data
            preprocessed_data = preprocess_result["preprocessed_frames"]
            all_metrics["preprocess"] = preprocess_result.get("metrics", {})
            logger.stage_complete("preprocess", result.duration_seconds,
                                  all_metrics["preprocess"])

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 5: OCR — GPU 1 Vision Model                  ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("ocr", f"Processing {len(preprocessed_data)} frames on GPU 1")

        result = run_stage(
            checkpoint, job_id, "ocr",
            ocr_frames,
            preprocessed_data, config.ocr
        )

        if result.status == "failed":
            logger.stage_error("ocr", result.error)
            return {"status": "failed", "stage": "ocr", "error": result.error}

        ocr_result = result.output_data
        all_metrics["ocr"] = ocr_result.get("metrics", {})
        logger.stage_complete("ocr", result.duration_seconds, all_metrics["ocr"])
        logger.metric("ocr", "avg_confidence",
                       f"{ocr_result['metrics']['avg_confidence']:.3f}")

        if ocr_result["metrics"]["low_confidence_frames"] > 0:
            warnings.append(
                f"{ocr_result['metrics']['low_confidence_frames']} frames had "
                f"low OCR confidence"
            )

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 6: STITCHING — GPU 2 Text LLM                ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("stitch", f"Merging {ocr_result['fragment_count']} fragments")

        result = run_stage(
            checkpoint, job_id, "stitch",
            stitch_fragments,
            ocr_result["fragments"], config.stitching
        )

        if result.status == "failed":
            logger.stage_error("stitch", result.error)
            # Fallback: concatenate raw OCR
            logger.stage_warn("stitch", "Falling back to raw concatenation")
            document_text = "\n\n".join(
                f["text"] for f in ocr_result["fragments"] if f["text"]
            )
        else:
            stitch_result = result.output_data
            document_text = stitch_result["document_text"]
            all_metrics["stitch"] = stitch_result.get("metrics", {})
            logger.stage_complete("stitch", result.duration_seconds,
                                  all_metrics["stitch"])

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 7: ENTITY EXTRACTION — Hybrid Regex + LLM    ║
        # ╚══════════════════════════════════════════════════════╝
        entities = {}
        if config.entities.enabled:
            logger.stage_start("entities", "Extracting structured metadata")

            result = run_stage(
                checkpoint, job_id, "entities",
                extract_entities,
                document_text, config.entities
            )

            if result.status == "failed":
                logger.stage_warn("entities", f"Entity extraction failed: {result.error}")
            else:
                entity_result = result.output_data
                entities = entity_result.get("entities", {})
                all_metrics["entities"] = entity_result.get("metrics", {})
                logger.stage_complete("entities", result.duration_seconds,
                                      all_metrics["entities"])

        # ╔══════════════════════════════════════════════════════╗
        # ║  STAGE 8: OUTPUT GENERATION — Multi-format           ║
        # ╚══════════════════════════════════════════════════════╝
        logger.stage_start("output", "Generating output files")

        pipeline_metadata = {
            "source_file": file_path.name,
            "job_id": job_id,
            "metrics": all_metrics,
            "stage_metrics": all_metrics,
            "warnings": warnings,
            "total_duration": round(time.time() - pipeline_start, 2),
            "stages_completed": list(all_metrics.keys()),
        }

        result = run_stage(
            checkpoint, job_id, "output",
            generate_outputs,
            document_text, entities, pipeline_metadata,
            config.paths.output_dir, file_path.name, config.output
        )

        if result.status == "failed":
            logger.stage_error("output", result.error)
            return {"status": "failed", "stage": "output", "error": result.error}

        output_result = result.output_data
        all_metrics["output"] = output_result.get("metrics", {})
        logger.stage_complete("output", result.duration_seconds, all_metrics["output"])

        # ╔══════════════════════════════════════════════════════╗
        # ║  CLEANUP & SUMMARY                                   ║
        # ╚══════════════════════════════════════════════════════╝
        total_duration = round(time.time() - pipeline_start, 2)

        # Cleanup temp files
        if config.cleanup_temp_on_success:
            try:
                shutil.rmtree(job_temp)
            except Exception:
                pass

        # Save audit manifest
        manifest_path = logger.save_manifest()

        summary = {
            "status": "success",
            "job_id": job_id,
            "source_file": file_path.name,
            "total_duration_seconds": total_duration,
            "outputs": output_result.get("outputs", {}),
            "output_folder": output_result.get("output_folder"),
            "entities": entities,
            "metrics": all_metrics,
            "warnings": warnings,
            "audit_log": str(manifest_path),
        }

        logger.log_event("complete", "pipeline",
                         f"✅ Pipeline complete in {total_duration}s. "
                         f"Output: {output_result.get('output_folder')}")

        # Print summary
        print("\n" + "=" * 60)
        print(f"  ✅ PIPELINE COMPLETE — {file_path.name}")
        print(f"  ⏱  Total time: {total_duration}s")
        print(f"  📂 Output: {output_result.get('output_folder')}")
        print(f"  📊 Frames: {extraction['frame_count']} → "
              f"{dedup['unique_count']} unique → "
              f"{ocr_result['fragment_count']} OCR'd")
        print(f"  📝 Document: {len(document_text)} chars, "
              f"{len(document_text.split())} words")
        if entities.get("case_number"):
            print(f"  ⚖️  Case: {entities['case_number']}")
        if warnings:
            print(f"  ⚠️  Warnings: {len(warnings)}")
        print("=" * 60 + "\n")

        return summary

    except Exception as e:
        total_duration = round(time.time() - pipeline_start, 2)
        logger.stage_error("pipeline", str(e))
        logger.save_manifest()

        if not config.cleanup_temp_on_failure:
            print(f"  💾 Temp files preserved at: {job_temp}")

        return {
            "status": "failed",
            "job_id": job_id,
            "error": str(e),
            "total_duration_seconds": total_duration,
            "metrics": all_metrics,
        }


# ──────────────────────────────────────────────────────
# File Watcher Mode
# ──────────────────────────────────────────────────────

def watch_folder(config: PipelineConfig):
    """Watch intake folder for new recordings and process automatically"""
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        print("Install watchdog: pip install watchdog")
        sys.exit(1)

    class RecordingHandler(FileSystemEventHandler):
        def __init__(self):
            self.processing = set()

        def on_created(self, event):
            if event.is_directory:
                return
            path = Path(event.src_path)
            if path.suffix.lower() in config.extraction.supported_formats:
                if path.name not in self.processing:
                    self.processing.add(path.name)
                    print(f"\n🆕 New recording detected: {path.name}")
                    # Wait for file to finish writing
                    import time as t
                    t.sleep(2)
                    try:
                        process_file(path, config)
                    finally:
                        self.processing.discard(path.name)

    observer = Observer()
    handler = RecordingHandler()
    watch_path = str(config.paths.intake_dir)
    observer.schedule(handler, watch_path, recursive=False)
    observer.start()

    print(f"👁️  Watching {watch_path} for recordings...")
    print(f"   Supported: {config.extraction.supported_formats}")
    print(f"   Press Ctrl+C to stop\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("\n⏹️  Watcher stopped.")
    observer.join()


# ──────────────────────────────────────────────────────
# CLI Entry Point
# ──────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Legal Video-to-Document Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python pipeline.py recording.mov          # Process single file
  python pipeline.py --watch                # Watch folder mode
  python pipeline.py recording.mov --force  # Ignore cache, reprocess
  python pipeline.py recording.mov --dry-run  # Validate only
        """
    )
    parser.add_argument("file", nargs="?", help="Video file to process")
    parser.add_argument("--watch", action="store_true",
                        help="Watch intake folder for new recordings")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocessing (ignore checkpoints)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Validate only, don't process")
    parser.add_argument("--output-dir", type=str,
                        help="Override output directory")

    args = parser.parse_args()
    config = PipelineConfig()

    if args.output_dir:
        config.paths.output_dir = Path(args.output_dir)

    if args.watch:
        watch_folder(config)
    elif args.file:
        file_path = Path(args.file)
        result = process_file(file_path, config,
                               force=args.force, dry_run=args.dry_run)
        sys.exit(0 if result["status"] in ("success", "dry_run") else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

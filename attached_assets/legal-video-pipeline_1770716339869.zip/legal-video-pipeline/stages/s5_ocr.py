"""
Stage 5: VISION MODEL OCR (GPU 1)
Best Practice: Stream frames to GPU as they're ready, don't wait for batch.
Use confidence scoring to trigger retries with different preprocessing.
Progressive output — start stitching as OCR fragments arrive.

Order rationale: After preprocessing (clean images = better OCR).
Runs on GPU 1 while GPU 2 waits for stitching work.
"""
import asyncio
import base64
import json
import time
import re
from pathlib import Path
from typing import List, Optional, Tuple
from dataclasses import dataclass
import aiohttp

from config.settings import OCRConfig


@dataclass
class OCRFragment:
    """Result of OCR on a single frame"""
    frame_index: int
    frame_path: str
    text: str
    confidence: float  # 0.0 - 1.0
    processing_time: float
    retried: bool = False
    retry_count: int = 0
    warnings: list = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


def _estimate_confidence(text: str) -> float:
    """
    Heuristic confidence scoring for OCR output.

    Factors:
    - Text length (too short = probably missed content)
    - Ratio of recognizable words vs garbage
    - Presence of common legal patterns
    - Ratio of special characters to alphanumeric
    """
    if not text or len(text.strip()) < 10:
        return 0.1

    # Length score (expect at least 100 chars from a legal document frame)
    len_score = min(1.0, len(text) / 200)

    # Alphanumeric ratio (legal docs should be mostly text)
    alnum_count = sum(1 for c in text if c.isalnum() or c.isspace())
    alnum_ratio = alnum_count / len(text) if len(text) > 0 else 0
    alnum_score = min(1.0, alnum_ratio / 0.7)  # Expect ~70% alphanumeric

    # Legal pattern bonus
    legal_patterns = [
        r'\b\d+\s*U\.S\.C\.',           # USC citations
        r'\b[A-Z][a-z]+\s+v\.\s+',      # Case citations
        r'\bCourt\b',
        r'\bPlaintiff\b|\bDefendant\b',
        r'\bMotion\b|\bOrder\b|\bStipulation\b',
        r'\b\d{1,2}:\d{2}-[a-z]{2}-\d+',  # Case numbers
        r'\bHon\.\s',                     # Judge references
        r'\bESQ\b|\bEsq\.\b',           # Attorney
        r'\b§\s*\d+',                     # Section symbols
    ]
    legal_hits = sum(1 for p in legal_patterns if re.search(p, text, re.IGNORECASE))
    legal_score = min(1.0, legal_hits / 3)  # 3+ patterns = full bonus

    # Garbage character penalty
    garbage_chars = sum(1 for c in text if ord(c) > 0xFFFF or c in '□○●◆◇')
    garbage_ratio = garbage_chars / len(text) if len(text) > 0 else 0
    garbage_penalty = max(0, 1.0 - garbage_ratio * 10)

    # Weighted combination
    confidence = (
        len_score * 0.2 +
        alnum_score * 0.25 +
        legal_score * 0.25 +
        garbage_penalty * 0.3
    )

    return round(min(1.0, max(0.0, confidence)), 3)


def _encode_image(image_path: str) -> str:
    """Encode image to base64 for API call"""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


async def _ocr_single_frame(session: aiohttp.ClientSession,
                             frame_path: str,
                             frame_index: int,
                             config: OCRConfig) -> OCRFragment:
    """
    OCR a single frame via vision model API.
    Uses OpenAI-compatible API format (vLLM serves this).
    """
    start_time = time.time()
    image_b64 = _encode_image(frame_path)

    # Determine media type
    ext = Path(frame_path).suffix.lower()
    media_types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}
    media_type = media_types.get(ext, "image/png")

    payload = {
        "model": config.model_name,
        "messages": [
            {"role": "system", "content": config.system_prompt},
            {"role": "user", "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{media_type};base64,{image_b64}"
                    }
                },
                {
                    "type": "text",
                    "text": "Extract all text from this legal document screenshot."
                }
            ]}
        ],
        "max_tokens": config.max_tokens,
        "temperature": config.temperature,
    }

    try:
        async with session.post(
            f"{config.model_endpoint}/chat/completions",
            json=payload,
            timeout=aiohttp.ClientTimeout(total=config.timeout)
        ) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise RuntimeError(f"OCR API error {resp.status}: {error_text[:200]}")

            result = await resp.json()
            text = result["choices"][0]["message"]["content"]
            processing_time = time.time() - start_time

            confidence = _estimate_confidence(text)

            return OCRFragment(
                frame_index=frame_index,
                frame_path=frame_path,
                text=text,
                confidence=confidence,
                processing_time=round(processing_time, 2),
            )

    except asyncio.TimeoutError:
        return OCRFragment(
            frame_index=frame_index,
            frame_path=frame_path,
            text="",
            confidence=0.0,
            processing_time=time.time() - start_time,
            warnings=["OCR timed out"]
        )
    except Exception as e:
        return OCRFragment(
            frame_index=frame_index,
            frame_path=frame_path,
            text="",
            confidence=0.0,
            processing_time=time.time() - start_time,
            warnings=[f"OCR error: {str(e)}"]
        )


async def _ocr_with_retry(session: aiohttp.ClientSession,
                           frame_info: dict,
                           config: OCRConfig,
                           preprocess_config=None) -> OCRFragment:
    """
    OCR with confidence-gated retry.

    If confidence is below threshold on first try:
    1. Retry with original (unpreprocessed) image if available
    2. Retry with different prompt
    3. Accept best result across attempts
    """
    frame_path = frame_info["path"]
    frame_index = frame_info["index"]

    # First attempt
    result = await _ocr_single_frame(session, frame_path, frame_index, config)

    # Check confidence
    if result.confidence >= config.confidence_threshold:
        return result

    # --- Retry logic ---
    best_result = result
    retry_count = 0

    for attempt in range(config.max_retries):
        retry_count += 1

        # Strategy 1: Try original (unpreprocessed) image
        original_path = frame_info.get("original_path")
        if original_path and original_path != frame_path and attempt == 0:
            retry_result = await _ocr_single_frame(
                session, original_path, frame_index, config
            )
            if retry_result.confidence > best_result.confidence:
                best_result = retry_result
                best_result.retried = True
                best_result.retry_count = retry_count

            if best_result.confidence >= config.confidence_threshold:
                break

        # Strategy 2: Try with more explicit prompt
        if attempt == 1:
            enhanced_config = OCRConfig(
                model_endpoint=config.model_endpoint,
                model_name=config.model_name,
                max_tokens=config.max_tokens,
                temperature=0.0,  # Even lower temperature
                timeout=config.timeout,
                system_prompt=config.system_prompt + """

ADDITIONAL INSTRUCTIONS: This frame may contain partially visible text at the 
edges. Extract what you can see, even if sentences are cut off. Mark truncated 
text with [...] at the boundary."""
            )
            retry_result = await _ocr_single_frame(
                session, frame_path, frame_index, enhanced_config
            )
            if retry_result.confidence > best_result.confidence:
                best_result = retry_result
                best_result.retried = True
                best_result.retry_count = retry_count

    if best_result.confidence < config.confidence_threshold:
        best_result.warnings.append(
            f"Low confidence ({best_result.confidence:.2f}) after {retry_count} retries"
        )

    return best_result


async def ocr_frames_async(frame_data: List[dict], config: OCRConfig) -> dict:
    """
    Process all frames through OCR with concurrency control.

    Uses semaphore to limit concurrent requests to batch_size.
    Progressive: results available as each frame completes.
    """
    semaphore = asyncio.Semaphore(config.batch_size)
    fragments: List[OCRFragment] = []
    errors = []

    async def process_frame(frame_info):
        async with semaphore:
            return await _ocr_with_retry(session, frame_info, config)

    connector = aiohttp.TCPConnector(limit=config.batch_size + 2)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [process_frame(frame) for frame in frame_data]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, Exception):
                errors.append(str(result))
            elif isinstance(result, OCRFragment):
                fragments.append(result)

    # Sort by frame index to maintain document order
    fragments.sort(key=lambda f: f.frame_index)

    # Compute metrics
    total_time = sum(f.processing_time for f in fragments)
    avg_confidence = (sum(f.confidence for f in fragments) / len(fragments)
                      if fragments else 0)
    low_confidence = sum(1 for f in fragments
                         if f.confidence < config.confidence_threshold)
    retried = sum(1 for f in fragments if f.retried)

    return {
        "fragments": [
            {
                "frame_index": f.frame_index,
                "frame_path": f.frame_path,
                "text": f.text,
                "confidence": f.confidence,
                "processing_time": f.processing_time,
                "retried": f.retried,
                "warnings": f.warnings,
            }
            for f in fragments
        ],
        "fragment_count": len(fragments),
        "errors": errors,
        "metrics": {
            "frames_processed": len(fragments),
            "total_ocr_time_seconds": round(total_time, 2),
            "avg_time_per_frame": round(total_time / len(fragments), 2)
                                  if fragments else 0,
            "avg_confidence": round(avg_confidence, 3),
            "low_confidence_frames": low_confidence,
            "retried_frames": retried,
            "total_text_length": sum(len(f.text) for f in fragments),
            "error_count": len(errors),
        }
    }


def ocr_frames(frame_data: List[dict], config: OCRConfig) -> dict:
    """Synchronous wrapper for async OCR pipeline"""
    return asyncio.run(ocr_frames_async(frame_data, config))

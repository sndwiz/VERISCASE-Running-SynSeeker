"""
Stage 6: TEXT STITCHING (GPU 2)
Best Practice: Process fragments in overlapping chunks, not all at once.
LLMs have context limits — chunked processing with overlap windows
ensures continuity across chunk boundaries.

Order rationale: After OCR. Runs on GPU 2 while GPU 1 may still be
finishing OCR on remaining frames (pipeline parallelism).
"""
import asyncio
import json
import time
from typing import List
import aiohttp

from config.settings import StitchingConfig


def _chunk_fragments(fragments: List[dict], chunk_size: int = 5,
                     overlap: int = 1) -> List[List[dict]]:
    """
    Split fragments into overlapping chunks for processing.

    Example with chunk_size=5, overlap=1:
    Fragments: [0,1,2,3,4,5,6,7,8,9]
    Chunk 1: [0,1,2,3,4]
    Chunk 2: [4,5,6,7,8]  ← fragment 4 overlaps
    Chunk 3: [8,9]         ← fragment 8 overlaps

    The overlap ensures the LLM has context at chunk boundaries.
    """
    chunks = []
    i = 0
    while i < len(fragments):
        end = min(i + chunk_size, len(fragments))
        chunks.append(fragments[i:end])
        i += chunk_size - overlap
        if i >= len(fragments):
            break
    return chunks


async def _stitch_chunk(session: aiohttp.ClientSession,
                         chunk: List[dict],
                         chunk_index: int,
                         prev_tail: str,
                         config: StitchingConfig) -> dict:
    """
    Stitch a chunk of OCR fragments into continuous text.

    prev_tail: Last ~500 chars from previous chunk's output,
    used to maintain continuity across chunk boundaries.
    """
    # Build fragment text block
    fragment_texts = []
    for i, frag in enumerate(chunk):
        confidence_note = ""
        if frag["confidence"] < 0.7:
            confidence_note = f" [LOW CONFIDENCE: {frag['confidence']:.2f}]"
        fragment_texts.append(
            f"--- FRAGMENT {frag['frame_index']} {confidence_note} ---\n"
            f"{frag['text']}\n"
        )

    fragments_block = "\n".join(fragment_texts)

    # Add context from previous chunk
    context_block = ""
    if prev_tail:
        context_block = (
            f"CONTEXT (last portion of previously stitched text — "
            f"use for continuity, do NOT re-include this text):\n"
            f"...{prev_tail}\n\n"
        )

    user_message = f"""{context_block}FRAGMENTS TO MERGE:

{fragments_block}

Merge these fragments into clean, continuous text. Remove duplicates 
from scroll overlap. Preserve exact legal language."""

    payload = {
        "model": config.model_name,
        "messages": [
            {"role": "system", "content": config.system_prompt},
            {"role": "user", "content": user_message}
        ],
        "max_tokens": config.max_tokens,
        "temperature": config.temperature,
    }

    try:
        async with session.post(
            f"{config.model_endpoint}/chat/completions",
            json=payload,
            timeout=aiohttp.ClientTimeout(total=config.timeout)
        ) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                raise RuntimeError(f"Stitch API error {resp.status}: {error_text[:200]}")

            result = await resp.json()
            stitched_text = result["choices"][0]["message"]["content"]

            return {
                "chunk_index": chunk_index,
                "text": stitched_text,
                "fragment_indices": [f["frame_index"] for f in chunk],
                "success": True,
            }

    except Exception as e:
        # Fallback: concatenate raw fragments
        fallback_text = "\n\n".join(f["text"] for f in chunk)
        return {
            "chunk_index": chunk_index,
            "text": fallback_text,
            "fragment_indices": [f["frame_index"] for f in chunk],
            "success": False,
            "error": str(e),
        }


async def stitch_fragments_async(fragments: List[dict],
                                   config: StitchingConfig) -> dict:
    """
    Stitch all OCR fragments into a single continuous document.

    Process:
    1. Chunk fragments with overlap
    2. Process chunks sequentially (need previous chunk's tail for context)
    3. Merge chunk outputs
    4. Final cleanup pass
    """
    if not fragments:
        return {"document_text": "", "metrics": {"chunks": 0}}

    # If few fragments, process all at once
    if len(fragments) <= config.chunk_size:
        chunks = [fragments]
    else:
        chunks = _chunk_fragments(
            fragments,
            chunk_size=config.chunk_size,
            overlap=config.overlap_window
        )

    connector = aiohttp.TCPConnector(limit=2)
    async with aiohttp.ClientSession(connector=connector) as session:
        chunk_results = []
        prev_tail = ""

        for i, chunk in enumerate(chunks):
            result = await _stitch_chunk(session, chunk, i, prev_tail, config)
            chunk_results.append(result)

            # Extract tail for next chunk's context
            if result["text"]:
                prev_tail = result["text"][-500:]

    # --- Merge all chunks ---
    # Sequential chunks may have some overlap at boundaries
    # Do a simple merge — the LLM already handled dedup within chunks
    merged_parts = []
    for result in chunk_results:
        text = result["text"].strip()
        if text:
            merged_parts.append(text)

    # Join with clear separation (will be cleaned in final pass)
    raw_merged = "\n\n".join(merged_parts)

    # --- Final cleanup pass (optional) ---
    # For long documents, do one final LLM pass to clean up chunk boundaries
    if len(chunks) > 1 and len(raw_merged) < 30000:  # Under context limit
        try:
            final_result = await _final_cleanup(session, raw_merged, config)
            if final_result:
                raw_merged = final_result
        except Exception:
            pass  # Keep raw merged on failure

    success_count = sum(1 for r in chunk_results if r["success"])

    return {
        "document_text": raw_merged,
        "chunk_results": chunk_results,
        "metrics": {
            "total_chunks": len(chunks),
            "successful_chunks": success_count,
            "failed_chunks": len(chunks) - success_count,
            "document_length": len(raw_merged),
            "document_word_count": len(raw_merged.split()),
        }
    }


async def _final_cleanup(session, text: str, config: StitchingConfig) -> str:
    """Optional final pass to clean up chunk boundary artifacts"""
    payload = {
        "model": config.model_name,
        "messages": [
            {"role": "system", "content": (
                "You are cleaning up a reconstructed legal document. "
                "Fix any duplicate paragraphs at section boundaries. "
                "Do NOT change legal language. Do NOT summarize. "
                "Output the cleaned document only."
            )},
            {"role": "user", "content": f"Clean this document:\n\n{text}"}
        ],
        "max_tokens": config.max_tokens,
        "temperature": 0.0,
    }

    try:
        async with session.post(
            f"{config.model_endpoint}/chat/completions",
            json=payload,
            timeout=aiohttp.ClientTimeout(total=config.timeout)
        ) as resp:
            if resp.status == 200:
                result = await resp.json()
                return result["choices"][0]["message"]["content"]
    except Exception:
        pass
    return None


def stitch_fragments(fragments: List[dict], config: StitchingConfig) -> dict:
    """Synchronous wrapper"""
    return asyncio.run(stitch_fragments_async(fragments, config))

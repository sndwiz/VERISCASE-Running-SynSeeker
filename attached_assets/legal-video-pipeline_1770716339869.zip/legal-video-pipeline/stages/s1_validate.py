"""
Stage 1: INPUT VALIDATION
Best Practice: Fail fast. Catch bad inputs before wasting GPU cycles.

Order rationale: FIRST stage always. No point extracting frames from a corrupt
file or processing a 4-hour video that'll blow out temp storage.
"""
import subprocess
import json
from pathlib import Path
from dataclasses import dataclass
from typing import Optional


@dataclass
class VideoMetadata:
    """Extracted video metadata"""
    path: str
    filename: str
    format: str
    duration_seconds: float
    width: int
    height: int
    fps: float
    total_frames: int
    file_size_mb: float
    codec: str
    has_audio: bool
    rotation: int  # iPhone videos sometimes have rotation metadata


class ValidationError(Exception):
    """Raised when input fails validation"""
    pass


def validate_and_extract_metadata(file_path: Path, supported_formats: tuple,
                                   max_duration: int = 600,
                                   max_size_mb: int = 2000) -> dict:
    """
    Validate input file and extract metadata using FFprobe.

    Checks:
    1. File exists and is readable
    2. File extension is supported
    3. File is a valid video (not corrupt)
    4. Duration is within limits
    5. File size is within limits
    6. Resolution is adequate for OCR

    Returns dict with metadata and validation status.
    """
    errors = []
    warnings = []

    # --- Check 1: File exists ---
    if not file_path.exists():
        raise ValidationError(f"File not found: {file_path}")

    if not file_path.is_file():
        raise ValidationError(f"Not a file: {file_path}")

    # --- Check 2: Supported format ---
    if file_path.suffix.lower() not in supported_formats:
        raise ValidationError(
            f"Unsupported format: {file_path.suffix}. "
            f"Supported: {supported_formats}"
        )

    # --- Check 3: File size ---
    file_size_mb = file_path.stat().st_size / (1024 * 1024)
    if file_size_mb > max_size_mb:
        raise ValidationError(
            f"File too large: {file_size_mb:.1f}MB (max: {max_size_mb}MB)"
        )
    if file_size_mb < 0.01:
        raise ValidationError("File appears empty or corrupt (< 10KB)")

    # --- Check 4: FFprobe metadata extraction ---
    try:
        result = subprocess.run(
            [
                "ffprobe", "-v", "quiet",
                "-print_format", "json",
                "-show_format", "-show_streams",
                str(file_path)
            ],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode != 0:
            raise ValidationError(
                f"FFprobe failed — file may be corrupt: {result.stderr[:200]}"
            )

        probe_data = json.loads(result.stdout)
    except subprocess.TimeoutExpired:
        raise ValidationError("FFprobe timed out — file may be corrupt")
    except json.JSONDecodeError:
        raise ValidationError("FFprobe returned invalid data")

    # --- Parse video stream ---
    video_stream = None
    has_audio = False
    for stream in probe_data.get("streams", []):
        if stream.get("codec_type") == "video" and video_stream is None:
            video_stream = stream
        if stream.get("codec_type") == "audio":
            has_audio = True

    if not video_stream:
        raise ValidationError("No video stream found in file")

    # --- Extract dimensions ---
    width = int(video_stream.get("width", 0))
    height = int(video_stream.get("height", 0))

    # Handle iPhone rotation metadata
    rotation = 0
    side_data = video_stream.get("side_data_list", [])
    for sd in side_data:
        if "rotation" in sd:
            rotation = int(sd["rotation"])
    # Also check tags
    tags = video_stream.get("tags", {})
    if "rotate" in tags:
        rotation = int(tags["rotate"])

    # --- Duration ---
    duration = float(probe_data.get("format", {}).get("duration", 0))
    if duration == 0:
        # Try stream-level duration
        duration = float(video_stream.get("duration", 0))
    if duration == 0:
        raise ValidationError("Cannot determine video duration")

    if duration > max_duration:
        raise ValidationError(
            f"Video too long: {duration:.0f}s (max: {max_duration}s). "
            f"Split into shorter recordings."
        )

    # --- FPS ---
    fps_str = video_stream.get("r_frame_rate", "30/1")
    try:
        num, den = fps_str.split("/")
        fps = float(num) / float(den)
    except (ValueError, ZeroDivisionError):
        fps = 30.0
        warnings.append(f"Could not parse FPS '{fps_str}', defaulting to 30")

    total_frames = int(duration * fps)

    # --- Resolution quality check ---
    min_dimension = min(width, height)
    if min_dimension < 480:
        warnings.append(
            f"Low resolution ({width}x{height}). OCR quality may be poor."
        )
    if min_dimension < 240:
        errors.append(
            f"Resolution too low for reliable OCR: {width}x{height}"
        )

    # --- Codec ---
    codec = video_stream.get("codec_name", "unknown")

    # --- Build metadata ---
    metadata = VideoMetadata(
        path=str(file_path),
        filename=file_path.name,
        format=file_path.suffix.lower(),
        duration_seconds=round(duration, 2),
        width=width,
        height=height,
        fps=round(fps, 2),
        total_frames=total_frames,
        file_size_mb=round(file_size_mb, 2),
        codec=codec,
        has_audio=has_audio,
        rotation=rotation
    )

    return {
        "metadata": metadata.__dict__,
        "warnings": warnings,
        "errors": errors,
        "valid": len(errors) == 0,
        "metrics": {
            "duration_seconds": metadata.duration_seconds,
            "resolution": f"{width}x{height}",
            "file_size_mb": metadata.file_size_mb,
            "estimated_raw_frames": total_frames,
            "estimated_extracted_frames": int(duration * 2),  # at 2 FPS
        }
    }

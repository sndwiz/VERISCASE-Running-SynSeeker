"""
Stage 3: FRAME DEDUPLICATION & QUALITY FILTERING
Best Practice: Remove redundant frames BEFORE hitting the GPU.
This is the biggest efficiency gain in the entire pipeline.

Order rationale: After extraction, before preprocessing.
Dedup on raw frames — no point preprocessing frames we'll throw away.

Sub-stages (in order):
  3a. Remove blank/black frames
  3b. Remove blur frames (motion blur during fast scroll)
  3c. Perceptual hash deduplication
  3d. Popup/notification overlay detection
"""
import numpy as np
from pathlib import Path
from typing import List, Tuple
from PIL import Image
from config.settings import DeduplicationConfig


def _load_image(path: str) -> Image.Image:
    """Load image, handle EXIF rotation"""
    from PIL import ImageOps
    img = Image.open(path)
    img = ImageOps.exif_transpose(img)
    return img


def _is_blank_frame(img: Image.Image, threshold: float = 0.95) -> bool:
    """
    Detect blank/nearly blank frames (all white, all black, solid color).
    Returns True if >threshold of pixels are within narrow value range.
    """
    arr = np.array(img.convert("L"))  # Grayscale
    # Check if most pixels are the same value (± 10)
    median_val = np.median(arr)
    same_pixels = np.sum(np.abs(arr.astype(float) - median_val) < 10)
    ratio = same_pixels / arr.size
    return ratio > threshold


def _is_blurry(img: Image.Image, threshold: float = 50.0) -> bool:
    """
    Detect motion blur using Laplacian variance.
    Low variance = blurry. Threshold tuned for screen recordings.
    """
    try:
        import cv2
        arr = np.array(img.convert("L"))
        laplacian_var = cv2.Laplacian(arr, cv2.CV_64F).var()
        return laplacian_var < threshold
    except ImportError:
        # cv2 not available, skip blur detection
        return False


def _compute_phash(img: Image.Image, hash_size: int = 16) -> 'ImageHash':
    """Compute perceptual hash"""
    import imagehash
    return imagehash.phash(img, hash_size=hash_size)


def _detect_popup_overlay(img: Image.Image, prev_img: Image.Image = None) -> bool:
    """
    Detect popup overlays (notifications, alerts) that partially cover content.
    These frames should be marked but not necessarily removed — the underlying
    content may still be unique.

    Heuristic: If top ~15% of frame changes dramatically while bottom stays same,
    likely a notification banner.
    """
    if prev_img is None:
        return False

    arr_curr = np.array(img.convert("L"))
    arr_prev = np.array(prev_img.convert("L"))

    if arr_curr.shape != arr_prev.shape:
        return False

    h = arr_curr.shape[0]
    top_slice = int(h * 0.15)

    # Compare top region vs bottom region
    top_diff = np.mean(np.abs(arr_curr[:top_slice].astype(float) -
                               arr_prev[:top_slice].astype(float)))
    bot_diff = np.mean(np.abs(arr_curr[top_slice:].astype(float) -
                               arr_prev[top_slice:].astype(float)))

    # Notification: top changes a lot, bottom stays mostly same
    return top_diff > 30 and bot_diff < 10


def deduplicate_frames(frame_paths: List[str], config: DeduplicationConfig) -> dict:
    """
    Multi-pass deduplication pipeline:

    Pass 1: Remove blank frames (fast, no hashing needed)
    Pass 2: Remove blurry frames (fast, Laplacian check)
    Pass 3: Perceptual hash dedup (core dedup step)
    Pass 4: Flag popup overlays (keep frame but mark it)

    Returns dict with unique frame paths and metrics.
    """
    import imagehash

    hash_funcs = {
        "phash": imagehash.phash,
        "ahash": imagehash.average_hash,
        "dhash": imagehash.dhash,
        "whash": imagehash.whash,
    }
    hash_func = hash_funcs.get(config.hash_algorithm, imagehash.phash)

    total_input = len(frame_paths)
    blank_removed = 0
    blur_removed = 0
    dedup_removed = 0
    popup_flagged = 0

    # --- Pass 1: Remove blank frames ---
    non_blank = []
    for path in frame_paths:
        img = _load_image(path)
        if _is_blank_frame(img):
            blank_removed += 1
        else:
            non_blank.append(path)

    # --- Pass 2: Remove blurry frames ---
    non_blur = []
    for path in non_blank:
        img = _load_image(path)
        if _is_blurry(img):
            blur_removed += 1
        else:
            non_blur.append(path)

    # --- Pass 3: Perceptual hash deduplication ---
    unique_frames = []
    popup_frames = []
    prev_hash = None
    prev_img = None

    for path in non_blur:
        img = _load_image(path)
        h = hash_func(img, hash_size=config.hash_size)

        is_unique = True
        if prev_hash is not None:
            distance = h - prev_hash
            if distance < config.threshold:
                is_unique = False
                dedup_removed += 1

        if is_unique:
            # --- Pass 4: Popup detection ---
            has_popup = False
            if config.detect_popups and prev_img is not None:
                has_popup = _detect_popup_overlay(img, prev_img)
                if has_popup:
                    popup_flagged += 1
                    popup_frames.append(path)

            unique_frames.append({
                "path": path,
                "hash": str(h),
                "has_popup": has_popup,
                "index": len(unique_frames)
            })
            prev_hash = h
            prev_img = img

    # Safety net: ensure minimum frames
    if len(unique_frames) < config.min_unique_frames and len(non_blur) > 0:
        # Fall back to evenly spaced sampling
        step = max(1, len(non_blur) // config.min_unique_frames)
        unique_frames = []
        for i in range(0, len(non_blur), step):
            unique_frames.append({
                "path": non_blur[i],
                "hash": "fallback",
                "has_popup": False,
                "index": len(unique_frames)
            })

    unique_paths = [f["path"] for f in unique_frames]
    reduction_pct = round((1 - len(unique_frames) / total_input) * 100, 1) \
                    if total_input > 0 else 0

    return {
        "unique_frames": unique_frames,
        "unique_paths": unique_paths,
        "unique_count": len(unique_frames),
        "popup_frames": popup_frames,
        "metrics": {
            "input_frames": total_input,
            "blank_removed": blank_removed,
            "blur_removed": blur_removed,
            "dedup_removed": dedup_removed,
            "popup_flagged": popup_flagged,
            "unique_frames": len(unique_frames),
            "reduction_percent": reduction_pct,
        }
    }

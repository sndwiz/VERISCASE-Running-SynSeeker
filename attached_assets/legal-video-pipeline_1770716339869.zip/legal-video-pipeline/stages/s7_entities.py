"""
Stage 7: ENTITY EXTRACTION
Best Practice: Hybrid approach — fast regex/spaCy pass first,
then LLM pass for complex entities. Don't waste GPU on things
regex can catch in milliseconds.

Order rationale: After stitching (need complete document text).
Same GPU 2 since stitching is done.
"""
import re
import json
import asyncio
from typing import List, Optional
import aiohttp

from config.settings import EntityConfig


# ──────────────────────────────────────────────────────
# Fast Pass: Regex-based extraction (no GPU needed)
# ──────────────────────────────────────────────────────

LEGAL_PATTERNS = {
    "case_numbers": [
        # Federal: 2:24-cv-01234-ABC
        r'\b\d{1,2}:\d{2}-[a-z]{2}-\d{4,6}(?:-[A-Z]+)?\b',
        # State variations
        r'\b(?:No\.|Case\s+No\.?|Cause\s+No\.?)\s*(\d[\w-]+)',
    ],
    "dollar_amounts": [
        r'\$[\d,]+(?:\.\d{2})?',
        r'\b\d[\d,]+\.\d{2}\b(?=\s*(?:dollars|USD))',
    ],
    "dates": [
        # Various date formats
        r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b',
        r'\b\d{1,2}/\d{1,2}/\d{2,4}\b',
        r'\b\d{4}-\d{2}-\d{2}\b',
    ],
    "case_citations": [
        # Party v. Party, Vol. Reporter Page (Court Year)
        r'[A-Z][a-zA-Z\s\.]+\s+v\.\s+[A-Z][a-zA-Z\s\.]+,\s*\d+\s+\w+\.?\s*(?:\d+[a-z]*\.?\s*)?\d+\s*\(\w+\.?\s*\d{4}\)',
        # Simplified: Name v. Name
        r'[A-Z][a-z]+\s+v\.\s+[A-Z][a-z]+',
    ],
    "statute_citations": [
        r'\b\d+\s+U\.S\.C\.\s*§\s*\d+(?:\([a-z0-9]+\))*',
        r'\b\d+\s+C\.F\.R\.\s*§\s*\d+',
        r'§\s*\d+[\.\-\d]*',
    ],
    "bar_numbers": [
        r'\bBar\s*(?:No\.?|#)\s*(\d+)',
        r'\(Bar\s*#?\s*(\d+)\)',
    ],
}


def regex_extract(text: str) -> dict:
    """
    Fast regex-based entity extraction.
    Returns raw matches — LLM pass will validate and structure these.
    """
    results = {}
    for entity_type, patterns in LEGAL_PATTERNS.items():
        matches = []
        for pattern in patterns:
            found = re.findall(pattern, text, re.IGNORECASE)
            matches.extend(found)
        # Deduplicate
        results[entity_type] = list(set(m.strip() if isinstance(m, str) else m
                                        for m in matches))
    return results


# ──────────────────────────────────────────────────────
# Deep Pass: LLM-based extraction (GPU 2)
# ──────────────────────────────────────────────────────

async def llm_extract(text: str, config: EntityConfig,
                       regex_hints: dict = None) -> dict:
    """
    LLM-based structured entity extraction.

    Provides regex hints to the LLM so it can validate and enhance
    rather than finding everything from scratch.
    """
    # Truncate if too long for context
    max_chars = 20000
    if len(text) > max_chars:
        # Take first and last portions
        text = text[:max_chars//2] + "\n\n[...MIDDLE SECTION TRUNCATED...]\n\n" + text[-max_chars//2:]

    hint_block = ""
    if regex_hints:
        hint_block = (
            "\n\nPRE-EXTRACTED HINTS (validate and enhance these):\n"
            + json.dumps(regex_hints, indent=2)
        )

    payload = {
        "model": "Qwen/Qwen2.5-72B-Instruct",  # Text model on GPU 2
        "messages": [
            {"role": "system", "content": config.system_prompt},
            {"role": "user", "content": (
                f"Extract structured metadata from this legal document:"
                f"{hint_block}\n\n"
                f"DOCUMENT:\n{text}"
            )}
        ],
        "max_tokens": 4096,
        "temperature": 0.0,
    }

    stitch_endpoint = "http://localhost:8002/v1"  # GPU 2

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{stitch_endpoint}/chat/completions",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as resp:
                if resp.status != 200:
                    return {"error": f"Entity API error {resp.status}"}

                result = await resp.json()
                content = result["choices"][0]["message"]["content"]

                # Parse JSON from response (handle markdown code blocks)
                content = content.strip()
                if content.startswith("```json"):
                    content = content[7:]
                if content.startswith("```"):
                    content = content[3:]
                if content.endswith("```"):
                    content = content[:-3]

                return json.loads(content.strip())

    except json.JSONDecodeError:
        return {"error": "Failed to parse entity JSON", "raw": content[:500]}
    except Exception as e:
        return {"error": str(e)}


async def extract_entities_async(document_text: str,
                                   config: EntityConfig) -> dict:
    """
    Hybrid entity extraction pipeline:
    1. Fast regex pass (milliseconds)
    2. LLM deep pass with regex hints (seconds)
    3. Merge and validate
    """
    # --- Fast pass ---
    regex_results = regex_extract(document_text)

    # --- Deep pass ---
    llm_results = {}
    if config.use_llm:
        llm_results = await llm_extract(document_text, config, regex_results)

    # --- Merge ---
    # LLM results take priority (more structured), regex fills gaps
    merged = llm_results if not llm_results.get("error") else {}

    # Add any regex finds the LLM missed
    if not merged.get("citations"):
        merged["citations"] = {
            "case_citations": regex_results.get("case_citations", []),
            "statute_citations": regex_results.get("statute_citations", []),
        }

    if not merged.get("dollar_amounts") and regex_results.get("dollar_amounts"):
        merged["dollar_amounts"] = [
            {"amount": amt, "context": "extracted by pattern matching"}
            for amt in regex_results["dollar_amounts"]
        ]

    return {
        "entities": merged,
        "regex_results": regex_results,
        "llm_results": llm_results,
        "metrics": {
            "regex_entities_found": sum(len(v) for v in regex_results.values()),
            "llm_extraction_success": "error" not in llm_results,
            "entity_types_found": len([k for k, v in merged.items()
                                       if v and v != "null"]),
        }
    }


def extract_entities(document_text: str, config: EntityConfig) -> dict:
    """Synchronous wrapper"""
    return asyncio.run(extract_entities_async(document_text, config))

"""
Stage 2: FRAME EXTRACTION
Best Practice: Extract at minimum viable FPS, use parallel CPU cores,
zero-pad filenames for proper ordering, checkpoint frame count.

Order rationale: After validation, before any image processing.
This is a CPU-bound operation — no GPU needed yet.
"""
import subprocess
import os
from pathlib import Path
from typing import Optional
from config.settings import ExtractionConfig


def extract_frames(video_path: Path, output_dir: Path,
                   config: ExtractionConfig,
                   video_metadata: dict) -> dict:
    """
    Extract frames from video using FFmpeg.

    Best practices applied:
    - Adaptive FPS based on video characteristics
    - Zero-padded filenames for proper sorting
    - PNG format for OCR-quality preservation
    - Status bar cropping for iPhone recordings
    - Rotation correction for iPhone videos
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Determine optimal FPS ---
    target_fps = config.fps
    if config.adaptive_fps:
        duration = video_metadata.get("duration_seconds", 60)
        # Short recordings → higher FPS (might scroll fast)
        # Long recordings → lower FPS (probably slow scrolling)
        if duration < 15:
            target_fps = min(config.max_fps, 4.0)
        elif duration < 30:
            target_fps = 3.0
        elif duration < 60:
            target_fps = 2.0
        else:
            target_fps = max(config.min_fps, 1.5)

    # --- Build FFmpeg filter chain ---
    filters = []

    # Fix rotation (iPhone .mov files)
    rotation = video_metadata.get("rotation", 0)
    if rotation != 0:
        # FFmpeg auto-rotates by default with -autorotate, but be explicit
        pass  # FFmpeg handles this automatically in modern versions

    # FPS filter
    filters.append(f"fps={target_fps}")

    filter_chain = ",".join(filters) if filters else f"fps={target_fps}"

    # --- Output pattern ---
    output_pattern = str(output_dir / "frame_%06d.png")

    # --- Build FFmpeg command ---
    cmd = [
        "ffmpeg",
        "-i", str(video_path),
        "-vf", filter_chain,
        "-q:v", str(config.quality),
        "-vsync", "vfr",        # Variable frame rate — drop exact dupes
        "-y",                    # Overwrite existing
        output_pattern
    ]

    # --- Execute ---
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300  # 5 minute timeout
        )

        if result.returncode != 0:
            raise RuntimeError(
                f"FFmpeg extraction failed (code {result.returncode}): "
                f"{result.stderr[-500:]}"
            )
    except subprocess.TimeoutExpired:
        raise RuntimeError("FFmpeg extraction timed out (>5 minutes)")

    # --- Gather results ---
    frames = sorted(output_dir.glob("frame_*.png"))
    frame_count = len(frames)

    if frame_count == 0:
        raise RuntimeError("No frames extracted — check video file integrity")

    # Calculate total size
    total_size_mb = sum(f.stat().st_size for f in frames) / (1024 * 1024)

    return {
        "frame_dir": str(output_dir),
        "frame_count": frame_count,
        "frame_paths": [str(f) for f in frames],
        "target_fps": target_fps,
        "total_size_mb": round(total_size_mb, 2),
        "metrics": {
            "frames_extracted": frame_count,
            "extraction_fps": target_fps,
            "total_frames_size_mb": round(total_size_mb, 2),
            "avg_frame_size_kb": round(total_size_mb * 1024 / frame_count, 1)
                                 if frame_count > 0 else 0,
        }
    }

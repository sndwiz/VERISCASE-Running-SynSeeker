"""
Stage 4: IMAGE PREPROCESSING
Best Practice: Clean images BEFORE OCR = dramatically better text extraction.
Research shows preprocessing alone can improve OCR accuracy by 20-40%.

Order rationale: After dedup (don't preprocess frames we'll discard),
before OCR (feed the cleanest possible images to the vision model).

IMPORTANT: For screen recordings, we are NOT dealing with scanned paper.
We're dealing with digital text on a screen → different preprocessing needed:
- NO aggressive binarization (destroys anti-aliased text)
- YES contrast enhancement (screen glare, low brightness recordings)
- YES cropping (remove iPhone status bar, navigation bars)
- LIGHT denoising only (video compression artifacts, not paper noise)
"""
import numpy as np
from pathlib import Path
from typing import List
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
from config.settings import PreprocessConfig


def _crop_status_bar(img: Image.Image, height_pct: float = 0.06) -> Image.Image:
    """
    Remove iPhone status bar from top of frame.
    Also removes bottom navigation bar if present.
    """
    w, h = img.size
    top_crop = int(h * height_pct)
    bottom_crop = int(h * 0.04)  # Small bottom nav bar
    return img.crop((0, top_crop, w, h - bottom_crop))


def _enhance_contrast(img: Image.Image, factor: float = 1.5) -> Image.Image:
    """
    Enhance contrast for better text visibility.
    Useful for: dim screen recordings, low brightness settings, screen glare.
    """
    enhancer = ImageEnhance.Contrast(img)
    return enhancer.enhance(factor)


def _auto_contrast(img: Image.Image) -> Image.Image:
    """
    Auto-stretch contrast to use full dynamic range.
    Better than fixed factor for varying brightness across frames.
    """
    return ImageOps.autocontrast(img, cutoff=1)


def _denoise_light(img: Image.Image, strength: int = 10) -> Image.Image:
    """
    Light denoising for video compression artifacts.
    Uses median filter for salt-and-pepper noise from video compression.
    Do NOT use heavy denoising — it blurs text edges.
    """
    # Median filter: good for compression artifacts, preserves edges
    return img.filter(ImageFilter.MedianFilter(size=3))


def _denoise_cv2(img: Image.Image, strength: int = 10) -> Image.Image:
    """
    OpenCV-based denoising (better quality, requires cv2).
    fastNlMeansDenoisingColored is excellent for screen recording artifacts.
    """
    try:
        import cv2
        arr = np.array(img)
        if len(arr.shape) == 3:
            denoised = cv2.fastNlMeansDenoisingColored(arr, None, strength, strength, 7, 21)
        else:
            denoised = cv2.fastNlMeansDenoising(arr, None, strength, 7, 21)
        return Image.fromarray(denoised)
    except ImportError:
        return _denoise_light(img)


def _deskew(img: Image.Image, threshold: float = 0.5) -> Image.Image:
    """
    Correct slight rotation. Screen recordings shouldn't need this,
    but photos of screens definitely do.
    """
    try:
        import cv2
        arr = np.array(img.convert("L"))
        # Find edges
        edges = cv2.Canny(arr, 50, 150, apertureSize=3)
        # Detect lines
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100,
                                 minLineLength=100, maxLineGap=10)
        if lines is None:
            return img

        # Calculate median angle
        angles = []
        for line in lines:
            x1, y1, x2, y2 = line[0]
            angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
            if abs(angle) < 10:  # Only near-horizontal lines
                angles.append(angle)

        if not angles:
            return img

        median_angle = np.median(angles)
        if abs(median_angle) < threshold:
            return img  # Within tolerance

        # Rotate to correct
        return img.rotate(median_angle, resample=Image.BICUBIC,
                         expand=False, fillcolor=(255, 255, 255))
    except ImportError:
        return img


def preprocess_frame(img: Image.Image, config: PreprocessConfig,
                     is_retry: bool = False) -> Image.Image:
    """
    Apply preprocessing pipeline to a single frame.

    Pipeline order matters:
    1. Crop (remove UI elements) — reduces processing area
    2. Deskew (if needed) — correct rotation before enhancement
    3. Auto-contrast — normalize brightness
    4. Denoise — remove artifacts
    5. Grayscale (optional) — some OCR models prefer it

    On retry: use different/more aggressive settings.
    """
    # 1. Crop status bar
    if config.crop_status_bar:
        img = _crop_status_bar(img, config.status_bar_height_pct)

    # 2. Deskew
    if config.deskew:
        img = _deskew(img, config.deskew_threshold)

    # 3. Contrast enhancement
    if config.contrast_enhance:
        img = _auto_contrast(img)
        if is_retry:
            # More aggressive on retry
            img = _enhance_contrast(img, config.contrast_factor * 1.3)
        else:
            img = _enhance_contrast(img, config.contrast_factor)

    # 4. Denoise
    if config.denoise:
        strength = config.denoise_strength
        if is_retry:
            strength = int(strength * 0.5)  # Less denoising on retry (might be over-smoothing)
        img = _denoise_cv2(img, strength)

    # 5. Upscale if needed (for small/low-res recordings)
    if config.upscale:
        w, h = img.size
        if min(w, h) < 720:
            scale = 720 / min(w, h)
            new_size = (int(w * scale), int(h * scale))
            img = img.resize(new_size, Image.LANCZOS)

    # 6. Grayscale (optional — keep RGB for vision models by default)
    if config.grayscale:
        img = img.convert("L").convert("RGB")  # Convert back to RGB for model compatibility

    return img


def preprocess_frames(frame_data: List[dict], output_dir: Path,
                      config: PreprocessConfig) -> dict:
    """
    Preprocess all unique frames.

    Saves preprocessed versions to output_dir, preserving originals.
    Returns paths to preprocessed frames.
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    processed_frames = []
    skipped = 0
    errors = []

    for frame_info in frame_data:
        frame_path = Path(frame_info["path"])
        output_path = output_dir / f"preprocessed_{frame_path.name}"

        try:
            img = Image.open(frame_path)
            img = ImageOps.exif_transpose(img)

            processed = preprocess_frame(img, config)
            processed.save(output_path, "PNG", optimize=True)

            processed_frames.append({
                **frame_info,
                "original_path": frame_info["path"],
                "preprocessed_path": str(output_path),
                "path": str(output_path),  # Update path to preprocessed version
            })
        except Exception as e:
            errors.append({"path": str(frame_path), "error": str(e)})
            # Keep original on error
            processed_frames.append(frame_info)
            skipped += 1

    return {
        "preprocessed_frames": processed_frames,
        "preprocessed_count": len(processed_frames) - skipped,
        "skipped_count": skipped,
        "errors": errors,
        "metrics": {
            "preprocessed": len(processed_frames) - skipped,
            "skipped": skipped,
            "error_count": len(errors),
        }
    }

#!/bin/bash
# =============================================================================
# Legal Video-to-Document Pipeline — Startup Script
# =============================================================================
# Run this on the dual RTX Pro 6000 workstation to start everything.
#
# Prerequisites:
#   - Docker + Docker Compose v2
#   - NVIDIA Container Toolkit
#   - At least 192GB combined GPU VRAM
#
# Usage:
#   chmod +x start.sh
#   ./start.sh              # Start everything
#   ./start.sh --pull       # Pull latest images first
#   ./start.sh --no-gpu     # CPU-only mode (testing only)
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "============================================================"
echo "  Legal Video-to-Document Pipeline"
echo "  Dual RTX Pro 6000 | Air-Gapped Processing"
echo "============================================================"
echo ""

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------

echo -e "${YELLOW}Running pre-flight checks...${NC}"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}ERROR: Docker not found. Install Docker first.${NC}"
    exit 1
fi
echo -e "  ${GREEN}✓${NC} Docker installed"

# Check Docker Compose
if ! docker compose version &> /dev/null; then
    echo -e "${RED}ERROR: Docker Compose v2 not found.${NC}"
    exit 1
fi
echo -e "  ${GREEN}✓${NC} Docker Compose v2"

# Check NVIDIA runtime
if ! docker info 2>/dev/null | grep -q nvidia; then
    echo -e "${YELLOW}WARNING: NVIDIA runtime not detected in Docker.${NC}"
    echo "  Install NVIDIA Container Toolkit: https://docs.nvidia.com/datacenter/cloud-native/"
    if [[ "$1" != "--no-gpu" ]]; then
        exit 1
    fi
fi
echo -e "  ${GREEN}✓${NC} NVIDIA Container Toolkit"

# Check GPU availability
if command -v nvidia-smi &> /dev/null; then
    GPU_COUNT=$(nvidia-smi --query-gpu=count --format=csv,noheader | head -1)
    GPU_MEM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader | head -1)
    echo -e "  ${GREEN}✓${NC} ${GPU_COUNT} GPU(s) detected (${GPU_MEM} each)"
else
    echo -e "${YELLOW}  WARNING: nvidia-smi not found${NC}"
fi

# Check disk space (need at least 200GB for models)
AVAILABLE_GB=$(df -BG . | tail -1 | awk '{print $4}' | tr -d 'G')
if [[ $AVAILABLE_GB -lt 200 ]]; then
    echo -e "${YELLOW}WARNING: Only ${AVAILABLE_GB}GB disk space available.${NC}"
    echo "  Models require ~150GB. Consider freeing space."
fi
echo -e "  ${GREEN}✓${NC} ${AVAILABLE_GB}GB disk space available"

echo ""

# ---------------------------------------------------------------------------
# Create directories
# ---------------------------------------------------------------------------

echo "Creating directories..."
mkdir -p intake/recordings
mkdir -p output/documents
echo -e "  ${GREEN}✓${NC} intake/recordings/"
echo -e "  ${GREEN}✓${NC} output/documents/"
echo ""

# ---------------------------------------------------------------------------
# Pull images if requested
# ---------------------------------------------------------------------------

if [[ "$1" == "--pull" ]]; then
    echo "Pulling latest images..."
    docker compose pull
    echo ""
fi

# ---------------------------------------------------------------------------
# Start services
# ---------------------------------------------------------------------------

echo -e "${YELLOW}Starting services...${NC}"
echo "  This will download models on first run (~150GB total)."
echo "  First startup may take 30-60 minutes."
echo ""

docker compose up -d

echo ""
echo -e "${YELLOW}Waiting for models to load...${NC}"

# Wait for vLLM health checks
MAX_WAIT=600  # 10 minutes
WAITED=0

while [[ $WAITED -lt $MAX_WAIT ]]; do
    VISION_OK=$(docker inspect --format='{{.State.Health.Status}}' vllm-vision-ocr 2>/dev/null || echo "starting")
    TEXT_OK=$(docker inspect --format='{{.State.Health.Status}}' vllm-text-stitch 2>/dev/null || echo "starting")

    if [[ "$VISION_OK" == "healthy" && "$TEXT_OK" == "healthy" ]]; then
        break
    fi

    echo "  Vision: $VISION_OK | Text: $TEXT_OK (${WAITED}s elapsed)"
    sleep 15
    WAITED=$((WAITED + 15))
done

if [[ $WAITED -ge $MAX_WAIT ]]; then
    echo -e "${YELLOW}Models still loading. Check logs with:${NC}"
    echo "  docker compose logs -f vllm-vision"
    echo "  docker compose logs -f vllm-text"
else
    echo ""
    echo -e "${GREEN}============================================================${NC}"
    echo -e "${GREEN}  Pipeline is READY!${NC}"
    echo -e "${GREEN}============================================================${NC}"
    echo ""
    echo "  Drop .mov files into: $(pwd)/intake/recordings/"
    echo "  Find output in:       $(pwd)/output/documents/"
    echo ""
    echo "  Manual processing:"
    echo "    docker exec legal-pipeline python -m pipeline.orchestrator /intake/recordings/your_file.mov"
    echo ""
    echo "  View logs:"
    echo "    docker compose logs -f pipeline"
    echo ""
    echo "  Stop:"
    echo "    docker compose down"
fi

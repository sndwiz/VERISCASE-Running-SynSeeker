"""
STAGE 6: ENTITY EXTRACTION (GPU 2, ~10-15 seconds)
====================================================
ORDERING RATIONALE: Runs AFTER stitching because entity extraction needs
the complete, clean document. Extracting from raw fragments would produce
duplicate entities and miss cross-fragment context.

This stage is NON-CRITICAL: if it fails, we still have the full document.
Graceful degradation means the pipeline continues with empty entities.

Best practice: GRACEFUL DEGRADATION for non-critical enrichment stages.
"""

import json
import httpx

from pipeline.models import (
    PipelineJob, ExtractedEntity, Stage, StageStatus
)
from pipeline.utils import get_logger

log = get_logger("entities")


ENTITY_EXTRACTION_PROMPT = """You are a legal document analyst. Extract ALL
structured entities from the following legal document.

Return a JSON array where each object has:
- "entity_type": one of the types listed below
- "value": the exact text from the document
- "confidence": 0.0-1.0 (how certain you are)
- "context": the surrounding sentence for verification

ENTITY TYPES TO EXTRACT:
- case_number: Case/docket numbers (e.g., 2:24-cv-01234-ABC)
- party_names: Plaintiff, Defendant, Appellant, Appellee names
- court: Full court name (e.g., U.S. District Court, District of Utah)
- judge: Judge name with title (e.g., Hon. Jane Doe)
- filing_date: Any dates mentioned as filing/served dates
- filing_type: Document type (Motion, Memorandum, Order, etc.)
- dollar_amounts: Any monetary amounts mentioned
- statute_citations: Statutory references (e.g., 42 U.S.C. § 1983)
- case_citations: Case law citations (e.g., Smith v. Jones, 550 U.S. 398)
- deadlines: Response due dates, hearing dates, scheduling deadlines
- attorney_names: Attorney names with bar numbers if present

RULES:
1. Extract EVERY instance, even if the same entity appears multiple times
2. For party_names, specify role (Plaintiff, Defendant, etc.) in the value
3. For dollar_amounts, include the full context (what the amount is for)
4. Return ONLY valid JSON — no commentary, no markdown code fences
5. If no entities of a type are found, simply omit that type
6. When uncertain, set confidence < 0.5 rather than omitting"""


def extract_entities(job: PipelineJob, config: dict) -> PipelineJob:
    """
    Extract structured legal entities from the stitched document.
    Non-critical stage — fails gracefully.
    """
    job.mark_stage(Stage.ENTITIES, StageStatus.RUNNING)
    cfg = config.get("entities", {})

    api_base = cfg.get("api_base", "http://localhost:8002/v1")
    model = cfg.get("model", "Qwen/Qwen2.5-72B-Instruct")
    max_tokens = cfg.get("max_tokens", 4096)
    temperature = cfg.get("temperature", 0.0)
    timeout = cfg.get("timeout_seconds", 120)

    if not job.stitched_text:
        log.warning("No stitched text available — skipping entity extraction")
        job.mark_stage(Stage.ENTITIES, StageStatus.SKIPPED,
                       error="No stitched text")
        return job

    try:
        # If document is very long, process in sections
        text = job.stitched_text
        if len(text) > 30000:
            entities = _extract_chunked(
                text, api_base, model, max_tokens, temperature, timeout
            )
        else:
            entities = _extract_single(
                text, api_base, model, max_tokens, temperature, timeout
            )

        job.entities = entities

        # Log summary
        type_counts = {}
        for e in entities:
            type_counts[e.entity_type] = type_counts.get(e.entity_type, 0) + 1

        log.info(
            f"Extracted {len(entities)} entities: "
            f"{', '.join(f'{v} {k}' for k, v in type_counts.items())}"
        )

        job.mark_stage(Stage.ENTITIES, StageStatus.COMPLETED, metrics={
            "total_entities": len(entities),
            "entity_types": type_counts,
        })

    except Exception as e:
        log.error(f"Entity extraction failed: {e}")

        if config.get("pipeline", {}).get("graceful_degradation", True):
            log.warning("Continuing without entities (graceful degradation)")
            job.entities = []
            job.mark_stage(Stage.ENTITIES, StageStatus.COMPLETED, metrics={
                "fallback": True,
                "error": str(e),
            })
        else:
            job.mark_stage(Stage.ENTITIES, StageStatus.FAILED, error=str(e))

    return job


def _extract_single(
    text: str,
    api_base: str,
    model: str,
    max_tokens: int,
    temperature: float,
    timeout: int,
) -> list[ExtractedEntity]:
    """Extract entities from a document that fits in one LLM call."""

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": ENTITY_EXTRACTION_PROMPT},
            {"role": "user", "content": f"DOCUMENT:\n\n{text}"},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    with httpx.Client(timeout=timeout) as client:
        response = client.post(
            f"{api_base}/chat/completions",
            json=payload,
        )
        response.raise_for_status()
        data = response.json()

    raw_output = data["choices"][0]["message"]["content"]
    return _parse_entities(raw_output)


def _extract_chunked(
    text: str,
    api_base: str,
    model: str,
    max_tokens: int,
    temperature: float,
    timeout: int,
    chunk_chars: int = 25000,
) -> list[ExtractedEntity]:
    """Extract entities from a long document by processing in chunks."""
    all_entities = []
    overlap = 2000  # Overlap between chunks to catch cross-boundary entities

    for i in range(0, len(text), chunk_chars - overlap):
        chunk = text[i:i + chunk_chars]
        try:
            chunk_entities = _extract_single(
                chunk, api_base, model, max_tokens, temperature, timeout
            )
            all_entities.extend(chunk_entities)
        except Exception as e:
            log.warning(f"Entity extraction failed for chunk at pos {i}: {e}")

    # Deduplicate entities (same type + same value)
    seen = set()
    unique = []
    for e in all_entities:
        key = (e.entity_type, e.value)
        if key not in seen:
            seen.add(key)
            unique.append(e)

    return unique


def _parse_entities(raw_output: str) -> list[ExtractedEntity]:
    """Parse LLM JSON output into ExtractedEntity objects."""
    # Clean up common LLM output issues
    text = raw_output.strip()

    # Remove markdown code fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(lines[1:])  # Remove first line
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

    try:
        entities_data = json.loads(text)
    except json.JSONDecodeError:
        # Try to find JSON array in the output
        start = text.find("[")
        end = text.rfind("]") + 1
        if start >= 0 and end > start:
            try:
                entities_data = json.loads(text[start:end])
            except json.JSONDecodeError:
                log.error("Could not parse entity extraction output as JSON")
                return []
        else:
            log.error("No JSON array found in entity extraction output")
            return []

    entities = []
    for item in entities_data:
        if isinstance(item, dict) and "entity_type" in item and "value" in item:
            entities.append(ExtractedEntity(
                entity_type=item["entity_type"],
                value=item["value"],
                confidence=float(item.get("confidence", 1.0)),
                context=item.get("context", ""),
            ))

    return entities

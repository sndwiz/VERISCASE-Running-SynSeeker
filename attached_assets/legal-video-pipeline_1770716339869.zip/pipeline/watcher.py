"""
FILE WATCHER SERVICE
=====================
Monitors the intake folder for new .mov/.mp4 files and automatically
triggers the pipeline. Designed to run as a systemd service or in Docker.

Features:
- Debounced file detection (waits for file to finish writing)
- Duplicate detection (won't reprocess same file)
- Concurrent job limit
- Crash recovery on startup
"""

import time
import threading
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from pipeline.orchestrator import run_pipeline, recover_incomplete_jobs
from pipeline.utils import load_config, setup_logging, get_logger, file_hash

log = get_logger("watcher")


class VideoFileHandler(FileSystemEventHandler):
    """Handle new video files dropped into the watch directory."""

    def __init__(self, config: dict, config_path: str):
        self.config = config
        self.config_path = config_path
        self.processing = set()       # Currently processing files
        self.processed_hashes = set()  # Already processed (by hash)
        self.lock = threading.Lock()

        cfg = config.get("ingestion", {})
        self.supported = set(cfg.get("supported_formats", [".mov", ".mp4"]))
        self.debounce_seconds = 3  # Wait for file to finish writing

        max_concurrent = config.get("pipeline", {}).get("max_concurrent_jobs", 2)
        self.semaphore = threading.Semaphore(max_concurrent)

    def on_created(self, event):
        if event.is_directory:
            return
        self._handle_file(event.src_path)

    def on_moved(self, event):
        """Handle files moved/renamed into the watch directory."""
        if event.is_directory:
            return
        self._handle_file(event.dest_path)

    def _handle_file(self, filepath: str):
        path = Path(filepath)

        # Check extension
        if path.suffix.lower() not in self.supported:
            return

        # Ignore temp files
        if path.name.startswith(".") or path.name.endswith(".tmp"):
            return

        log.info(f"Detected new file: {path.name}")

        # Debounce — wait for file to finish writing
        threading.Thread(
            target=self._debounced_process,
            args=(filepath,),
            daemon=True,
        ).start()

    def _debounced_process(self, filepath: str):
        """Wait for file to stabilize, then process."""
        path = Path(filepath)

        # Wait for file size to stabilize (file still being written)
        prev_size = -1
        for _ in range(30):  # Max 30 * debounce_seconds wait
            time.sleep(self.debounce_seconds)
            if not path.exists():
                return  # File was removed
            current_size = path.stat().st_size
            if current_size == prev_size and current_size > 0:
                break  # File is stable
            prev_size = current_size
        else:
            log.warning(f"File {path.name} never stabilized — skipping")
            return

        # Check if already processing
        with self.lock:
            if filepath in self.processing:
                log.debug(f"Already processing: {path.name}")
                return
            self.processing.add(filepath)

        # Check for duplicate by hash
        try:
            fhash = file_hash(filepath)
            if fhash in self.processed_hashes:
                log.info(f"Duplicate file detected (same hash): {path.name}")
                with self.lock:
                    self.processing.discard(filepath)
                return
        except Exception:
            pass

        # Acquire semaphore (limits concurrent jobs)
        log.info(f"Queuing for processing: {path.name}")
        self.semaphore.acquire()

        try:
            log.info(f"Starting pipeline for: {path.name}")
            job = run_pipeline(
                source_file=filepath,
                config_path=self.config_path,
            )

            if job and job.output_paths:
                self.processed_hashes.add(fhash if fhash else "")
                log.info(f"Pipeline complete for: {path.name}")
            else:
                log.error(f"Pipeline failed for: {path.name}")

        except Exception as e:
            log.error(f"Pipeline error for {path.name}: {e}")

        finally:
            self.semaphore.release()
            with self.lock:
                self.processing.discard(filepath)


def start_watcher(config_path: str = "config.yaml"):
    """Start the file watcher service."""
    config = load_config(config_path)
    pipeline_cfg = config.get("pipeline", {})
    paths_cfg = config.get("paths", {})

    setup_logging(
        log_level=pipeline_cfg.get("log_level", "INFO"),
        log_dir=paths_cfg.get("log_dir"),
    )

    watch_dir = paths_cfg.get("watch_dir", "/intake/recordings")
    Path(watch_dir).mkdir(parents=True, exist_ok=True)

    log.info(f"{'='*60}")
    log.info(f"Legal Video Pipeline — File Watcher Service")
    log.info(f"{'='*60}")
    log.info(f"Watching: {watch_dir}")
    log.info(f"Max concurrent jobs: {pipeline_cfg.get('max_concurrent_jobs', 2)}")

    # Recover any incomplete jobs from previous crashes
    log.info("Checking for incomplete jobs from previous session...")
    recover_incomplete_jobs(config_path)

    # Process any existing files in the watch directory
    _process_existing_files(watch_dir, config, config_path)

    # Start watching for new files
    handler = VideoFileHandler(config, config_path)
    observer = Observer()
    observer.schedule(handler, watch_dir, recursive=False)
    observer.start()

    log.info(f"Watcher started. Waiting for files...")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        log.info("Shutting down watcher...")
        observer.stop()

    observer.join()
    log.info("Watcher stopped.")


def _process_existing_files(watch_dir: str, config: dict, config_path: str):
    """Process any files already in the watch directory on startup."""
    supported = set(
        config.get("ingestion", {}).get("supported_formats", [".mov", ".mp4"])
    )

    existing = []
    for ext in supported:
        existing.extend(Path(watch_dir).glob(f"*{ext}"))

    if existing:
        log.info(f"Found {len(existing)} existing files to process")
        for filepath in sorted(existing):
            log.info(f"  Processing existing: {filepath.name}")
            try:
                run_pipeline(
                    source_file=str(filepath),
                    config_path=config_path,
                )
            except Exception as e:
                log.error(f"Failed to process {filepath.name}: {e}")


if __name__ == "__main__":
    import sys
    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    start_watcher(config_path)

"""Shared utilities: logging, config, checkpoints."""

import json, yaml, hashlib, logging
from pathlib import Path
from datetime import datetime
from typing import Optional
from pipeline.models import PipelineJob, Stage

def load_config(config_path: str = "config.yaml") -> dict:
    with open(config_path, "r") as f:
        return yaml.safe_load(f)

def setup_logging(log_level: str = "INFO", log_dir: str = None):
    fmt = "[%(asctime)s] %(levelname)-8s %(name)s | %(message)s"
    handlers = [logging.StreamHandler()]
    if log_dir:
        p = Path(log_dir); p.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(p / f"pipeline_{datetime.now():%Y%m%d}.log"))
    logging.basicConfig(level=getattr(logging, log_level.upper(), logging.INFO),
                        format=fmt, handlers=handlers)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"legal-pipeline.{name}")

def save_checkpoint(job: PipelineJob, checkpoint_dir: str):
    cp_dir = Path(checkpoint_dir); cp_dir.mkdir(parents=True, exist_ok=True)
    tmp = cp_dir / f"{job.job_id}.json.tmp"
    final = cp_dir / f"{job.job_id}.json"
    with open(tmp, "w") as f:
        json.dump(job.to_checkpoint(), f, indent=2, default=str)
    tmp.rename(final)

def load_checkpoint(job_id: str, checkpoint_dir: str) -> Optional[PipelineJob]:
    cp = Path(checkpoint_dir) / f"{job_id}.json"
    if not cp.exists(): return None
    with open(cp, "r") as f:
        return PipelineJob.from_checkpoint(json.load(f))

def find_incomplete_jobs(checkpoint_dir: str) -> list:
    cp_dir = Path(checkpoint_dir)
    if not cp_dir.exists(): return []
    jobs = []
    for f in cp_dir.glob("*.json"):
        try:
            with open(f, "r") as fh:
                job = PipelineJob.from_checkpoint(json.load(fh))
            if job.current_stage != Stage.OUTPUT:
                jobs.append(job)
        except Exception: continue
    return jobs

def delete_checkpoint(job_id: str, checkpoint_dir: str):
    cp = Path(checkpoint_dir) / f"{job_id}.json"
    if cp.exists(): cp.unlink()

def file_hash(filepath: str, algorithm: str = "md5") -> str:
    h = hashlib.new(algorithm)
    with open(filepath, "rb") as f:
        while chunk := f.read(8192):
            h.update(chunk)
    return h.hexdigest()

def ensure_dirs(*dirs):
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)

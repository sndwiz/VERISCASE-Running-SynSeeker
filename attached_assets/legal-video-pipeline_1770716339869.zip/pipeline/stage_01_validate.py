"""STAGE 1: VALIDATION — Cheapest check, runs FIRST to fail fast."""

import subprocess, json
from pathlib import Path
from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import get_logger, file_hash

log = get_logger("validate")

def validate(job: PipelineJob, config: dict) -> PipelineJob:
    job.mark_stage(Stage.VALIDATE, StageStatus.RUNNING)
    cfg = config.get("ingestion", {})
    source = Path(job.source_file)
    try:
        if not source.exists():
            raise FileNotFoundError(f"File not found: {source}")
        supported = cfg.get("supported_formats", [".mov", ".mp4"])
        if source.suffix.lower() not in supported:
            raise ValueError(f"Unsupported format '{source.suffix}'")
        size_bytes = source.stat().st_size
        job.file_size_bytes = size_bytes
        if size_bytes < cfg.get("min_file_size_kb", 50) * 1024:
            raise ValueError(f"File too small ({size_bytes} bytes)")
        if size_bytes > cfg.get("max_file_size_gb", 10) * 1024 ** 3:
            raise ValueError(f"File too large")
        probe = _ffprobe(str(source))
        if not probe:
            raise ValueError("FFprobe failed — file may be corrupt")
        video_streams = [s for s in probe.get("streams", []) if s.get("codec_type") == "video"]
        if not video_streams:
            raise ValueError("No video stream found")
        vs = video_streams[0]
        job.resolution = (int(vs.get("width", 0)), int(vs.get("height", 0)))
        duration = float(probe.get("format", {}).get("duration", 0) or vs.get("duration", 0) or 0)
        job.duration_seconds = duration
        if duration < 0.5:
            raise ValueError(f"Video too short ({duration:.1f}s)")
        job.source_file_hash = file_hash(str(source))
        log.info(f"Validated: {source.name} | {job.resolution[0]}x{job.resolution[1]} | {duration:.1f}s")
        job.file_valid = True
        job.mark_stage(Stage.VALIDATE, StageStatus.COMPLETED, metrics={
            "file_size_mb": round(size_bytes / 1024 / 1024, 2),
            "duration_seconds": round(duration, 2),
        })
    except Exception as e:
        log.error(f"Validation failed: {e}")
        job.file_valid = False
        job.mark_stage(Stage.VALIDATE, StageStatus.FAILED, error=str(e))
    return job

def _ffprobe(filepath: str) -> dict | None:
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", filepath],
            capture_output=True, text=True, timeout=30)
        if result.returncode != 0: return None
        return json.loads(result.stdout)
    except Exception: return None

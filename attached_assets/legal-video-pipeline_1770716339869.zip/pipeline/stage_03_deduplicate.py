"""STAGE 3: DEDUPLICATION — Reduce data volume BEFORE hitting GPU."""

from pathlib import Path
from PIL import Image
import imagehash
from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import get_logger

log = get_logger("dedup")

HASH_ALGORITHMS = {
    "phash": imagehash.phash, "dhash": imagehash.dhash,
    "ahash": imagehash.average_hash, "whash": imagehash.whash,
}

def deduplicate_frames(job: PipelineJob, config: dict) -> PipelineJob:
    job.mark_stage(Stage.DEDUPLICATE, StageStatus.RUNNING)
    cfg = config.get("deduplication", {})
    algo_name = cfg.get("hash_algorithm", "phash")
    hash_size = cfg.get("hash_size", 16)
    threshold = cfg.get("hamming_threshold", 12)
    min_unique = cfg.get("min_unique_frames", 3)
    max_unique = cfg.get("max_unique_frames", 200)
    hash_func = HASH_ALGORITHMS.get(algo_name, imagehash.phash)

    frame_dir = Path(job.raw_frame_dir)
    frame_files = sorted(frame_dir.glob("*.*"))
    if not frame_files:
        job.mark_stage(Stage.DEDUPLICATE, StageStatus.FAILED, error="No frames found")
        return job

    try:
        unique_frames = []
        prev_hash = None
        skipped = 0

        for frame_path in frame_files:
            try:
                img = Image.open(frame_path)
                current_hash = hash_func(img, hash_size=hash_size)
                if prev_hash is None:
                    unique_frames.append(str(frame_path))
                    prev_hash = current_hash
                    continue
                if (current_hash - prev_hash) > threshold:
                    unique_frames.append(str(frame_path))
                    prev_hash = current_hash
                else:
                    skipped += 1
            except Exception as e:
                log.warning(f"Failed to hash {frame_path.name}: {e}")
                unique_frames.append(str(frame_path))

        last_frame = str(frame_files[-1])
        if last_frame not in unique_frames:
            unique_frames.append(last_frame)

        if len(unique_frames) > max_unique:
            unique_frames = unique_frames[:max_unique]

        job.unique_frame_paths = unique_frames
        job.unique_frame_count = len(unique_frames)
        reduction = (1 - len(unique_frames) / len(frame_files)) * 100

        log.info(f"Dedup: {len(frame_files)} -> {len(unique_frames)} frames ({reduction:.0f}% reduction)")
        job.mark_stage(Stage.DEDUPLICATE, StageStatus.COMPLETED, metrics={
            "input_frames": len(frame_files), "unique_frames": len(unique_frames),
            "duplicates_removed": skipped, "reduction_percent": round(reduction, 1),
        })
    except Exception as e:
        log.error(f"Deduplication failed: {e}")
        job.mark_stage(Stage.DEDUPLICATE, StageStatus.FAILED, error=str(e))
    return job

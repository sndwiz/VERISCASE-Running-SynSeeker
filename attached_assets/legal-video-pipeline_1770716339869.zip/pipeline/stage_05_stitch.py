"""
STAGE 5: TEXT STITCHING (GPU 2, ~15-30 seconds)
================================================
ORDERING RATIONALE: Runs on GPU 2 AFTER (or in parallel with) OCR on GPU 1.
Takes overlapping text fragments and merges them into one clean document.

In streaming mode, this CONSUMES fragments from OCR as they arrive,
accumulating chunks until it has enough to stitch a section.

Best practice: PRODUCER-CONSUMER pattern between GPUs.
"""

import httpx

from pipeline.models import PipelineJob, OCRFragment, Stage, StageStatus
from pipeline.utils import get_logger

log = get_logger("stitch")


# ---------------------------------------------------------------------------
# Prompt engineering for legal text stitching
# ---------------------------------------------------------------------------

STITCH_SYSTEM_PROMPT = """You are a legal document reconstruction specialist.
You receive overlapping text fragments extracted via OCR from a scrolling
screen recording of a legal document. Your job is to merge them into one
clean, continuous document.

RULES:
1. MERGE overlapping content — do NOT duplicate paragraphs or sentences
2. PRESERVE exact legal language — do NOT paraphrase, summarize, or correct
3. MAINTAIN document structure (headings, numbered paragraphs, citations)
4. If you detect a gap where content may be missing, insert [POSSIBLE GAP]
5. Preserve [HEADER], [FOOTER], [HANDWRITTEN], [REDACTED] tags from OCR
6. Output ONLY the reconstructed document — no commentary
7. When fragments overlap, keep the version with better text quality"""


def stitch_text(job: PipelineJob, config: dict) -> PipelineJob:
    """
    Merge OCR fragments into one continuous document.

    Strategy:
    - Process fragments in chunks (configurable chunk_size)
    - Each chunk stitches with accumulated result
    - Progressive merging handles long documents that exceed context window
    """
    job.mark_stage(Stage.STITCH, StageStatus.RUNNING)
    cfg = config.get("stitching", {})

    api_base = cfg.get("api_base", "http://localhost:8002/v1")
    model = cfg.get("model", "Qwen/Qwen2.5-72B-Instruct")
    max_tokens = cfg.get("max_tokens", 8192)
    temperature = cfg.get("temperature", 0.1)
    timeout = cfg.get("timeout_seconds", 180)
    chunk_size = cfg.get("chunk_size", 5)

    fragments = job.ocr_fragments

    if not fragments:
        job.mark_stage(Stage.STITCH, StageStatus.FAILED,
                       error="No OCR fragments to stitch")
        return job

    try:
        # Sort fragments by frame index to ensure order
        fragments = sorted(fragments, key=lambda f: f.frame_index)

        if len(fragments) == 1:
            # Single fragment — no stitching needed
            job.stitched_text = fragments[0].text
            log.info("Single fragment — no stitching needed")
            job.mark_stage(Stage.STITCH, StageStatus.COMPLETED, metrics={
                "fragments_input": 1,
                "stitch_passes": 0,
                "output_chars": len(job.stitched_text),
            })
            return job

        # Progressive stitching: merge in chunks
        accumulated_text = ""
        stitch_passes = 0

        for i in range(0, len(fragments), chunk_size):
            chunk = fragments[i:i + chunk_size]
            chunk_texts = [f.text for f in chunk]

            if not accumulated_text:
                # First chunk — just concatenate and ask LLM to merge
                merged = _stitch_chunk(
                    fragments=chunk_texts,
                    previous_text=None,
                    api_base=api_base,
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    timeout=timeout,
                )
            else:
                # Subsequent chunks — merge with accumulated text
                # Only send the TAIL of accumulated text for context overlap
                context_tail = _get_context_tail(accumulated_text, max_chars=2000)
                merged = _stitch_chunk(
                    fragments=chunk_texts,
                    previous_text=context_tail,
                    api_base=api_base,
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    timeout=timeout,
                )

            if merged:
                if accumulated_text:
                    # Append new content (LLM should have deduped the overlap)
                    accumulated_text = accumulated_text + "\n\n" + merged
                else:
                    accumulated_text = merged
                stitch_passes += 1

            log.info(
                f"Stitch pass {stitch_passes}: "
                f"processed fragments {i+1}-{min(i+chunk_size, len(fragments))}"
            )

        # Final cleanup pass — one more LLM call to clean up seams
        if stitch_passes > 1:
            log.info("Running final cleanup pass...")
            accumulated_text = _final_cleanup(
                text=accumulated_text,
                api_base=api_base,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                timeout=timeout,
            ) or accumulated_text

        job.stitched_text = accumulated_text.strip()

        log.info(
            f"Stitching complete: {len(fragments)} fragments → "
            f"{len(job.stitched_text)} chars"
        )

        job.mark_stage(Stage.STITCH, StageStatus.COMPLETED, metrics={
            "fragments_input": len(fragments),
            "stitch_passes": stitch_passes,
            "output_chars": len(job.stitched_text),
        })

    except Exception as e:
        log.error(f"Stitching failed: {e}")
        # Graceful degradation: concat raw fragments if stitching fails
        if config.get("pipeline", {}).get("graceful_degradation", True):
            log.warning("Falling back to raw concatenation")
            job.stitched_text = "\n\n---\n\n".join(
                f.text for f in fragments
            )
            job.mark_stage(Stage.STITCH, StageStatus.COMPLETED, metrics={
                "fallback": True,
                "error": str(e),
            })
        else:
            job.mark_stage(Stage.STITCH, StageStatus.FAILED, error=str(e))

    return job


# ---------------------------------------------------------------------------
# LLM calls
# ---------------------------------------------------------------------------

def _stitch_chunk(
    fragments: list[str],
    previous_text: str | None,
    api_base: str,
    model: str,
    max_tokens: int,
    temperature: float,
    timeout: int,
) -> str | None:
    """Send a chunk of fragments to the LLM for merging."""

    # Build the user prompt
    fragment_block = ""
    for i, text in enumerate(fragments):
        fragment_block += f"\n--- FRAGMENT {i + 1} ---\n{text}\n"

    if previous_text:
        user_prompt = (
            f"Here is the END of the document reconstructed so far:\n"
            f"--- PREVIOUS DOCUMENT TAIL ---\n{previous_text}\n"
            f"--- END PREVIOUS ---\n\n"
            f"Here are the next overlapping OCR fragments to merge. "
            f"They likely overlap with the tail above. "
            f"Output ONLY the NEW content that should be appended "
            f"(do not repeat the previous tail):\n"
            f"{fragment_block}"
        )
    else:
        user_prompt = (
            f"Here are overlapping OCR fragments from a scrolling screen "
            f"recording of a legal document. Merge them into one clean, "
            f"continuous document:\n{fragment_block}"
        )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": STITCH_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                f"{api_base}/chat/completions",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        log.error(f"Stitch LLM call failed: {e}")
        return None


def _final_cleanup(
    text: str,
    api_base: str,
    model: str,
    max_tokens: int,
    temperature: float,
    timeout: int,
) -> str | None:
    """Final pass to remove any remaining duplicated sections."""

    # If text is too long for one pass, just return as-is
    if len(text) > 50000:
        log.warning("Document too long for single cleanup pass, skipping")
        return text

    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a document editor. The following legal document "
                    "was reconstructed from OCR fragments. Check for and remove "
                    "any duplicated paragraphs or sentences that appear more "
                    "than once. Preserve ALL unique content exactly as-is. "
                    "Output the cleaned document only."
                ),
            },
            {"role": "user", "content": text},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                f"{api_base}/chat/completions",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
        return data["choices"][0]["message"]["content"]
    except Exception as e:
        log.error(f"Cleanup pass failed: {e}")
        return None


def _get_context_tail(text: str, max_chars: int = 2000) -> str:
    """Get the last N characters of text, breaking at paragraph boundary."""
    if len(text) <= max_chars:
        return text

    tail = text[-max_chars:]
    # Try to break at a paragraph boundary
    para_break = tail.find("\n\n")
    if para_break > 0 and para_break < max_chars // 2:
        tail = tail[para_break + 2:]
    return tail

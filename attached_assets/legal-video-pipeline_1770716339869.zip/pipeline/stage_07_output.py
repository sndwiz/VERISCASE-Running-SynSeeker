"""
STAGE 7: OUTPUT GENERATION (CPU-only)
======================================
ORDERING RATIONALE: Runs LAST — all heavy processing is done.
Generates final deliverables in multiple formats.

Uses ATOMIC WRITES: writes to temp file first, then renames to final
location. This prevents partial files from appearing in the output
directory if something crashes mid-write.

Best practice: ATOMIC OUTPUTS — never leave partial files in output dir.
"""

import json
import shutil
from pathlib import Path
from datetime import datetime

from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import get_logger, ensure_dirs

log = get_logger("output")


def generate_outputs(job: PipelineJob, config: dict) -> PipelineJob:
    """
    Generate final output files from the processed pipeline job.

    Outputs:
    - JSON: Structured data with full text + entities (for VERICASE/API)
    - Markdown: Clean readable document
    - PDF: Formatted legal document (if reportlab available)
    """
    job.mark_stage(Stage.OUTPUT, StageStatus.RUNNING)
    cfg = config.get("output", {})
    paths_cfg = config.get("paths", {})

    output_dir = paths_cfg.get("output_dir", "/output/documents")
    formats = cfg.get("formats", ["json", "markdown"])
    auto_file = cfg.get("auto_file_by_case", True)

    # Determine output subdirectory
    if auto_file and job.entities:
        case_num = _find_case_number(job)
        if case_num:
            sub_dir = _sanitize_dirname(case_num)
        else:
            sub_dir = job.job_id
    else:
        sub_dir = job.job_id

    job_output_dir = Path(output_dir) / sub_dir
    ensure_dirs(str(job_output_dir))

    generated = {}

    try:
        # ---- JSON Output ----
        if "json" in formats:
            json_path = _write_json(job, job_output_dir)
            if json_path:
                generated["json"] = str(json_path)
                log.info(f"Generated: {json_path}")

        # ---- Markdown Output ----
        if "markdown" in formats:
            md_path = _write_markdown(job, job_output_dir)
            if md_path:
                generated["markdown"] = str(md_path)
                log.info(f"Generated: {md_path}")

        # ---- PDF Output ----
        if "pdf" in formats:
            pdf_path = _write_pdf(job, job_output_dir)
            if pdf_path:
                generated["pdf"] = str(pdf_path)
                log.info(f"Generated: {pdf_path}")

        # ---- Pipeline Report ----
        report_path = _write_pipeline_report(job, job_output_dir)
        if report_path:
            generated["report"] = str(report_path)

        job.output_paths = generated

        log.info(
            f"Output complete: {len(generated)} files in {job_output_dir}"
        )

        job.mark_stage(Stage.OUTPUT, StageStatus.COMPLETED, metrics={
            "files_generated": len(generated),
            "output_directory": str(job_output_dir),
            "formats": list(generated.keys()),
        })

        # Cleanup temp files if configured
        if cfg.get("purge_temp_on_success", True):
            _cleanup_temp(job, config)

    except Exception as e:
        log.error(f"Output generation failed: {e}")
        job.mark_stage(Stage.OUTPUT, StageStatus.FAILED, error=str(e))

    return job


# ---------------------------------------------------------------------------
# Writers (all use atomic write pattern)
# ---------------------------------------------------------------------------

def _write_json(job: PipelineJob, output_dir: Path) -> Path | None:
    """Write structured JSON output — the primary machine-readable format."""
    try:
        data = {
            "metadata": {
                "job_id": job.job_id,
                "source_file": Path(job.source_file).name,
                "source_file_hash": job.source_file_hash,
                "processed_at": datetime.now().isoformat(),
                "duration_seconds": job.duration_seconds,
                "resolution": f"{job.resolution[0]}x{job.resolution[1]}",
                "frames_extracted": job.raw_frame_count,
                "frames_unique": job.unique_frame_count,
            },
            "document": {
                "full_text": job.stitched_text,
                "char_count": len(job.stitched_text),
                "word_count": len(job.stitched_text.split()),
            },
            "entities": [
                {
                    "type": e.entity_type,
                    "value": e.value,
                    "confidence": e.confidence,
                    "context": e.context,
                }
                for e in job.entities
            ],
            "entity_summary": _entity_summary(job),
        }

        return _atomic_write_json(
            data, output_dir / f"{job.job_id}.json"
        )

    except Exception as e:
        log.error(f"JSON output failed: {e}")
        return None


def _write_markdown(job: PipelineJob, output_dir: Path) -> Path | None:
    """Write clean Markdown document."""
    try:
        lines = []
        lines.append(f"# {_infer_document_title(job)}")
        lines.append("")
        lines.append(f"*Processed: {datetime.now():%Y-%m-%d %H:%M}*")
        lines.append(f"*Source: {Path(job.source_file).name}*")
        lines.append("")

        # Entity summary at top
        if job.entities:
            lines.append("## Document Information")
            lines.append("")

            summary = _entity_summary(job)
            for key, value in summary.items():
                if value:
                    label = key.replace("_", " ").title()
                    if isinstance(value, list):
                        lines.append(f"**{label}:** {', '.join(value)}")
                    else:
                        lines.append(f"**{label}:** {value}")

            lines.append("")
            lines.append("---")
            lines.append("")

        # Document body
        lines.append("## Document Text")
        lines.append("")
        lines.append(job.stitched_text)

        content = "\n".join(lines)

        return _atomic_write_text(
            content, output_dir / f"{job.job_id}.md"
        )

    except Exception as e:
        log.error(f"Markdown output failed: {e}")
        return None


def _write_pdf(job: PipelineJob, output_dir: Path) -> Path | None:
    """Write formatted PDF document."""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.units import inch
    except ImportError:
        log.warning("reportlab not installed — skipping PDF output")
        return None

    try:
        filepath = output_dir / f"{job.job_id}.pdf"
        tmp_path = filepath.with_suffix(".pdf.tmp")

        doc = SimpleDocTemplate(
            str(tmp_path),
            pagesize=letter,
            topMargin=1 * inch,
            bottomMargin=1 * inch,
        )

        styles = getSampleStyleSheet()
        body_style = ParagraphStyle(
            "LegalBody",
            parent=styles["Normal"],
            fontSize=11,
            leading=14,
            spaceAfter=6,
        )
        title_style = styles["Heading1"]

        story = []
        story.append(Paragraph(_infer_document_title(job), title_style))
        story.append(Spacer(1, 12))

        # Split text into paragraphs
        for para in job.stitched_text.split("\n\n"):
            para = para.strip()
            if para:
                # Escape special characters for reportlab
                safe_para = (
                    para
                    .replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                )
                story.append(Paragraph(safe_para, body_style))
                story.append(Spacer(1, 6))

        doc.build(story)

        # Atomic rename
        tmp_path.rename(filepath)
        return filepath

    except Exception as e:
        log.error(f"PDF output failed: {e}")
        return None


def _write_pipeline_report(job: PipelineJob, output_dir: Path) -> Path | None:
    """Write a processing report with timing and metrics."""
    try:
        report = {
            "job_id": job.job_id,
            "source_file": Path(job.source_file).name,
            "completed_at": datetime.now().isoformat(),
            "stages": {},
        }

        for stage_name, result in job.stage_results.items():
            stage_data = {
                "status": result.status.value,
                "metrics": result.metrics,
            }
            if result.started_at and result.completed_at:
                duration = (result.completed_at - result.started_at).total_seconds()
                stage_data["duration_seconds"] = round(duration, 2)
            if result.error:
                stage_data["error"] = result.error
            report["stages"][stage_name] = stage_data

        return _atomic_write_json(
            report, output_dir / f"{job.job_id}_report.json"
        )

    except Exception as e:
        log.error(f"Report generation failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _atomic_write_json(data: dict, filepath: Path) -> Path:
    """Write JSON atomically (temp file + rename)."""
    tmp_path = filepath.with_suffix(filepath.suffix + ".tmp")
    with open(tmp_path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    tmp_path.rename(filepath)
    return filepath


def _atomic_write_text(content: str, filepath: Path) -> Path:
    """Write text file atomically."""
    tmp_path = filepath.with_suffix(filepath.suffix + ".tmp")
    with open(tmp_path, "w") as f:
        f.write(content)
    tmp_path.rename(filepath)
    return filepath


def _entity_summary(job: PipelineJob) -> dict:
    """Build a summary dict from entities for quick reference."""
    summary = {}
    for e in job.entities:
        if e.entity_type not in summary:
            summary[e.entity_type] = e.value
        elif isinstance(summary[e.entity_type], list):
            summary[e.entity_type].append(e.value)
        else:
            summary[e.entity_type] = [summary[e.entity_type], e.value]
    return summary


def _find_case_number(job: PipelineJob) -> str | None:
    """Find the first case number entity for auto-filing."""
    for e in job.entities:
        if e.entity_type == "case_number":
            return e.value
    return None


def _infer_document_title(job: PipelineJob) -> str:
    """Generate a title from entities or fall back to filename."""
    parts = []

    for e in job.entities:
        if e.entity_type == "filing_type":
            parts.append(e.value)
            break

    for e in job.entities:
        if e.entity_type == "case_number":
            parts.append(f"({e.value})")
            break

    if parts:
        return " ".join(parts)
    return Path(job.source_file).stem


def _sanitize_dirname(name: str) -> str:
    """Make a string safe for use as a directory name."""
    # Replace common problematic chars in case numbers
    return (
        name
        .replace(":", "-")
        .replace("/", "-")
        .replace("\\", "-")
        .replace(" ", "_")
        .replace(".", "_")
    )


def _cleanup_temp(job: PipelineJob, config: dict):
    """Remove temporary files after successful output."""
    temp_dir = Path(config.get("paths", {}).get("temp_dir", "/tmp/legal-pipeline"))
    job_temp = temp_dir / job.job_id

    if job_temp.exists():
        try:
            shutil.rmtree(str(job_temp))
            log.info(f"Cleaned up temp directory: {job_temp}")
        except Exception as e:
            log.warning(f"Failed to cleanup temp: {e}")

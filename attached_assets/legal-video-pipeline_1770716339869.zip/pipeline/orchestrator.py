"""
PIPELINE ORCHESTRATOR
======================
Runs all 7 stages in the correct order with:
- Checkpoint/resume between every stage
- Graceful degradation for non-critical stages
- Detailed timing and metrics
- Crash recovery from last successful stage

STAGE EXECUTION ORDER (and why):
┌──────────────────────────────────────────────────────────────────┐
│ Stage │ Runs On │ Why This Order                                │
├──────────────────────────────────────────────────────────────────┤
│ 1. Validate    │ CPU     │ Cheapest check — fail fast            │
│ 2. Extract     │ CPU     │ Data prep — still cheap               │
│ 3. Deduplicate │ CPU     │ REDUCE data before GPU (critical!)    │
│ 4. OCR         │ GPU 1   │ First expensive stage — minimized by  │
│                │         │ dedup running first                   │
│ 5. Stitch      │ GPU 2   │ Needs OCR fragments — can stream      │
│ 6. Entities    │ GPU 2   │ Needs complete doc — non-critical      │
│ 7. Output      │ CPU     │ Final step — atomic writes             │
└──────────────────────────────────────────────────────────────────┘

KEY DESIGN DECISIONS:
- Stages 1-3 are CPU-only: cheap, fast, filter bad data early
- Stage 3 MUST run before Stage 4: saves 60-80% GPU time
- Stage 5 CAN run in parallel with Stage 4 (producer-consumer)
- Stage 6 is non-critical: fails gracefully
- Stage 7 uses atomic writes: no partial files in output
- Checkpoint after EVERY stage: crash at any point recovers cleanly
"""

import sys
import time
from pathlib import Path
from datetime import datetime

from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import (
    load_config, setup_logging, get_logger,
    save_checkpoint, load_checkpoint, delete_checkpoint,
    find_incomplete_jobs, ensure_dirs, file_hash,
)
from pipeline.stage_01_validate import validate
from pipeline.stage_02_extract import extract_frames
from pipeline.stage_03_deduplicate import deduplicate_frames
from pipeline.stage_04_ocr import run_ocr
from pipeline.stage_05_stitch import stitch_text
from pipeline.stage_06_entities import extract_entities
from pipeline.stage_07_output import generate_outputs

log = get_logger("orchestrator")


# Stage execution order — the heart of the pipeline
STAGE_PIPELINE = [
    (Stage.VALIDATE,    validate,           True),   # (stage, func, critical?)
    (Stage.EXTRACT,     extract_frames,     True),
    (Stage.DEDUPLICATE, deduplicate_frames, True),
    (Stage.OCR,         run_ocr,            True),
    (Stage.STITCH,      stitch_text,        True),
    (Stage.ENTITIES,    extract_entities,   False),  # Non-critical!
    (Stage.OUTPUT,      generate_outputs,   True),
]


def run_pipeline(
    source_file: str,
    config_path: str = "config.yaml",
    resume_job_id: str = None,
) -> PipelineJob:
    """
    Run the complete pipeline on a video file.

    Args:
        source_file: Path to .mov/.mp4 file
        config_path: Path to config.yaml
        resume_job_id: If set, resume from checkpoint instead of starting fresh

    Returns:
        Completed PipelineJob with all results
    """
    config = load_config(config_path)
    pipeline_cfg = config.get("pipeline", {})
    checkpoint_dir = config.get("paths", {}).get(
        "checkpoint_dir", "/tmp/legal-pipeline/checkpoints"
    )

    setup_logging(
        log_level=pipeline_cfg.get("log_level", "INFO"),
        log_dir=config.get("paths", {}).get("log_dir"),
    )

    ensure_dirs(checkpoint_dir)

    # ---- Resume or create new job ----
    if resume_job_id:
        job = load_checkpoint(resume_job_id, checkpoint_dir)
        if job:
            log.info(f"Resuming job {job.job_id} from stage {job.current_stage.value}")
        else:
            log.error(f"No checkpoint found for job {resume_job_id}")
            return None
    else:
        job = PipelineJob(source_file=source_file)
        log.info(f"Starting new job: {job.job_id}")
        log.info(f"Source: {source_file}")

    # ---- Determine starting stage (for resume) ----
    start_from = _get_resume_stage(job)
    started = False

    pipeline_start = time.time()

    # ---- Execute stages in order ----
    for stage, stage_func, is_critical in STAGE_PIPELINE:
        # Skip stages that completed in a previous run
        if not started:
            if stage == start_from:
                started = True
            else:
                continue

        job.current_stage = stage
        stage_name = stage.value
        log.info(f"{'='*60}")
        log.info(f"STAGE: {stage_name}")
        log.info(f"{'='*60}")

        stage_start = time.time()

        try:
            # Execute the stage
            job = stage_func(job, config)

            # Check result
            result = job.stage_results.get(stage_name)
            if result and result.status == StageStatus.FAILED:
                if is_critical:
                    log.error(f"CRITICAL stage {stage_name} failed: {result.error}")
                    log.error("Pipeline aborted.")
                    save_checkpoint(job, checkpoint_dir)
                    return job
                else:
                    log.warning(
                        f"Non-critical stage {stage_name} failed: {result.error}"
                    )
                    log.warning("Continuing with graceful degradation.")

        except Exception as e:
            log.error(f"Unhandled exception in {stage_name}: {e}")
            job.mark_stage(stage, StageStatus.FAILED, error=str(e))

            if is_critical:
                log.error("Pipeline aborted due to critical stage failure.")
                save_checkpoint(job, checkpoint_dir)
                return job

        stage_elapsed = time.time() - stage_start
        log.info(f"Stage {stage_name} completed in {stage_elapsed:.1f}s")

        # Checkpoint after every stage
        if pipeline_cfg.get("checkpoint_enabled", True):
            save_checkpoint(job, checkpoint_dir)
            log.debug(f"Checkpoint saved after {stage_name}")

    # ---- Pipeline complete ----
    total_elapsed = time.time() - pipeline_start

    log.info(f"{'='*60}")
    log.info(f"PIPELINE COMPLETE")
    log.info(f"{'='*60}")
    log.info(f"Job ID: {job.job_id}")
    log.info(f"Total time: {total_elapsed:.1f}s ({total_elapsed/60:.1f} min)")
    log.info(f"Output files: {list(job.output_paths.values())}")

    # Print stage timing summary
    log.info("")
    log.info("Stage Timing Summary:")
    for stage_name, result in job.stage_results.items():
        if result.started_at and result.completed_at:
            dur = (result.completed_at - result.started_at).total_seconds()
            status = result.status.value.upper()
            log.info(f"  {stage_name:<20s} {dur:>6.1f}s  [{status}]")

    # Cleanup checkpoint on success
    if pipeline_cfg.get("checkpoint_enabled", True):
        delete_checkpoint(job.job_id, checkpoint_dir)

    return job


def _get_resume_stage(job: PipelineJob) -> Stage:
    """Determine which stage to resume from based on checkpoint state."""
    # Find the last completed stage and resume from the next one
    completed_stages = []
    for stage, _, _ in STAGE_PIPELINE:
        result = job.stage_results.get(stage.value)
        if result and result.status == StageStatus.COMPLETED:
            completed_stages.append(stage)

    if not completed_stages:
        return Stage.VALIDATE  # Start from beginning

    # Find the next stage after the last completed one
    last_completed = completed_stages[-1]
    found = False
    for stage, _, _ in STAGE_PIPELINE:
        if found:
            return stage
        if stage == last_completed:
            found = True

    # All stages complete — re-run output
    return Stage.OUTPUT


def recover_incomplete_jobs(config_path: str = "config.yaml") -> list[PipelineJob]:
    """Find and resume any jobs that crashed mid-pipeline."""
    config = load_config(config_path)
    checkpoint_dir = config.get("paths", {}).get(
        "checkpoint_dir", "/tmp/legal-pipeline/checkpoints"
    )

    incomplete = find_incomplete_jobs(checkpoint_dir)
    if not incomplete:
        log.info("No incomplete jobs found.")
        return []

    log.info(f"Found {len(incomplete)} incomplete jobs:")
    results = []
    for job in incomplete:
        log.info(f"  Resuming: {job.job_id} (last stage: {job.current_stage.value})")
        completed = run_pipeline(
            source_file=job.source_file,
            config_path=config_path,
            resume_job_id=job.job_id,
        )
        if completed:
            results.append(completed)

    return results


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------

def main():
    """Command-line interface for the pipeline."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Legal Video-to-Document Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process a single recording
  python -m pipeline.orchestrator /intake/recordings/filing.mov

  # Resume a crashed job
  python -m pipeline.orchestrator --resume JOB_ID

  # Recover all incomplete jobs
  python -m pipeline.orchestrator --recover

  # Use custom config
  python -m pipeline.orchestrator --config custom.yaml recording.mov
        """,
    )

    parser.add_argument("source_file", nargs="?", help="Path to video file")
    parser.add_argument("--config", default="config.yaml", help="Config file path")
    parser.add_argument("--resume", metavar="JOB_ID", help="Resume a crashed job")
    parser.add_argument("--recover", action="store_true",
                        help="Recover all incomplete jobs")

    args = parser.parse_args()

    if args.recover:
        recover_incomplete_jobs(args.config)
    elif args.resume:
        run_pipeline(
            source_file="",  # Will be loaded from checkpoint
            config_path=args.config,
            resume_job_id=args.resume,
        )
    elif args.source_file:
        run_pipeline(
            source_file=args.source_file,
            config_path=args.config,
        )
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

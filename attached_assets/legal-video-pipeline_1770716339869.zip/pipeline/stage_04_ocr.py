"""STAGE 4: VISION OCR — GPU 1. Only runs AFTER dedup reduces frame count."""

import base64
import httpx
from pathlib import Path
from pipeline.models import PipelineJob, OCRFragment, Stage, StageStatus
from pipeline.utils import get_logger

log = get_logger("ocr")

LEGAL_OCR_SYSTEM_PROMPT = """You are a legal document OCR specialist. Extract ALL text from a screenshot exactly as it appears.
RULES: Reproduce text EXACTLY. Preserve paragraph breaks, legal citations, structure.
Mark headers with [HEADER], footers with [FOOTER], handwritten with [HANDWRITTEN], redacted with [REDACTED], truncated with [TRUNCATED].
Output ONLY extracted text."""

LEGAL_OCR_USER_PROMPT = "Extract ALL text from this legal document screenshot. Preserve exact formatting and citations."

def run_ocr(job: PipelineJob, config: dict) -> PipelineJob:
    job.mark_stage(Stage.OCR, StageStatus.RUNNING)
    cfg = config.get("ocr", {})
    api_base = cfg.get("api_base", "http://localhost:8001/v1")
    model = cfg.get("model", "Qwen/Qwen2.5-VL-72B-Instruct")
    max_tokens = cfg.get("max_tokens", 4096)
    temperature = cfg.get("temperature", 0.1)
    timeout = cfg.get("timeout_seconds", 120)
    retries = cfg.get("retry_attempts", 3)

    fragments, failed = [], []
    for idx, frame_path in enumerate(job.unique_frame_paths):
        log.info(f"OCR frame {idx+1}/{job.unique_frame_count}: {Path(frame_path).name}")
        for attempt in range(retries):
            try:
                text = _ocr_single_frame(frame_path, api_base, model, max_tokens, temperature, timeout)
                if text and text.strip():
                    fragments.append(OCRFragment(frame_index=idx, frame_path=frame_path, text=text.strip()))
                    break
            except Exception as e:
                log.warning(f"OCR attempt {attempt+1}/{retries} failed for frame {idx}: {e}")
                if attempt < retries - 1:
                    import time; time.sleep(cfg.get("retry_delay_seconds", 5))
        else:
            failed.append(frame_path)

    job.ocr_fragments = fragments
    log.info(f"OCR complete: {len(fragments)}/{job.unique_frame_count} frames ({len(failed)} failures)")
    if not fragments:
        job.mark_stage(Stage.OCR, StageStatus.FAILED, error="No frames OCR'd successfully")
    else:
        job.mark_stage(Stage.OCR, StageStatus.COMPLETED, metrics={
            "frames_processed": len(fragments), "frames_failed": len(failed),
            "total_text_chars": sum(len(f.text) for f in fragments)})
    return job

def _ocr_single_frame(frame_path, api_base, model, max_tokens, temperature, timeout):
    with open(frame_path, "rb") as f:
        image_b64 = base64.b64encode(f.read()).decode("utf-8")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": LEGAL_OCR_SYSTEM_PROMPT},
            {"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
                {"type": "text", "text": LEGAL_OCR_USER_PROMPT}]}],
        "max_tokens": max_tokens, "temperature": temperature}
    with httpx.Client(timeout=timeout) as client:
        response = client.post(f"{api_base}/chat/completions", json=payload)
        response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]

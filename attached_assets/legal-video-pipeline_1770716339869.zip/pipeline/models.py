"""Shared data models for the Legal Video Pipeline."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional
from datetime import datetime
import json
import hashlib


class StageStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class Stage(Enum):
    VALIDATE = "01_validate"
    EXTRACT = "02_extract"
    DEDUPLICATE = "03_deduplicate"
    OCR = "04_ocr"
    STITCH = "05_stitch"
    ENTITIES = "06_entities"
    OUTPUT = "07_output"


@dataclass
class StageResult:
    stage: Stage
    status: StageStatus = StageStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None
    metrics: dict = field(default_factory=dict)


@dataclass
class ExtractedEntity:
    entity_type: str
    value: str
    confidence: float = 1.0
    context: str = ""


@dataclass
class OCRFragment:
    frame_index: int
    frame_path: str
    text: str
    confidence: float = 1.0


@dataclass
class PipelineJob:
    job_id: str = ""
    source_file: str = ""
    source_file_hash: str = ""
    created_at: str = ""
    current_stage: Stage = Stage.VALIDATE
    stage_results: dict = field(default_factory=dict)
    file_valid: bool = False
    file_size_bytes: int = 0
    duration_seconds: float = 0.0
    resolution: tuple = (0, 0)
    raw_frame_count: int = 0
    raw_frame_dir: str = ""
    unique_frame_count: int = 0
    unique_frame_paths: list = field(default_factory=list)
    ocr_fragments: list = field(default_factory=list)
    stitched_text: str = ""
    entities: list = field(default_factory=list)
    output_paths: dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.job_id and self.source_file:
            self.job_id = self._generate_job_id()

    def _generate_job_id(self) -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        name = Path(self.source_file).stem[:30] if self.source_file else "unknown"
        short_hash = hashlib.md5((self.source_file or "").encode()).hexdigest()[:6]
        return f"{ts}_{name}_{short_hash}"

    def mark_stage(self, stage: Stage, status: StageStatus,
                   error: str = None, metrics: dict = None):
        result = self.stage_results.get(stage.value, StageResult(stage=stage))
        result.status = status
        if status == StageStatus.RUNNING:
            result.started_at = datetime.now()
        if status in (StageStatus.COMPLETED, StageStatus.FAILED):
            result.completed_at = datetime.now()
        if error:
            result.error = error
        if metrics:
            result.metrics = metrics
        self.stage_results[stage.value] = result

    def to_checkpoint(self) -> dict:
        return {
            "job_id": self.job_id,
            "source_file": self.source_file,
            "source_file_hash": self.source_file_hash,
            "created_at": self.created_at,
            "current_stage": self.current_stage.value,
            "file_valid": self.file_valid,
            "file_size_bytes": self.file_size_bytes,
            "duration_seconds": self.duration_seconds,
            "resolution": list(self.resolution),
            "raw_frame_count": self.raw_frame_count,
            "raw_frame_dir": self.raw_frame_dir,
            "unique_frame_count": self.unique_frame_count,
            "unique_frame_paths": self.unique_frame_paths,
            "ocr_fragments": [
                {"frame_index": f.frame_index, "frame_path": f.frame_path,
                 "text": f.text, "confidence": f.confidence}
                for f in self.ocr_fragments
            ],
            "stitched_text": self.stitched_text,
            "entities": [
                {"entity_type": e.entity_type, "value": e.value,
                 "confidence": e.confidence, "context": e.context}
                for e in self.entities
            ],
            "output_paths": self.output_paths,
            "stage_results": {
                k: {"status": v.status.value,
                     "started_at": v.started_at.isoformat() if v.started_at else None,
                     "completed_at": v.completed_at.isoformat() if v.completed_at else None,
                     "error": v.error, "metrics": v.metrics}
                for k, v in self.stage_results.items()
            },
        }

    @classmethod
    def from_checkpoint(cls, data: dict) -> "PipelineJob":
        job = cls()
        job.job_id = data["job_id"]
        job.source_file = data["source_file"]
        job.source_file_hash = data.get("source_file_hash", "")
        job.created_at = data["created_at"]
        job.current_stage = Stage(data["current_stage"])
        job.file_valid = data.get("file_valid", False)
        job.file_size_bytes = data.get("file_size_bytes", 0)
        job.duration_seconds = data.get("duration_seconds", 0.0)
        job.resolution = tuple(data.get("resolution", (0, 0)))
        job.raw_frame_count = data.get("raw_frame_count", 0)
        job.raw_frame_dir = data.get("raw_frame_dir", "")
        job.unique_frame_count = data.get("unique_frame_count", 0)
        job.unique_frame_paths = data.get("unique_frame_paths", [])
        job.ocr_fragments = [OCRFragment(**f) for f in data.get("ocr_fragments", [])]
        job.stitched_text = data.get("stitched_text", "")
        job.entities = [ExtractedEntity(**e) for e in data.get("entities", [])]
        job.output_paths = data.get("output_paths", {})
        return job

"""STAGE 2: FRAME EXTRACTION — CPU data prep before GPU stages."""

import subprocess
from pathlib import Path
from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import get_logger, ensure_dirs

log = get_logger("extract")

def extract_frames(job: PipelineJob, config: dict) -> PipelineJob:
    job.mark_stage(Stage.EXTRACT, StageStatus.RUNNING)
    cfg = config.get("extraction", {})
    fps = cfg.get("fps", 2)
    quality = cfg.get("quality", 2)
    output_format = cfg.get("output_format", "png")

    temp_base = config.get("paths", {}).get("temp_dir", "/tmp/legal-pipeline")
    frame_dir = Path(temp_base) / job.job_id / "raw_frames"
    ensure_dirs(str(frame_dir))
    job.raw_frame_dir = str(frame_dir)

    try:
        output_pattern = str(frame_dir / f"frame_%06d.{output_format}")
        cmd = ["ffmpeg", "-i", job.source_file, "-vf", f"fps={fps}",
               "-q:v", str(quality), "-y", "-hide_banner", "-loglevel", "warning",
               output_pattern]

        log.info(f"Extracting frames at {fps} FPS...")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg failed: {result.stderr}")

        frame_files = sorted(frame_dir.glob(f"*.{output_format}"))
        job.raw_frame_count = len(frame_files)
        if job.raw_frame_count == 0:
            raise RuntimeError("FFmpeg produced zero frames")

        log.info(f"Extracted {job.raw_frame_count} frames ({job.duration_seconds:.1f}s @ {fps} FPS)")
        job.mark_stage(Stage.EXTRACT, StageStatus.COMPLETED, metrics={
            "raw_frame_count": job.raw_frame_count, "fps": fps})
    except Exception as e:
        log.error(f"Frame extraction failed: {e}")
        job.mark_stage(Stage.EXTRACT, StageStatus.FAILED, error=str(e))
    return job

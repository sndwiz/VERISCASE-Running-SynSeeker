"""Legal Video-to-Document Pipeline"""

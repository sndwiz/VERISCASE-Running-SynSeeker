#!/usr/bin/env python3
"""
Quick test script — validates pipeline logic without requiring GPUs.
Creates a mock video, runs CPU stages (validate, extract, dedup),
and simulates GPU stages with mock responses.

Usage:
    pip install -r requirements.txt
    python test_local.py
"""

import tempfile
import subprocess
import shutil
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from pipeline.models import PipelineJob, Stage, StageStatus
from pipeline.utils import load_config, setup_logging, save_checkpoint, load_checkpoint


def create_test_video(output_path: str, duration: int = 5):
    """Create a simple test video with scrolling text using FFmpeg."""
    # Generate a video with scrolling text to simulate a screen recording
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi",
        "-i", (
            f"color=c=white:s=1080x1920:d={duration},"
            "drawtext=text='UNITED STATES DISTRICT COURT\\n"
            "DISTRICT OF UTAH\\n\\n"
            "Case No. 2-24-cv-01234-ABC\\n\\n"
            "SMITH v. JONES CORPORATION\\n\\n"
            "MOTION TO DISMISS\\n\\n"
            "Plaintiff John Smith hereby moves this Court...'"
            ":fontsize=36:fontcolor=black:x=50:y=50"
        ),
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-t", str(duration),
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        # Fallback: simpler test video
        cmd_simple = [
            "ffmpeg", "-y",
            "-f", "lavfi",
            "-i", f"color=c=white:s=1080x1920:d={duration}",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-t", str(duration),
            output_path,
        ]
        result = subprocess.run(cmd_simple, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"ERROR: Could not create test video: {result.stderr}")
            return False

    print(f"Created test video: {output_path}")
    return True


def test_stage_01_validate():
    """Test file validation stage."""
    print("\n" + "=" * 60)
    print("TEST: Stage 01 — Validate")
    print("=" * 60)

    from pipeline.stage_01_validate import validate

    with tempfile.TemporaryDirectory() as tmpdir:
        video_path = str(Path(tmpdir) / "test.mov")

        # Create test video
        if not create_test_video(video_path):
            print("SKIP: FFmpeg not available")
            return False

        config = {
            "ingestion": {
                "supported_formats": [".mov", ".mp4"],
                "max_file_size_gb": 10,
                "min_file_size_kb": 1,
            }
        }

        job = PipelineJob(source_file=video_path)
        job = validate(job, config)

        assert job.file_valid, f"Validation failed: {job.stage_results}"
        assert job.file_size_bytes > 0
        assert job.duration_seconds > 0
        assert job.resolution[0] > 0
        print(f"  ✓ File valid: {job.resolution[0]}x{job.resolution[1]}, "
              f"{job.duration_seconds:.1f}s")

        # Test invalid file
        job_bad = PipelineJob(source_file="/nonexistent/file.mov")
        job_bad = validate(job_bad, config)
        assert not job_bad.file_valid
        print("  ✓ Invalid file correctly rejected")

    return True


def test_stage_02_extract():
    """Test frame extraction stage."""
    print("\n" + "=" * 60)
    print("TEST: Stage 02 — Extract Frames")
    print("=" * 60)

    from pipeline.stage_01_validate import validate
    from pipeline.stage_02_extract import extract_frames

    with tempfile.TemporaryDirectory() as tmpdir:
        video_path = str(Path(tmpdir) / "test.mov")

        if not create_test_video(video_path, duration=3):
            print("SKIP: FFmpeg not available")
            return False

        config = {
            "ingestion": {
                "supported_formats": [".mov"],
                "min_file_size_kb": 1,
                "max_file_size_gb": 10,
            },
            "extraction": {
                "fps": 2,
                "quality": 2,
                "output_format": "png",
                "max_dimension": 2048,
            },
            "paths": {
                "temp_dir": str(Path(tmpdir) / "temp"),
            },
        }

        job = PipelineJob(source_file=video_path)
        job = validate(job, config)
        assert job.file_valid

        job = extract_frames(job, config)

        result = job.stage_results.get(Stage.EXTRACT.value)
        assert result.status == StageStatus.COMPLETED
        assert job.raw_frame_count > 0
        print(f"  ✓ Extracted {job.raw_frame_count} frames")

        # Verify frames exist on disk
        frame_dir = Path(job.raw_frame_dir)
        frames = list(frame_dir.glob("*.png"))
        assert len(frames) == job.raw_frame_count
        print(f"  ✓ {len(frames)} frame files on disk")

    return True


def test_stage_03_deduplicate():
    """Test frame deduplication stage."""
    print("\n" + "=" * 60)
    print("TEST: Stage 03 — Deduplicate Frames")
    print("=" * 60)

    from pipeline.stage_01_validate import validate
    from pipeline.stage_02_extract import extract_frames
    from pipeline.stage_03_deduplicate import deduplicate_frames

    with tempfile.TemporaryDirectory() as tmpdir:
        video_path = str(Path(tmpdir) / "test.mov")

        if not create_test_video(video_path, duration=5):
            print("SKIP: FFmpeg not available")
            return False

        config = {
            "ingestion": {"supported_formats": [".mov"],
                          "min_file_size_kb": 1, "max_file_size_gb": 10},
            "extraction": {"fps": 2, "quality": 2, "output_format": "png",
                           "max_dimension": 2048},
            "deduplication": {"hash_algorithm": "phash", "hash_size": 16,
                              "hamming_threshold": 12, "min_unique_frames": 1,
                              "max_unique_frames": 200},
            "paths": {"temp_dir": str(Path(tmpdir) / "temp")},
        }

        job = PipelineJob(source_file=video_path)
        job = validate(job, config)
        job = extract_frames(job, config)

        raw_count = job.raw_frame_count
        job = deduplicate_frames(job, config)

        result = job.stage_results.get(Stage.DEDUPLICATE.value)
        assert result.status == StageStatus.COMPLETED
        assert job.unique_frame_count > 0
        assert job.unique_frame_count <= raw_count

        reduction = result.metrics.get("reduction_percent", 0)
        print(f"  ✓ {raw_count} → {job.unique_frame_count} frames "
              f"({reduction:.0f}% reduction)")

    return True


def test_checkpoint_resume():
    """Test checkpoint save/load for crash recovery."""
    print("\n" + "=" * 60)
    print("TEST: Checkpoint / Resume")
    print("=" * 60)

    from pipeline.models import OCRFragment, ExtractedEntity

    with tempfile.TemporaryDirectory() as tmpdir:
        job = PipelineJob(source_file="/fake/test.mov")
        job.file_valid = True
        job.raw_frame_count = 120
        job.unique_frame_count = 25
        job.unique_frame_paths = [f"/tmp/frame_{i}.png" for i in range(25)]
        job.ocr_fragments = [
            OCRFragment(frame_index=0, frame_path="/tmp/f.png",
                        text="Test legal text")
        ]
        job.stitched_text = "Full legal document text here."
        job.entities = [
            ExtractedEntity(entity_type="case_number",
                            value="2:24-cv-01234")
        ]
        job.current_stage = Stage.ENTITIES
        job.mark_stage(Stage.VALIDATE, StageStatus.COMPLETED)
        job.mark_stage(Stage.EXTRACT, StageStatus.COMPLETED)
        job.mark_stage(Stage.DEDUPLICATE, StageStatus.COMPLETED)
        job.mark_stage(Stage.OCR, StageStatus.COMPLETED)
        job.mark_stage(Stage.STITCH, StageStatus.COMPLETED)

        # Save checkpoint
        save_checkpoint(job, tmpdir)
        print(f"  ✓ Checkpoint saved: {job.job_id}")

        # Load checkpoint
        restored = load_checkpoint(job.job_id, tmpdir)
        assert restored is not None
        assert restored.job_id == job.job_id
        assert restored.file_valid == True
        assert restored.raw_frame_count == 120
        assert restored.unique_frame_count == 25
        assert len(restored.ocr_fragments) == 1
        assert restored.stitched_text == "Full legal document text here."
        assert len(restored.entities) == 1
        assert restored.entities[0].value == "2:24-cv-01234"
        print(f"  ✓ Checkpoint restored with all data intact")

    return True


def main():
    setup_logging("INFO")

    print("=" * 60)
    print("  Legal Video Pipeline — Local Tests")
    print("  (No GPU required — tests CPU stages only)")
    print("=" * 60)

    # Check FFmpeg availability
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        has_ffmpeg = True
    except (subprocess.CalledProcessError, FileNotFoundError):
        has_ffmpeg = False
        print("\nWARNING: FFmpeg not found. Video tests will be skipped.")

    results = {}

    tests = [
        ("Checkpoint/Resume", test_checkpoint_resume),
    ]

    if has_ffmpeg:
        tests = [
            ("Stage 01: Validate", test_stage_01_validate),
            ("Stage 02: Extract", test_stage_02_extract),
            ("Stage 03: Deduplicate", test_stage_03_deduplicate),
            ("Checkpoint/Resume", test_checkpoint_resume),
        ]

    for name, test_func in tests:
        try:
            passed = test_func()
            results[name] = "PASS" if passed else "SKIP"
        except Exception as e:
            print(f"  ✗ FAILED: {e}")
            results[name] = "FAIL"

    # Summary
    print("\n" + "=" * 60)
    print("  TEST SUMMARY")
    print("=" * 60)
    for name, result in results.items():
        icon = {"PASS": "✓", "FAIL": "✗", "SKIP": "⊘"}[result]
        print(f"  {icon} {name}: {result}")

    failed = sum(1 for v in results.values() if v == "FAIL")
    if failed:
        print(f"\n{failed} test(s) FAILED")
        sys.exit(1)
    else:
        print(f"\nAll tests passed!")


if __name__ == "__main__":
    main()

# dbStorage.ts Breakup Plan

## Current State

- **Single file**: `server/dbStorage.ts` — 4,546 lines, 179KB, 155+ async methods
- **Single class**: `DbStorage` handles ALL database operations for 80+ tables
- **Problem**: Unmaintainable. One typo breaks every feature. Merge conflicts guaranteed with multiple devs.

## Target Structure

```
server/
├── storage/
│   ├── index.ts              # Re-exports combined storage + shared db instance
│   ├── base.ts               # Base class with shared db pool reference
│   ├── boards.storage.ts     # Boards, Groups, Tasks (~240 lines)
│   ├── ai.storage.ts         # AI Conversations, Messages (~100 lines)
│   ├── evidence.storage.ts   # Evidence Vault, OCR Jobs, Timeline, Chain of Custody (~200 lines)
│   ├── threads.storage.ts    # Threads, Messages, Decisions (~160 lines)
│   ├── clients.storage.ts    # Clients, Matters, Matter Contacts (~180 lines)
│   ├── research.storage.ts   # Research Results (~50 lines)
│   ├── automations.storage.ts # Automation Rules (~70 lines)
│   ├── detective.storage.ts  # Detective Nodes (~120 lines)
│   ├── files.storage.ts      # File Items, Doc Profiles, Filing Tags, Tag Links (~230 lines)
│   ├── people.storage.ts     # People/Orgs (~80 lines)
│   ├── billing.storage.ts    # Time Entries, Expenses, Invoices, Payments, Trust (~400 lines)
│   ├── calendar.storage.ts   # Calendar Events (~120 lines)
│   ├── approvals.storage.ts  # Approval Requests, Comments, Initials (~100 lines)
│   ├── templates.storage.ts  # Document Templates, Generated Docs, Approvals (~1,900 lines — mostly in-memory data)
│   ├── forms.storage.ts      # Client Forms, Submissions (~60 lines)
│   ├── meetings.storage.ts   # Meetings (~50 lines)
│   └── security.storage.ts   # Audit Logs, Security Events (~120 lines)
```

## Line-by-Line Mapping

Current `dbStorage.ts` sections → new files:

| Lines | Section | New File |
|---|---|---|
| 105–189 | Board Methods | `boards.storage.ts` |
| 190–241 | Group Methods | `boards.storage.ts` |
| 242–345 | Task Methods | `boards.storage.ts` |
| 346–443 | AI Conversation/Message Methods | `ai.storage.ts` |
| 444–534 | Evidence Vault Methods | `evidence.storage.ts` |
| 535–598 | OCR Jobs Methods | `evidence.storage.ts` |
| 599–650 | Timeline Methods | `evidence.storage.ts` |
| 651–809 | Thread Methods | `threads.storage.ts` |
| 810–890 | Client Methods | `clients.storage.ts` |
| 891–964 | Matter Methods | `clients.storage.ts` |
| 965–1037 | Matter Contact Methods | `clients.storage.ts` |
| 1038–1083 | Research Methods | `research.storage.ts` |
| 1084–1151 | Automation Methods | `automations.storage.ts` |
| 1152–1271 | Detective Board Methods | `detective.storage.ts` |
| 1272–1489 | File Items, Doc Profiles, Tags | `files.storage.ts` |
| 1490–1567 | People/Orgs | `people.storage.ts` |
| 1568–1777 | Time Entries, Expenses | `billing.storage.ts` |
| 1783–1923 | Invoices | `billing.storage.ts` |
| 1924–2030 | Payments, Trust Transactions | `billing.storage.ts` |
| 2031–2173 | Calendar Events | `calendar.storage.ts` |
| 2174–2263 | Approval Requests | `approvals.storage.ts` |
| 2264–4141 | Document Templates (in-memory) | `templates.storage.ts` |
| 4142–4318 | Template CRUD + Generated Docs | `templates.storage.ts` |
| 4319–4381 | Client Forms | `forms.storage.ts` |
| 4382–4424 | Meetings | `meetings.storage.ts` |
| 4425–4495 | Audit Logs | `security.storage.ts` |
| 4496–4546 | Security Events | `security.storage.ts` |

## Implementation

### Step 1: Create `base.ts`

Shared database pool that all storage modules import:

```typescript
// server/storage/base.ts
import { db } from "../db";
import type { PostgresJsDatabase } from "drizzle-orm/postgres-js";

export abstract class BaseStorage {
  protected db = db;
}
```

### Step 2: Create Domain Files

Each file extends BaseStorage and exports its methods. Example:

```typescript
// server/storage/boards.storage.ts
import { BaseStorage } from "./base";
import { eq } from "drizzle-orm";
import { boards, groups, tasks } from "@shared/schema";
import type { Board, InsertBoard, Group, InsertGroup, Task, InsertTask } from "@shared/schema";

export class BoardStorage extends BaseStorage {
  async getBoards(): Promise<Board[]> {
    return this.db.select().from(boards).orderBy(boards.createdAt);
  }
  // ... rest of board/group/task methods
}
```

### Step 3: Create `index.ts` Facade

Combine all storage classes into one object that matches the current `storage` export:

```typescript
// server/storage/index.ts
import { BoardStorage } from "./boards.storage";
import { AIStorage } from "./ai.storage";
import { EvidenceStorage } from "./evidence.storage";
import { ClientStorage } from "./clients.storage";
import { BillingStorage } from "./billing.storage";
import { SecurityStorage } from "./security.storage";
// ... etc

// Composition over inheritance
class Storage {
  boards = new BoardStorage();
  ai = new AIStorage();
  evidence = new EvidenceStorage();
  clients = new ClientStorage();
  billing = new BillingStorage();
  security = new SecurityStorage();
  // ... etc
}

export const storage = new Storage();
```

### Step 4: Update Route Imports

**Before** (current):
```typescript
import { storage } from "../dbStorage";
// storage.getBoards()
```

**After** (two options):

Option A — Namespaced (cleaner, recommended):
```typescript
import { storage } from "../storage";
// storage.boards.getBoards()
```

Option B — Backward compatible facade (if you want zero route changes):
```typescript
// server/storage/index.ts - flat proxy
export const storage = {
  ...new BoardStorage(),
  ...new AIStorage(),
  ...new EvidenceStorage(),
  // ... spread all storage classes
};
```

Option B means ZERO changes to any route file. The storage object has the same flat method names. You can refactor to Option A later.

## Migration Order (Safest Path)

1. **Create `server/storage/` directory**
2. **Create `base.ts`** with shared db reference
3. **Move `security.storage.ts` first** — smallest blast radius, easy to test
4. **Move `meetings.storage.ts`** — isolated, simple CRUD
5. **Move `billing.storage.ts`** — large but self-contained domain
6. **Move `evidence.storage.ts`** — critical path, test thoroughly
7. **Continue domain by domain**, testing each before proceeding
8. **Move `templates.storage.ts` last** — largest chunk (1,900 lines of in-memory template data)
9. **Delete `dbStorage.ts`** once all methods are migrated and tests pass
10. **Update import paths** in route files

## The Templates Problem

Lines 2264–4141 are ~1,900 lines of **hardcoded in-memory template objects** (civil litigation forms, PI/tort templates, discovery templates, settlement templates). This isn't really "storage" — it's seed data living in code.

**Recommendation**: Extract to JSON files:
```
server/data/
├── templates/
│   ├── civil-litigation.json
│   ├── personal-injury.json
│   ├── discovery.json
│   └── settlement.json
```

Load them in `templates.storage.ts` with `import` or `fs.readFileSync`. This alone removes ~1,900 lines from the storage layer.

## Estimated Effort

- **Total**: 3-4 hours for an experienced dev
- **Risk**: Low if using Option B (flat proxy) — zero route changes needed
- **Testing**: Each module can be verified independently by running the routes that use it

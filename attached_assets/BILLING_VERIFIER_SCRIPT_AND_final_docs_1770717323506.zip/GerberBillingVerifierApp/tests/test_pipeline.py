import pandas as pd
from pathlib import Path
from app.pipeline import Settings, run_pipeline

def test_pipeline_smoke(tmp_path: Path):
    # minimal fake time entry
    df = pd.DataFrame({
        "Date": ["2025-10-01"],
        "Hours": [1.5],
        "Narrative": ["Draft injunction"],
        "Evidence": ["Doc: temp civil stalking injunction"],
    })
    csv = tmp_path/"time.csv"
    df.to_csv(csv, index=False)

    settings = Settings(
        client_name="David Gerber",
        aliases=["Gerber"],
        phones=["8018080242"],
        key_parties=["Mueller"],
        start_date="2025-09-20",
        end_date="2025-11-30",
        hourly_rate=850.0,
    )
    out = run_pipeline(settings, [csv], workdir=tmp_path/"work", outdir=tmp_path/"out")
    assert out["xlsx"].exists()
    assert out["csv"].exists()

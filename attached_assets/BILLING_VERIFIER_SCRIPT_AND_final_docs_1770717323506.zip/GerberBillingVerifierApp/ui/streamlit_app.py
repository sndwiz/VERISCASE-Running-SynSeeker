import streamlit as st
from pathlib import Path
import tempfile
import pandas as pd

from app.pipeline import Settings, run_pipeline


st.set_page_config(page_title="Billing Verifier", layout="wide")
st.title("Gerber Billing Verifier – Button-First")

st.markdown("Upload exports, set the client + dates, then click **Run Pipeline**. This tool is for **verification + packaging**, not inventing time.")

with st.sidebar:
    st.header("Matter Settings")
    client_name = st.text_input("Client name", value="David Gerber")
    aliases = st.text_area("Client aliases (one per line)", value="David Gerber\nGerber").splitlines()
    phones = st.text_area("Client phone numbers (one per line)", value="8018080242").splitlines()
    key_parties = st.text_area("Key parties (one per line)", value="Mueller\nJennifer Terry\nMatt\nWhit\nBernarda").splitlines()

    st.header("Date Range")
    start_date = st.date_input("Start date", value=pd.to_datetime("2025-09-20"))
    end_date = st.date_input("End date", value=pd.to_datetime("2025-11-30"))

    st.header("Billing")
    rate = st.number_input("Hourly rate", value=850.0, step=10.0)
    long_thresh = st.number_input("Long entry threshold (hours)", value=6.0, step=0.5)
    day_thresh = st.number_input("Day threshold (hours)", value=10.0, step=0.5)

st.subheader("1) Upload files")
uploads = st.file_uploader("Drop CSV/XLSX/ZIP files here", accept_multiple_files=True, type=["csv","xlsx","xls","zip"])

run = st.button("Run Pipeline", type="primary", disabled=(len(uploads)==0))

if run:
    with st.spinner("Running pipeline..."):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            in_files=[]
            for u in uploads:
                fp = td / u.name
                fp.write_bytes(u.getbuffer())
                in_files.append(fp)

            settings = Settings(
                client_name=client_name.strip(),
                aliases=[a.strip() for a in aliases if a.strip()],
                phones=[p.strip() for p in phones if p.strip()],
                key_parties=[k.strip() for k in key_parties if k.strip()],
                start_date=str(start_date),
                end_date=str(end_date),
                hourly_rate=float(rate),
                long_entry_hours_threshold=float(long_thresh),
                day_hours_threshold=float(day_thresh),
            )

            out = run_pipeline(settings, in_files, workdir=td/"work", outdir=td/"out")
            st.success("Done!")

            # Show preview of outputs
            xlsx = out["xlsx"]
            csv = out["csv"]

            st.download_button("Download Clio-ready Excel", data=xlsx.read_bytes(), file_name=xlsx.name)
            st.download_button("Download Paste CSV", data=csv.read_bytes(), file_name=csv.name)

            # quick preview
            df = pd.read_csv(csv)
            st.subheader("Preview (first 50 rows)")
            st.dataframe(df.head(50), use_container_width=True)

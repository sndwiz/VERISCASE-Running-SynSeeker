# System Spec: Button-First Billing Verification Pipeline

## Goal
Make billing **fast, defensible, and reviewable**:
- Lauren (attorney) should click buttons, verify flags, and export billing.
- The tool should minimize reading through raw logs and maximize traceability.

## Inputs (common formats)
Your current universe of files typically includes:
1) Time logs (Clio export / BillingBlox / custom CSV)
2) Email exports (sent mail, internal communications)
3) Phone bills / usage details (calls, sometimes SMS)
4) Calendar exports
5) Scratch timeline notes (Pages/doc exports)

The tool should accept:
- `.xlsx`, `.csv`
- optionally `.zip` (containing any of the above)

## Core Rules (non-negotiables)
1) **No invented time.** The tool never creates billable time from thin air.
2) **Date-window truth.** All outputs are filtered to the selected start/end dates.
3) **Matter isolation.** Only items matching client aliases / phone numbers / key parties count.
4) **Auditability.** Every entry must carry:
   - source file
   - evidence pointer (or be flagged missing)
5) **Review-first.** Anything ambiguous becomes a button-click decision:
   - "Confirm Gerber link" / "Not Gerber"
   - "Attach evidence" / "Leave flagged"
   - "Use split version" / "Keep original"

## Data Model (normalized)
Everything becomes a normalized event row:

### `Event`
- `event_id` (stable hash of key fields)
- `event_type` (time_entry, call, email, calendar, doc_touch)
- `timestamp_start`, `timestamp_end`
- `date`
- `duration_minutes`, `duration_hours`
- `title` / `subject`
- `body_snippet` (safe short)
- `people` (list)
- `phones` (list)
- `client_hit` (bool)
- `confidence` (High/Medium/Low)
- `source_file`, `source_sheet`, `source_row`
- `raw_json` (optional for audit)

### `TimeEntry`
- `hours`, `rate`, `amount`
- `narrative_raw`
- `evidence_raw`

## Pipeline Steps (what the buttons trigger)
### Step A — Ingest
- Unzip if needed
- Detect file type
- Parse into tables using known patterns:
  - usage details calls
  - calendar events
  - time entries

### Step B — Normalize
- Convert date/time formats
- Standardize phone numbers
- Standardize names (alias mapping)

### Step C — Filter
- Date range filter
- Client/matter filter using:
  - client name aliases
  - key-party names
  - phone numbers

### Step D — Dedupe
- Exact duplicates (same timestamp + duration + contact + source)
- Near-duplicates (same day + same subject + same duration) -> flag for review

### Step E — Enrich (evidence suggestions)
For each time entry on a date:
- look for nearby evidence ±1 day:
  - Gerber calls
  - key contact calls
  - calendar events
  - doc activity / “touches”
Store a compact `Evidence Suggested` string.

### Step F — Flagging (review queue)
- Missing evidence
- Very long entries (>= threshold; default 6 hours)
- Medium confidence
- Days over 10 hours
- Potential overlaps (time blocks overlapping)

### Step G — Narrative generation (Clio-ready)
Generate conservative narratives:
- Verb + task + client
- Attach short evidence in parentheses if present
- Never state legal conclusions; just work performed

### Step H — Split alternatives
For very long entries:
- generate 2–5 sub-entries
- equalize hours to 0.01 precision (same total)
- provide “Split Alternative” sheet
- user chooses which to use

### Step I — Export
- Excel workbook:
  - At a glance
  - Clio-ready entries (as-is)
  - Review checklist
  - Split alternatives
  - Supporting reference sheets
- CSV paste/import

## UI (what Lauren sees)
### Screen 1: Setup
- Upload files (multi)
- Client name + aliases
- Key-party names
- Date range
- Hourly rate
- Buttons:
  - **Run Pipeline**
  - **Save Profile** (re-use settings)

### Screen 2: Review
Tabs:
- P0 Missing evidence
- P1 Very long (split)
- P2 Medium confidence
- Days over 10h
Each row has buttons:
- Confirm / Not Gerber
- Mark evidence attached (paste pointer)
- Accept split / keep original

### Screen 3: Export
- Download Excel + CSV
- Export a “review log” (who clicked what + when)

## Security / privacy
- Run locally (Mac) by default
- Do not send data to third parties
- Optional encryption at rest for saved projects
- Audit log of changes

## Developer handoff checklist
- Confirm all input formats we need to support
- Decide where projects are stored (local folder vs database)
- Confirm export template that matches Lauren’s billing system (Clio vs other)

# Gerber Billing Verifier (Button-First)

This repo is a starter app to turn messy legal activity exports (Clio logs, email exports, phone bills, calendars, scratch timelines)
into a **review-first** billing package:

- filters to a **client/matter** (e.g., David Gerber)
- constrains to a **date window** (e.g., 2025-09-20 → 2025-11-30)
- dedupes + normalizes records
- generates:
  - **Clio-ready entries** (as-is, no invented time)
  - **flags** (missing evidence, very long entries, medium-confidence links)
  - **evidence suggestions** (calls / calendar / doc-touch proxies)
  - **split alternatives** for long entries (same total time)
  - exports to Excel + CSV

## Philosophy (important)
This tool is designed to **verify and package recorded work**. It should not be used to create or inflate time.
Every billed entry should tie back to something verifiable (document edits, email threads, calendar events, call logs, etc).

## Quick start
1) Create a venv and install:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2) Run the UI:
```bash
streamlit run ui/streamlit_app.py
```

3) Upload files, set:
- Client name / aliases (e.g., "David Gerber", "Gerber", phone number)
- Date range
- Hourly rate

4) Click **Run Pipeline** → downloads appear.

## Outputs
The pipeline produces:
- `*_ClioReady.xlsx` (multi-sheet workbook)
- `*_Paste.csv` (easy import/paste)
- `*_Audit.xlsx` (flag lists)

## Extending
- Add more parsers in `app/parsers.py`
- Tune narrative templates in `app/narratives.py`
- Add Clio API export later (requires credentials + scope)

## Notes
This starter is intentionally conservative: if it can't prove a link, it marks it for review.

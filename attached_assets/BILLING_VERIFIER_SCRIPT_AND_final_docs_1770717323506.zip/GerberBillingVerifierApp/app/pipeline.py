from __future__ import annotations

import re
import zipfile
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


@dataclass
class Settings:
    client_name: str
    aliases: List[str]
    phones: List[str]
    key_parties: List[str]
    start_date: str  # YYYY-MM-DD
    end_date: str    # YYYY-MM-DD
    hourly_rate: float = 850.0
    long_entry_hours_threshold: float = 6.0
    day_hours_threshold: float = 10.0


def _standardize_phone(s: str) -> str:
    if s is None:
        return ""
    digits = re.sub(r"\D+", "", str(s))
    # keep last 10 digits if longer
    if len(digits) > 10:
        digits = digits[-10:]
    return digits


def _contains_any(hay: str, needles: List[str]) -> bool:
    hay = (hay or "").lower()
    return any((n or "").lower() in hay for n in needles if n)


def load_files(input_paths: List[Path], workdir: Path) -> List[Path]:
    """
    Accepts files and zips. Expands zips into workdir and returns a flat list of files.
    """
    workdir.mkdir(parents=True, exist_ok=True)
    out: List[Path] = []

    for p in input_paths:
        p = Path(p)
        if p.suffix.lower() == ".zip":
            with zipfile.ZipFile(p, "r") as z:
                z.extractall(workdir)
            # collect extracted
            for fp in workdir.rglob("*"):
                if fp.is_file() and fp.suffix.lower() in (".csv", ".xlsx", ".xls"):
                    out.append(fp)
        else:
            out.append(p)
    return out


def parse_tables(files: List[Path]) -> Dict[str, List[Tuple[str, pd.DataFrame]]]:
    """
    Very lightweight "best-effort" parsers. Extend this as you learn new formats.
    Returns dict of categories -> list of (source_name, df).
    """
    cats: Dict[str, List[Tuple[str, pd.DataFrame]]] = {"time": [], "calls": [], "calendar": [], "docs": []}

    for f in files:
        name = f.name
        suf = f.suffix.lower()

        try:
            if suf == ".csv":
                df = pd.read_csv(f)
                # heuristics
                cols = " ".join(df.columns.astype(str)).lower()
                if "minutes" in cols and ("incoming" in cols or "outgoing" in cols or "direction" in cols):
                    cats["calls"].append((name, df))
                elif "subject" in cols and ("start" in cols or "begin" in cols):
                    cats["calendar"].append((name, df))
                else:
                    cats["time"].append((name, df))
            elif suf in (".xlsx", ".xls"):
                xls = pd.ExcelFile(f)
                for sheet in xls.sheet_names:
                    df = pd.read_excel(xls, sheet_name=sheet)
                    cols = " ".join(df.columns.astype(str)).lower()
                    tag = None
                    if "minutes" in cols and ("incoming" in cols or "outgoing" in cols or "direction" in cols):
                        tag = "calls"
                    elif "subject" in cols and ("start" in cols or "begin" in cols):
                        tag = "calendar"
                    elif "document" in cols and ("touches" in cols or "first" in cols or "last" in cols):
                        tag = "docs"
                    else:
                        tag = "time"
                    cats[tag].append((f"{name}::{sheet}", df))
        except Exception:
            # swallow parse errors; you can log this later
            continue

    return cats


def normalize_calls(dfs: List[Tuple[str, pd.DataFrame]]) -> pd.DataFrame:
    if not dfs:
        return pd.DataFrame()

    out = []
    for src, df in dfs:
        d = df.copy()
        # try common columns
        ts_col = None
        for c in d.columns:
            if str(c).lower() in ("timestamp", "date/time", "date time", "date", "time"):
                ts_col = c
                break
        if ts_col is None and "Timestamp" in d.columns:
            ts_col = "Timestamp"

        # if separate date and time columns exist, leave as-is for now
        if ts_col is not None:
            d["_ts"] = pd.to_datetime(d[ts_col], errors="coerce")
        elif "Date" in d.columns and "Time" in d.columns:
            d["_ts"] = pd.to_datetime(d["Date"].astype(str) + " " + d["Time"].astype(str), errors="coerce")
        else:
            d["_ts"] = pd.NaT

        # direction / contact / minutes
        dir_col = None
        for c in d.columns:
            if "incoming" in str(c).lower() or "outgoing" in str(c).lower() or "direction" in str(c).lower():
                dir_col = c
                break
        if dir_col is None and "Incoming/Outgoing" in d.columns:
            dir_col = "Incoming/Outgoing"

        contact_col = "Contact" if "Contact" in d.columns else None
        minutes_col = "Minutes" if "Minutes" in d.columns else None

        d["_direction"] = d[dir_col] if dir_col in d.columns else ""
        d["_contact"] = d[contact_col] if contact_col in d.columns else ""
        d["_minutes"] = pd.to_numeric(d[minutes_col], errors="coerce") if minutes_col in d.columns else np.nan

        d["_src"] = src
        out.append(d[["_ts", "_direction", "_contact", "_minutes", "_src"]])

    calls = pd.concat(out, ignore_index=True)
    calls = calls.dropna(subset=["_ts"]).sort_values("_ts")
    calls["Date"] = calls["_ts"].dt.normalize()
    return calls.rename(columns={
        "_ts": "Timestamp",
        "_direction": "Direction",
        "_contact": "Contact",
        "_minutes": "Minutes",
        "_src": "Source",
    })


def normalize_calendar(dfs: List[Tuple[str, pd.DataFrame]]) -> pd.DataFrame:
    if not dfs:
        return pd.DataFrame()
    out=[]
    for src, df in dfs:
        d=df.copy()
        # heuristics for start
        start_col = None
        for c in d.columns:
            lc=str(c).lower()
            if lc in ("start","start time","begin","begin time","event start"):
                start_col=c
                break
        if start_col is None and "Start" in d.columns:
            start_col="Start"
        d["_start"]=pd.to_datetime(d[start_col], errors="coerce") if start_col in d.columns else pd.NaT

        subj_col = "Subject" if "Subject" in d.columns else ("Title" if "Title" in d.columns else None)
        d["_subject"]=d[subj_col] if subj_col in d.columns else ""

        d["_src"]=src
        out.append(d[["_start","_subject","_src"]])
    cal=pd.concat(out, ignore_index=True).dropna(subset=["_start"]).sort_values("_start")
    cal["Date"]=cal["_start"].dt.normalize()
    return cal.rename(columns={"_start":"Start","_subject":"Subject","_src":"Source"})


def normalize_time_entries(dfs: List[Tuple[str, pd.DataFrame]], hourly_rate: float) -> pd.DataFrame:
    """
    Expects a 'Date' column and 'Hours'. If missing, tries best-effort.
    """
    if not dfs:
        return pd.DataFrame()
    out=[]
    for src, df in dfs:
        d=df.copy()
        # Identify date
        date_col=None
        for c in d.columns:
            if str(c).lower() in ("date","day","work date"):
                date_col=c
                break
        if date_col is None and "Date" in d.columns:
            date_col="Date"

        d["_date"]=pd.to_datetime(d[date_col], errors="coerce") if date_col in d.columns else pd.NaT

        # Hours
        hours_col=None
        for c in d.columns:
            if str(c).lower() in ("hours","duration","time"):
                hours_col=c
                break
        if hours_col is None and "Hours" in d.columns:
            hours_col="Hours"
        d["_hours"]=pd.to_numeric(d[hours_col], errors="coerce") if hours_col in d.columns else np.nan

        # Narrative / evidence
        nar=None
        for c in d.columns:
            if "narrative" in str(c).lower() or "description" in str(c).lower():
                nar=c
                break
        ev=None
        for c in d.columns:
            if "evidence" in str(c).lower() or "support" in str(c).lower():
                ev=c
                break
        d["_narr"]=d[nar] if nar in d.columns else ""
        d["_evid"]=d[ev] if ev in d.columns else ""

        d["_src"]=src
        out.append(d[["_date","_hours","_narr","_evid","_src"]])

    te=pd.concat(out, ignore_index=True)
    te=te.dropna(subset=["_date"]).copy()
    te["Date"]=te["_date"].dt.normalize()
    te["Hours"]=te["_hours"].fillna(0.0)
    te["Rate"]=hourly_rate
    te["Amount"]=te["Hours"]*te["Rate"]
    te["Narrative"]=te["_narr"].astype(str)
    te["Evidence"]=te["_evid"].astype(str)
    te["Source"]=te["_src"]
    te=te[te["Hours"]>0].sort_values(["Date"])
    return te[["Date","Hours","Rate","Amount","Narrative","Evidence","Source"]]


def classify_confidence(text: str, aliases: List[str], key_parties: List[str], phones: List[str]) -> str:
    t=(text or "").lower()
    if _contains_any(t, [a.lower() for a in aliases] + [_standardize_phone(p) for p in phones if p]):
        return "High"
    if _contains_any(t, [k.lower() for k in key_parties]):
        return "Medium"
    return "Low"


def craft_clio_narrative(narrative: str, evidence: str, settings: Settings) -> str:
    text = f"{narrative} {evidence}".lower()

    doc_map = [
        (r"injunction|civil stalking", "Draft/revise civil stalking injunction"),
        (r"notice of appearance", "Prepare/file Notice of Appearance"),
        (r"return of service|proof of service|service assistance", "Coordinate service / prepare proof of service"),
        (r"acceptance of service", "Prepare/file Acceptance of Service"),
        (r"attorney fees", "Draft/revise motion re attorney fees"),
        (r"extension of time", "Draft/revise motion re extension of time"),
        (r"meet\s*&\s*confer|meet and confer", "Meet & confer re case issues"),
        (r"research", "Legal research"),
        (r"review|analy", "Review/analyze materials"),
        (r"draft|revise|edit", "Draft/revise documents"),
        (r"email", "Email correspondence"),
        (r"call|phone|voicemail", "Telephone conference"),
    ]
    task="Case work (client matter)"
    for pat,label in doc_map:
        if re.search(pat, text):
            task=label
            break

    base=f"{task}; {settings.client_name}"
    if evidence and str(evidence).strip():
        ev=re.sub(r"\s+"," ",str(evidence)).strip()[:120]
        base += f" ({ev})"
    return base


def evidence_suggest(date: pd.Timestamp, calls: pd.DataFrame, calendar: pd.DataFrame, settings: Settings) -> str:
    if pd.isna(date):
        return ""
    win = {date - pd.Timedelta(days=1), date, date + pd.Timedelta(days=1)}
    parts=[]
    if not calls.empty:
        # gerber calls = contact hits alias or phone
        alias_hits = [a.lower() for a in settings.aliases]
        cg = calls[calls["Date"].isin(win)].copy()
        if not cg.empty:
            # if Contact has "Gerber" etc
            hit = cg[cg["Contact"].astype(str).str.lower().apply(lambda x: any(a in x for a in alias_hits))]
            if not hit.empty:
                mins = pd.to_numeric(hit["Minutes"], errors="coerce").sum()
                parts.append(f"Client calls ±1d: {len(hit)} calls, {mins:.0f} min")
            else:
                parts.append(f"Calls ±1d: {len(cg)} calls")
    if not calendar.empty:
        ce = calendar[calendar["Date"].isin(win)]
        if len(ce)>0:
            subj="; ".join(ce["Subject"].astype(str).head(3))
            parts.append(f"Calendar ±1d: {len(ce)} events (e.g., {subj})")
    return " | ".join(parts)


def split_long_entry(date: pd.Timestamp, hours: float, rate: float) -> pd.DataFrame:
    if hours < 6:
        return pd.DataFrame()
    n=int(np.clip(round(hours/2.0),2,5))
    base=round(hours/n,2)
    splits=[base]*n
    diff=round(hours - sum(splits),2)
    i=0
    while abs(diff) >= 0.01 and i < 200:
        idx=i % n
        adj=0.01 if diff>0 else -0.01
        splits[idx]=round(splits[idx]+adj,2)
        diff=round(hours - sum(splits),2)
        i+=1
    rows=[]
    labels=["Draft/revise sections","Review/edit for filing","Finalize/compile exhibits","Prepare e-filing package","Client update/coordination"][:n]
    for k,sh in enumerate(splits):
        rows.append({
            "Date": date,
            "Hours": sh,
            "Rate": rate,
            "Amount": round(sh*rate,2),
            "Narrative": f"{labels[k]} (split from {hours:.2f}h entry)",
        })
    return pd.DataFrame(rows)


def run_pipeline(settings: Settings, input_files: List[Path], workdir: Path, outdir: Path) -> Dict[str, Path]:
    outdir.mkdir(parents=True, exist_ok=True)

    files = load_files(input_files, workdir)
    cats = parse_tables(files)

    calls = normalize_calls(cats["calls"])
    cal = normalize_calendar(cats["calendar"])
    time_entries = normalize_time_entries(cats["time"], settings.hourly_rate)

    # Date range filter
    start = pd.to_datetime(settings.start_date).normalize()
    end = pd.to_datetime(settings.end_date).normalize()
    time_entries = time_entries[(time_entries["Date"]>=start) & (time_entries["Date"]<=end)].copy()

    # Client filter + confidence
    def _row_text(r):
        return f"{r.get('Narrative','')} {r.get('Evidence','')} {r.get('Source','')}"
    time_entries["Confidence"] = time_entries.apply(lambda r: classify_confidence(_row_text(r), settings.aliases, settings.key_parties, settings.phones), axis=1)

    # Keep High + Medium by default; Low goes to review later
    time_entries = time_entries[time_entries["Confidence"].isin(["High","Medium"])].copy()

    # Flags
    time_entries["Flag Missing Evidence"] = time_entries["Evidence"].astype(str).str.strip().eq("") | time_entries["Evidence"].isna()
    time_entries["Flag Very Long"] = time_entries["Hours"] >= settings.long_entry_hours_threshold
    time_entries["Flag Medium"] = time_entries["Confidence"].eq("Medium")

    # Suggested evidence
    time_entries["Evidence Suggested"] = time_entries["Date"].apply(lambda d: evidence_suggest(d, calls, cal, settings))

    # Clio narrative
    time_entries["Clio Narrative"] = time_entries.apply(lambda r: craft_clio_narrative(r["Narrative"], r["Evidence"], settings), axis=1)

    # Daily totals
    daily = time_entries.groupby(time_entries["Date"].dt.strftime("%Y-%m-%d")).agg(
        Entries=("Hours","size"),
        Hours=("Hours","sum"),
        Amount=("Amount","sum"),
        MissingEvidence=("Flag Missing Evidence","sum"),
        VeryLong=("Flag Very Long","sum"),
        Medium=("Flag Medium","sum"),
    ).reset_index().rename(columns={"Date":"Date"}).sort_values("Hours", ascending=False)
    days_over = daily[daily["Hours"] > settings.day_hours_threshold].copy()

    # Split alternatives
    split_rows=[]
    for _,r in time_entries[time_entries["Flag Very Long"]].iterrows():
        sd = split_long_entry(r["Date"], float(r["Hours"]), float(r["Rate"]))
        if not sd.empty:
            sd["Source"] = r["Source"]
            sd["Evidence Suggested"] = r["Evidence Suggested"]
            sd["Original Clio Narrative"] = r["Clio Narrative"]
            split_rows.append(sd)
    splits = pd.concat(split_rows, ignore_index=True) if split_rows else pd.DataFrame()

    # Export
    stamp = f"{settings.client_name.replace(' ','_')}_{settings.start_date}_to_{settings.end_date}"
    xlsx_path = outdir / f"{stamp}_ClioReady.xlsx"
    csv_path = outdir / f"{stamp}_Paste.csv"

    paste = time_entries[["Date","Hours","Rate","Amount","Clio Narrative","Evidence","Evidence Suggested","Confidence","Source"]].copy()
    paste["Date"]=paste["Date"].dt.strftime("%Y-%m-%d")
    paste.to_csv(csv_path, index=False)

    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as w:
        time_entries.to_excel(w, sheet_name="Clio-ready (as-is)", index=False)
        daily.to_excel(w, sheet_name="Daily Totals", index=False)
        days_over.to_excel(w, sheet_name="Days Over Threshold", index=False)
        splits.to_excel(w, sheet_name="Split Alternatives", index=False)
        calls.to_excel(w, sheet_name="Calls (normalized)", index=False)
        cal.to_excel(w, sheet_name="Calendar (normalized)", index=False)

    return {"xlsx": xlsx_path, "csv": csv_path}

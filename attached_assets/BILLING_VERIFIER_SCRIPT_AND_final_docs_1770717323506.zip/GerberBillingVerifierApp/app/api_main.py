from fastapi import FastAPI, UploadFile, File, Form
from pathlib import Path
import tempfile

from app.pipeline import Settings, run_pipeline

app = FastAPI(title="Billing Verifier API", version="0.1.0")

@app.post("/run")
async def run(
    client_name: str = Form(...),
    aliases: str = Form(""),
    phones: str = Form(""),
    key_parties: str = Form(""),
    start_date: str = Form(...),
    end_date: str = Form(...),
    hourly_rate: float = Form(850.0),
    long_entry_hours_threshold: float = Form(6.0),
    day_hours_threshold: float = Form(10.0),
    files: list[UploadFile] = File(...),
):
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        in_files=[]
        for f in files:
            fp = td / f.filename
            fp.write_bytes(await f.read())
            in_files.append(fp)

        settings = Settings(
            client_name=client_name,
            aliases=[a.strip() for a in aliases.splitlines() if a.strip()],
            phones=[p.strip() for p in phones.splitlines() if p.strip()],
            key_parties=[k.strip() for k in key_parties.splitlines() if k.strip()],
            start_date=start_date,
            end_date=end_date,
            hourly_rate=hourly_rate,
            long_entry_hours_threshold=long_entry_hours_threshold,
            day_hours_threshold=day_hours_threshold,
        )
        out = run_pipeline(settings, in_files, workdir=td/"work", outdir=td/"out")
        # In a real deployment you'd stream files or store them; this returns names only
        return {"xlsx": out["xlsx"].name, "csv": out["csv"].name}

/**
 * VERICASE Billing Module — Main Application Entry
 * 
 * Wires together: State, Settings, Parsers, Pipeline, UI, Export, Integrations
 * Handles DOM events via delegation, manages file uploads, and orchestrates
 * the billing verification pipeline.
 */

import { State } from './modules/state.js';
import { Settings } from './modules/settings.js';
import { Pipeline } from './modules/pipeline.js';
import { UI } from './modules/ui.js';
import { Export } from './modules/export.js';
import { Integrations } from './modules/integrations.js';
import { Utils } from './modules/utils.js';

// ============================================
// PIPELINE ACTIONS
// ============================================

async function runPipeline() {
  UI.showLoading(true);
  try {
    await Pipeline.run();
    UI.render();
    UI.showLoading(false);
    UI.showToast('Pipeline completed successfully!', 'success');
  } catch (err) {
    console.error(err);
    UI.showLoading(false);
    UI.showToast('Error processing files: ' + err.message, 'error');
  }
}

function clearFiles() {
  State.files = [];
  document.getElementById('fileList').innerHTML = '';
  document.getElementById('runPipelineBtn').disabled = true;
  document.getElementById('resultsSection').classList.add('hidden');
}

// ============================================
// REVIEW ACTIONS
// ============================================

function toggleConfirm(idx) {
  const entry = State.timeEntries[idx];
  if (!entry) return;
  entry.reviewStatus = entry.reviewStatus === 'confirmed' ? 'pending' : 'confirmed';
  State.reviewLog.push({
    timestamp: new Date().toISOString(),
    action: entry.reviewStatus === 'confirmed' ? 'confirm' : 'unconfirm',
    eventId: entry.eventId
  });
  UI.renderEntriesTable();
  UI.renderFlaggedTable();
  UI.showToast(entry.reviewStatus === 'confirmed' ? 'Entry confirmed' : 'Entry unmarked');
}

function openReview(idx) {
  State.currentReviewEntry = idx;
  const entry = State.timeEntries[idx];
  if (!entry) return;

  document.getElementById('reviewModalBody').innerHTML = `
    <div class="form-group"><label class="form-label">Date</label><input type="text" class="form-input" value="${entry.date}" disabled></div>
    <div class="form-group"><label class="form-label">Hours</label><input type="number" class="form-input" id="reviewHours" value="${entry.hours}" step="0.1"></div>
    <div class="form-group"><label class="form-label">Clio Narrative</label><textarea class="form-textarea" id="reviewNarrative">${Utils.escapeHtml(entry.clioNarrative)}</textarea></div>
    <div class="form-group"><label class="form-label">Evidence (attach reference)</label><textarea class="form-textarea" id="reviewEvidence">${Utils.escapeHtml(entry.evidenceRaw)}</textarea></div>
    <div class="form-group"><label class="form-label">Evidence Suggested</label><p class="text-sm text-muted">${entry.evidenceSuggested || 'None'}</p></div>
    <div class="form-group"><label class="form-label">Notes</label><textarea class="form-textarea" id="reviewNotes">${Utils.escapeHtml(entry.notes || '')}</textarea></div>
  `;
  document.getElementById('reviewModal').classList.add('active');
}

function closeModal() {
  document.getElementById('reviewModal').classList.remove('active');
}

function saveReview() {
  const idx = State.currentReviewEntry;
  if (idx == null) return;
  const entry = State.timeEntries[idx];
  if (!entry) return;

  const prev = { hours: entry.hours, clioNarrative: entry.clioNarrative, evidenceRaw: entry.evidenceRaw };
  entry.hours = parseFloat(document.getElementById('reviewHours').value) || entry.hours;
  entry.amount = entry.hours * entry.rate;
  entry.clioNarrative = document.getElementById('reviewNarrative').value;
  entry.evidenceRaw = document.getElementById('reviewEvidence').value;
  entry.notes = document.getElementById('reviewNotes').value;

  State.reviewLog.push({
    timestamp: new Date().toISOString(),
    action: 'edit',
    eventId: entry.eventId,
    previous: prev,
    new: { hours: entry.hours, clioNarrative: entry.clioNarrative, evidenceRaw: entry.evidenceRaw }
  });

  closeModal();
  UI.render();
  UI.showToast('Entry updated');
}

function acceptSplit(idx) {
  if (State.splits[idx]) { State.splits[idx].accepted = true; UI.renderSplitsTable(); UI.showToast('Split accepted'); }
}

function rejectSplit(idx) {
  if (State.splits[idx]) { State.splits[idx].accepted = false; UI.renderSplitsTable(); UI.showToast('Keeping original entry'); }
}

function dismissQualityIssue(idx) {
  State.qualityIssues.splice(idx, 1);
  UI.renderQualityTable();
  UI.renderStats();
  UI.showToast('Issue dismissed');
}

function toggleWriteOff(idx) {
  const adj = State.adjustments[idx];
  if (adj) { adj.writeOff = !adj.writeOff; UI.renderAdjustmentsTable(); UI.renderStats(); }
}

function editAdjustment(idx) {
  const adj = State.adjustments[idx];
  if (!adj) return;
  const newHours = prompt('Enter adjusted hours:', adj.adjustedHours.toFixed(2));
  if (newHours !== null) {
    const h = parseFloat(newHours);
    if (!isNaN(h) && h >= 0) {
      adj.adjustedHours = h;
      adj.adjustedAmount = h * adj.rate;
      adj.adjustmentReason = 'Manual adjustment';
      UI.renderAdjustmentsTable();
      UI.showToast('Hours adjusted');
    }
  }
}

function applyRounding() {
  const settings = Settings.get();
  State.adjustments = Pipeline.applyRounding(State.timeEntries, settings);
  UI.renderAdjustmentsTable();
  UI.showToast('Rounding rules applied', 'success');
}

// ============================================
// SEARCH FILTERS
// ============================================

function filterEntries() {
  const q = document.getElementById('searchEntries')?.value.toLowerCase() || '';
  if (!q) { UI._renderFilteredEntries(State.timeEntries); return; }
  UI._renderFilteredEntries(State.timeEntries.filter(e =>
    e.date.includes(q) || e.clioNarrative.toLowerCase().includes(q) ||
    e.evidenceRaw.toLowerCase().includes(q) || e.source.toLowerCase().includes(q)
  ));
}

function filterCalls() {
  const q = document.getElementById('searchCalls')?.value.toLowerCase() || '';
  if (!q) { UI._renderFilteredCalls(State.calls); return; }
  UI._renderFilteredCalls(State.calls.filter(c => c.contact.toLowerCase().includes(q) || c.date.includes(q)));
}

// ============================================
// PROFILE SAVE/LOAD
// ============================================

async function saveProfile() {
  const settings = Settings.get();
  // Save to server
  try {
    await Integrations.saveProfile(settings);
    UI.showToast('Profile saved to server', 'success');
  } catch {
    // Fallback: download as JSON
    const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `${settings.clientName.replace(/\s+/g, '_')}_Profile.json`;
    a.click(); URL.revokeObjectURL(a.href);
    UI.showToast('Profile downloaded (server unavailable)', 'success');
  }
}

function loadProfile() {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = '.json';
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        Settings.set(JSON.parse(evt.target.result));
        UI.showToast('Profile loaded', 'success');
      } catch { UI.showToast('Invalid profile file', 'error'); }
    };
    reader.readAsText(file);
  };
  input.click();
}

// ============================================
// INTEGRATION SYNC
// ============================================

async function syncToIntegrations() {
  const settings = Settings.get();
  const summary = {
    clientName: settings.clientName,
    totalEntries: State.timeEntries.length,
    totalHours: State.timeEntries.reduce((s, e) => s + e.hours, 0),
    totalAmount: State.timeEntries.reduce((s, e) => s + e.amount, 0),
    flaggedCount: State.timeEntries.filter(e => e.flags.length > 0).length,
    dateRange: `${settings.startDate} → ${settings.endDate}`
  };

  try {
    await Integrations.syncResults(settings.clientName, State.timeEntries, summary, settings);
    UI.showToast('Results synced to server', 'success');
  } catch (err) {
    UI.showToast('Sync failed: ' + err.message, 'error');
  }
}

async function pushToClio() {
  try {
    const confirmed = State.timeEntries.filter(e => e.reviewStatus === 'confirmed');
    if (confirmed.length === 0) { UI.showToast('No confirmed entries to push', 'error'); return; }
    const result = await Integrations.clioPushEntries(confirmed);
    UI.showToast(`Pushed ${result.created} entries to Clio`, 'success');
  } catch (err) {
    UI.showToast('Clio push failed: ' + err.message, 'error');
  }
}

async function syncToMonday() {
  const settings = Settings.get();
  const summary = {
    clientName: settings.clientName,
    totalHours: State.timeEntries.reduce((s, e) => s + e.hours, 0),
    totalAmount: State.timeEntries.reduce((s, e) => s + e.amount, 0)
  };
  try {
    await Integrations.mondaySyncBilling(settings.clientName, summary, State.timeEntries);
    UI.showToast('Synced to Monday.com board', 'success');
  } catch (err) {
    UI.showToast('Monday sync failed: ' + err.message, 'error');
  }
}

// ============================================
// FILE HANDLING
// ============================================

function handleFiles(files) {
  for (const file of files) {
    const ext = file.name.split('.').pop().toLowerCase();
    if (['csv', 'xlsx', 'xls', 'zip'].includes(ext)) State.files.push(file);
  }
  renderFileList();
}

function renderFileList() {
  const list = document.getElementById('fileList');
  if (!list) return;
  list.innerHTML = State.files.map((f, i) => `
    <div class="file-item">
      <span class="file-item-name">📄 ${f.name}</span>
      <span class="file-item-remove" data-action="removeFile" data-idx="${i}">✕</span>
    </div>
  `).join('');
  const btn = document.getElementById('runPipelineBtn');
  if (btn) btn.disabled = State.files.length === 0;
}

function removeFile(idx) {
  State.files.splice(idx, 1);
  renderFileList();
}

// ============================================
// EVENT DELEGATION — single listener for all actions
// ============================================

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;

  const action = btn.dataset.action;
  const idx = parseInt(btn.dataset.idx);

  switch (action) {
    case 'toggleConfirm': toggleConfirm(idx); break;
    case 'openReview': openReview(idx); break;
    case 'acceptSplit': acceptSplit(idx); break;
    case 'rejectSplit': rejectSplit(idx); break;
    case 'dismissQuality': dismissQualityIssue(idx); break;
    case 'toggleWriteOff': toggleWriteOff(idx); break;
    case 'editAdjustment': editAdjustment(idx); break;
    case 'removeFile': removeFile(idx); break;
  }
});

// ============================================
// GLOBAL FUNCTION BINDINGS (for onclick in HTML)
// ============================================

window.runPipeline = runPipeline;
window.clearFiles = clearFiles;
window.saveProfile = saveProfile;
window.loadProfile = loadProfile;
window.closeModal = closeModal;
window.saveReview = saveReview;
window.applyRounding = applyRounding;
window.filterEntries = filterEntries;
window.filterCalls = filterCalls;
window.syncToIntegrations = syncToIntegrations;
window.pushToClio = pushToClio;
window.syncToMonday = syncToMonday;

// Exports
window.exportPDF = () => { Export.toPDF(); UI.showToast('PDF downloaded', 'success'); };
window.exportExcel = () => { Export.toExcel(); UI.showToast('Excel downloaded', 'success'); };
window.exportCSV = () => { Export.toCSV(); UI.showToast('CSV downloaded', 'success'); };
window.exportReviewLog = () => { Export.toReviewLog(); UI.showToast('Review log downloaded', 'success'); };

// ============================================
// INITIALIZATION
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');

  if (dropZone) {
    dropZone.addEventListener('click', () => fileInput?.click());
    dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('drag-over'); });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
    dropZone.addEventListener('drop', (e) => { e.preventDefault(); dropZone.classList.remove('drag-over'); handleFiles(e.dataTransfer.files); });
  }

  if (fileInput) {
    fileInput.addEventListener('change', (e) => handleFiles(e.target.files));
  }

  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`)?.classList.add('active');
    });
  });

  // Check integration status on load
  Integrations.getStatus().then(status => {
    const el = document.getElementById('integrationStatus');
    if (el) {
      const badges = [];
      if (status.clio?.connected) badges.push('<span class="badge badge-high">Clio ✓</span>');
      if (status.monday?.configured) badges.push('<span class="badge badge-medium">Monday ✓</span>');
      if (status.hubspot?.configured) badges.push('<span class="badge badge-medium">HubSpot ✓</span>');
      el.innerHTML = badges.length ? badges.join(' ') : '<span class="text-muted">No integrations connected</span>';
    }
  }).catch(() => {});

  console.log('🧾 VERICASE Billing Module initialized');
});

/**
 * UI Module — Rendering, tab switching, review actions
 */

import { State } from './state.js';
import { Settings } from './settings.js';
import { Utils } from './utils.js';

export const UI = {
  render() {
    document.getElementById('resultsSection').classList.remove('hidden');
    this.renderStats();
    this.renderDailyTable();
    this.renderEntriesTable();
    this.renderFlaggedTable();
    this.renderQualityTable();
    this.renderAdjustmentsTable();
    this.renderSplitsTable();
    this.renderCallsTable();
  },

  renderStats() {
    const settings = Settings.get();
    const totalHours = State.timeEntries.reduce((s, e) => s + e.hours, 0);
    const totalAmount = State.timeEntries.reduce((s, e) => s + e.amount, 0);
    const flagged = State.timeEntries.filter(e => e.flags.length > 0).length;
    const daysOver = State.dailySummary.filter(d => d.overThreshold).length;
    const quality = State.qualityIssues.length;
    const adjTotal = State.adjustments.reduce((s, a) => a.writeOff ? s : s + a.adjustedAmount, 0);

    document.getElementById('statsGrid').innerHTML = `
      <div class="stat-card success"><div class="stat-label">Total Entries</div><div class="stat-value">${State.timeEntries.length}</div></div>
      <div class="stat-card success"><div class="stat-label">Total Hours</div><div class="stat-value">${totalHours.toFixed(1)}</div></div>
      <div class="stat-card success"><div class="stat-label">Total Billable</div><div class="stat-value">${Utils.formatCurrency(adjTotal || totalAmount)}</div></div>
      <div class="stat-card ${flagged > 0 ? 'warning' : ''}"><div class="stat-label">Flagged Items</div><div class="stat-value">${flagged}</div></div>
      <div class="stat-card ${quality > 0 ? 'warning' : ''}"><div class="stat-label">Quality Issues</div><div class="stat-value">${quality}</div></div>
      <div class="stat-card ${daysOver > 0 ? 'danger' : ''}"><div class="stat-label">Days Over ${settings.dayThreshold}h</div><div class="stat-value">${daysOver}</div></div>
    `;
  },

  renderDailyTable() {
    const tbody = document.querySelector('#dailyTable tbody');
    if (!tbody) return;
    tbody.innerHTML = State.dailySummary.map(d => `
      <tr class="${d.overThreshold ? 'row-danger' : ''}">
        <td>${d.date}</td><td>${d.entries}</td><td>${d.hours.toFixed(2)}</td>
        <td>${Utils.formatCurrency(d.amount)}</td>
        <td>${d.flagCount > 0 ? `<span class="badge badge-flag">${d.flagCount} flags</span>` : '—'}</td>
      </tr>
    `).join('');
  },

  renderEntriesTable() {
    this._entriesData = State.timeEntries;
    this._renderFilteredEntries(this._entriesData);
  },

  _renderFilteredEntries(entries) {
    const tbody = document.querySelector('#entriesTable tbody');
    if (!tbody) return;
    tbody.innerHTML = entries.map((e) => {
      const idx = State.timeEntries.indexOf(e);
      return `<tr>
        <td>${e.date}</td><td>${e.hours.toFixed(2)}</td>
        <td class="text-truncate" title="${Utils.escapeHtml(e.clioNarrative)}">${Utils.truncate(e.clioNarrative, 60)}</td>
        <td class="text-truncate">${Utils.truncate(e.evidenceRaw, 40)}</td>
        <td><span class="badge badge-${e.confidence.toLowerCase()}">${e.confidence}</span></td>
        <td><div class="review-actions">
          <button class="review-btn ${e.reviewStatus === 'confirmed' ? 'confirmed' : ''}" data-action="toggleConfirm" data-idx="${idx}">
            ${e.reviewStatus === 'confirmed' ? '✓ Confirmed' : 'Confirm'}
          </button>
          <button class="review-btn" data-action="openReview" data-idx="${idx}">Edit</button>
        </div></td>
      </tr>`;
    }).join('');
  },

  renderFlaggedTable() {
    const flagged = State.timeEntries.filter(e => e.flags.length > 0);
    const tbody = document.querySelector('#flaggedTable tbody');
    if (!tbody) return;
    tbody.innerHTML = flagged.map(e => {
      const idx = State.timeEntries.indexOf(e);
      return `<tr>
        <td>${e.date}</td><td>${e.hours.toFixed(2)}</td>
        <td>${e.flags.map(f => `<span class="badge badge-flag">${f}</span>`).join(' ')}</td>
        <td class="text-truncate">${Utils.truncate(e.clioNarrative, 50)}</td>
        <td class="text-truncate">${Utils.truncate(e.evidenceSuggested, 60)}</td>
        <td><button class="review-btn" data-action="openReview" data-idx="${idx}">Review</button></td>
      </tr>`;
    }).join('');
  },

  renderSplitsTable() {
    const tbody = document.querySelector('#splitsTable tbody');
    if (!tbody) return;
    tbody.innerHTML = State.splits.map((s, i) => `<tr>
      <td>${s.originalEntry.date}</td><td>${s.originalEntry.hours.toFixed(2)}h</td>
      <td><small>${s.splitEntries.map(se => `${se.hours}h: ${Utils.truncate(se.narrative, 40)}`).join('<br>')}</small></td>
      <td><div class="review-actions">
        <button class="review-btn ${s.accepted ? 'confirmed' : ''}" data-action="acceptSplit" data-idx="${i}">
          ${s.accepted ? '✓ Using Split' : 'Use Split'}
        </button>
        <button class="review-btn" data-action="rejectSplit" data-idx="${i}">Keep Original</button>
      </div></td>
    </tr>`).join('');
  },

  renderQualityTable() {
    const tbody = document.querySelector('#qualityTable tbody');
    if (!tbody) return;
    tbody.innerHTML = State.qualityIssues.map((q, i) => {
      const idx = State.timeEntries.indexOf(q.entry);
      const bc = q.type === 'blockBilling' ? 'danger' : q.type === 'travel' ? 'medium' : 'flag';
      return `<tr>
        <td>${q.entry.date}</td><td>${q.entry.hours.toFixed(2)}</td>
        <td><span class="badge badge-${bc}">${q.issue}</span></td>
        <td class="text-truncate">${Utils.truncate(q.entry.clioNarrative || q.entry.narrativeRaw, 50)}</td>
        <td class="text-sm text-muted">${q.suggestion}</td>
        <td><div class="review-actions">
          <button class="review-btn" data-action="openReview" data-idx="${idx}">Edit</button>
          <button class="review-btn" data-action="dismissQuality" data-idx="${i}">Dismiss</button>
        </div></td>
      </tr>`;
    }).join('');
  },

  renderAdjustmentsTable() {
    const settings = Settings.get();
    const tbody = document.querySelector('#adjustmentsTable tbody');
    if (!tbody) return;
    
    const origTotal = State.adjustments.reduce((s, a) => s + a.originalAmount, 0);
    const writeOffTotal = State.adjustments.reduce((s, a) => a.writeOff ? s + a.adjustedAmount : s, 0);
    const adjTotal = State.adjustments.reduce((s, a) => a.writeOff ? s : s + a.adjustedAmount, 0);

    const summaryEl = document.getElementById('adjustmentsSummary');
    if (summaryEl) {
      summaryEl.innerHTML = `Original: ${Utils.formatCurrency(origTotal)} | Write-offs: ${Utils.formatCurrency(writeOffTotal)} | <strong>Adjusted: ${Utils.formatCurrency(adjTotal)}</strong>`;
    }

    tbody.innerHTML = State.adjustments.map((a, i) => `<tr class="${a.writeOff ? 'row-writeoff' : ''}">
      <td>${a.date}</td><td>${a.originalHours.toFixed(2)}</td><td>${a.adjustedHours.toFixed(2)}</td>
      <td>${Utils.formatCurrency(a.adjustedAmount)}</td>
      <td>${a.adjustmentReason || '—'}</td>
      <td><div class="review-actions">
        <button class="review-btn ${a.writeOff ? 'danger' : ''}" data-action="toggleWriteOff" data-idx="${i}">
          ${a.writeOff ? '✕ Written Off' : 'Write Off'}
        </button>
        <button class="review-btn" data-action="editAdjustment" data-idx="${i}">Edit</button>
      </div></td>
    </tr>`).join('');
  },

  renderCallsTable() {
    const tbody = document.querySelector('#callsTable tbody');
    if (!tbody) return;
    this._renderFilteredCalls(State.calls);
  },

  _renderFilteredCalls(calls) {
    const tbody = document.querySelector('#callsTable tbody');
    if (!tbody) return;
    tbody.innerHTML = calls.slice(0, 200).map(c => `<tr>
      <td>${c.date}</td><td>${c.contact}</td><td>${c.direction}</td>
      <td>${c.minutes?.toFixed(1) || 0} min</td><td class="text-muted">${c.source}</td>
    </tr>`).join('');
  },

  _renderFilteredCalendar(events) {
    const tbody = document.querySelector('#calendarTable tbody');
    if (!tbody) return;
    tbody.innerHTML = events.slice(0, 200).map(e => `<tr>
      <td>${e.date}</td><td>${e.subject}</td><td class="text-muted">${e.source}</td>
    </tr>`).join('');
  },

  showToast(message, type = '') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  },

  showLoading(show) {
    const el = document.getElementById('loadingOverlay');
    if (el) el.classList.toggle('active', show);
  }
};

/**
 * UTBMS Module — Uniform Task-Based Management System code detection
 */

export const UTBMS = {
  codes: {
    'L110': 'Fact Investigation/Development',
    'L120': 'Analysis/Strategy',
    'L130': 'Experts/Consultants',
    'L140': 'Document/File Management',
    'L150': 'Budgeting',
    'L210': 'Pleadings',
    'L220': 'Prelim Injunctions/Provisional Remedies',
    'L230': 'Court Mandated Conferences',
    'L240': 'Dispositive Motions',
    'L250': 'Other Written Motions/Submissions',
    'L310': 'Written Discovery',
    'L320': 'Document Production',
    'L330': 'Depositions',
    'L340': 'Expert Discovery',
    'L350': 'Discovery Motions',
    'L410': 'Jury Selection/Mock Trial',
    'L420': 'Trial Prep/Trial',
    'L430': 'Post-Trial Motions/Enforcement',
    'L510': 'Appeal',
    'A101': 'Plan and prepare for',
    'A102': 'Research',
    'A103': 'Draft/revise',
    'A104': 'Review/analyze',
    'A105': 'Communicate (in firm)',
    'A106': 'Communicate (with client)',
    'A107': 'Communicate (other outside counsel)',
    'A108': 'Communicate (other external)',
    'A109': 'Appear for/attend',
    'A110': 'Manage data/files',
    'A111': 'Other'
  },

  patterns: [
    [/deposition|depo/, 'L330'],
    [/trial prep|prepare.*trial/, 'L420'],
    [/trial|hearing|appear.*court/, 'L420'],
    [/motion.*dismiss|summary judgment|dispositive/, 'L240'],
    [/motion|brief|memorandum/, 'L250'],
    [/discovery|interrogator|request.*produc/, 'L310'],
    [/document.*review|review.*document|doc.*production/, 'L320'],
    [/pleading|complaint|answer|reply/, 'L210'],
    [/research|legal research|case law/, 'A102'],
    [/draft|revise|prepare|write/, 'A103'],
    [/review|analyze|analysis/, 'A104'],
    [/call|phone|conference|meet.*client|email.*client/, 'A106'],
    [/internal|staff|team/, 'A105'],
    [/file|document|organize/, 'A110'],
    [/strategy|plan|assess/, 'L120'],
    [/expert|consultant/, 'L130'],
    [/investigation|investigate|fact/, 'L110']
  ],

  detectCode(narrative) {
    const text = (narrative || '').toLowerCase();
    for (const [pattern, code] of this.patterns) {
      if (pattern.test(text)) {
        return { code, description: this.codes[code] || code };
      }
    }
    return { code: 'A111', description: 'Other' };
  }
};

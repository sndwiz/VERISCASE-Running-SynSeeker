/**
 * Integrations Client Module
 * 
 * Browser-side API calls to the server for Clio, Monday,
 * HubSpot, and chatbot integrations. All sensitive billing
 * data processing stays client-side; only summaries and
 * confirmed results are sent to server for integration sync.
 */

const API_BASE = '/api';

async function api(method, path, body = null) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API_BASE}${path}`, opts);
  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  return res.json();
}

export const Integrations = {
  // ============================================
  // STATUS
  // ============================================
  async getStatus() {
    return api('GET', '/integrations/status');
  },

  // ============================================
  // PROFILES (server-stored)
  // ============================================
  async listProfiles() { return api('GET', '/billing/profiles'); },
  async getProfile(id) { return api('GET', `/billing/profiles/${id}`); },
  async saveProfile(settings) { return api('POST', '/billing/profiles', settings); },
  async deleteProfile(id) { return api('DELETE', `/billing/profiles/${id}`); },

  // ============================================
  // REVIEW LOGS
  // ============================================
  async saveReviewLog(matterId, reviewLog, summary) {
    return api('POST', '/billing/reviews', { matterId, reviewLog, summary });
  },

  // ============================================
  // PIPELINE RESULTS → SERVER (for integration sync)
  // ============================================
  async syncResults(matterId, entries, summary, settings) {
    return api('POST', '/billing/results', { matterId, entries, summary, settings });
  },

  // ============================================
  // CLIO
  // ============================================
  async clioStatus() { return api('GET', '/integrations/clio/status'); },
  async clioMatters(query = '') { return api('GET', `/integrations/clio/matters?query=${encodeURIComponent(query)}`); },
  async clioTimeEntries(matterId, from, to) {
    return api('GET', `/integrations/clio/matters/${matterId}/entries?from=${from}&to=${to}`);
  },
  async clioPushEntries(entries) {
    return api('POST', '/integrations/clio/entries', { entries });
  },

  // ============================================
  // MONDAY.COM
  // ============================================
  async mondayBoards() { return api('GET', '/integrations/monday/boards'); },
  async mondaySyncBilling(matterId, summary, entries) {
    return api('POST', '/integrations/monday/sync', { matterId, summary, entries });
  },

  // ============================================
  // HUBSPOT
  // ============================================
  async hubspotSearchContacts(query) {
    return api('GET', `/integrations/hubspot/contacts?q=${encodeURIComponent(query)}`);
  },
  async hubspotLogActivity(contactId, dealId, matterId, summary) {
    return api('POST', '/integrations/hubspot/activity', { contactId, dealId, matterId, summary });
  }
};

/**
 * Utils Module — Shared utility functions
 */

export const Utils = {
  standardizePhone(s) {
    if (!s) return '';
    const digits = String(s).replace(/\D/g, '');
    return digits.length > 10 ? digits.slice(-10) : digits;
  },

  containsAny(haystack, needles) {
    const h = (haystack || '').toLowerCase();
    return needles.some(n => n && h.includes(n.toLowerCase()));
  },

  formatDate(d) {
    if (!d) return '';
    if (typeof d === 'string') return d.slice(0, 10);
    if (d instanceof Date) return d.toISOString().slice(0, 10);
    return '';
  },

  formatCurrency(n) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n || 0);
  },

  generateHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(36);
  },

  truncate(str, len = 100) {
    if (!str) return '';
    return str.length > len ? str.slice(0, len) + '...' : str;
  },

  escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  },

  debounce(fn, ms = 300) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  }
};

/**
 * Pipeline Module — Core billing verification engine
 * 
 * Normalizes, classifies, flags, and generates narratives
 * for legal time entries. All processing is client-side.
 */

import { State } from './state.js';
import { Settings } from './settings.js';
import { Utils } from './utils.js';
import { UTBMS } from './utbms.js';
import { Parsers } from './parsers.js';

export const Pipeline = {
  async run() {
    const settings = Settings.get();

    // 1. Parse all uploaded files
    const allParsed = [];
    for (const file of State.files) {
      const parsed = await Parsers.parseFile(file);
      allParsed.push(...parsed);
    }

    // 2. Categorize by type
    const categories = { time: [], calls: [], calendar: [], docs: [] };
    for (const p of allParsed) {
      (categories[p.type] || categories.time).push(p);
    }

    // 3. Normalize each category
    State.calls = this.normalizeCalls(categories.calls);
    State.calendar = this.normalizeCalendar(categories.calendar);
    State.timeEntries = this.normalizeTimeEntries(categories.time, settings);

    // 4. Date-range filter
    const start = new Date(settings.startDate);
    const end = new Date(settings.endDate);
    State.timeEntries = State.timeEntries.filter(e => {
      const d = new Date(e.date);
      return d >= start && d <= end;
    });

    // 5. Classify, flag, suggest evidence, generate narratives
    State.timeEntries = State.timeEntries.map(e => {
      e.confidence = this.classifyConfidence(e, settings);
      e.flags = this.computeFlags(e, settings);
      e.evidenceSuggested = this.suggestEvidence(e, settings);
      e.clioNarrative = this.craftNarrative(e, settings);
      e.eventId = Utils.generateHash(`${e.date}-${e.hours}-${e.narrativeRaw}`);
      e.reviewStatus = 'pending';
      return e;
    });

    // 6. Filter out Low confidence (keep High + Medium)
    State.timeEntries = State.timeEntries.filter(e => e.confidence !== 'Low');

    // 7. Daily summaries
    State.dailySummary = this.computeDailySummary(settings);

    // 8. Split alternatives for long entries
    State.splits = this.generateSplits(settings);

    // 9. Quality checks
    State.qualityIssues = this.checkQuality(State.timeEntries);

    // 10. Rounding & adjustments
    State.adjustments = this.applyRounding(State.timeEntries, settings);

    // 11. UTBMS codes
    State.timeEntries = State.timeEntries.map(e => {
      const utbms = UTBMS.detectCode(e.clioNarrative || e.narrativeRaw);
      return { ...e, utbmsCode: utbms.code, utbmsDesc: utbms.description };
    });

    // Emit completion event
    State.emit('pipeline.complete', {
      totalEntries: State.timeEntries.length,
      totalHours: State.timeEntries.reduce((s, e) => s + e.hours, 0),
      totalAmount: State.timeEntries.reduce((s, e) => s + e.amount, 0),
      flaggedCount: State.timeEntries.filter(e => e.flags.length > 0).length
    });
  },

  // ============================================
  // NORMALIZERS
  // ============================================

  normalizeCalls(parsed) {
    const calls = [];
    for (const { source, data } of parsed) {
      for (const row of data) {
        const ts = this.findTimestamp(row);
        if (!ts) continue;
        calls.push({
          timestamp: ts,
          date: Utils.formatDate(ts),
          contact: row.Contact || row.contact || '',
          direction: row.Direction || row['Incoming/Outgoing'] || row.direction || '',
          minutes: parseFloat(row.Minutes || row.minutes || row.Duration || 0),
          source
        });
      }
    }
    return calls.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  },

  normalizeCalendar(parsed) {
    const events = [];
    for (const { source, data } of parsed) {
      for (const row of data) {
        const start = this.findTimestamp(row, ['Start', 'start', 'Begin', 'begin', 'Event Start']);
        if (!start) continue;
        events.push({
          start,
          date: Utils.formatDate(start),
          subject: row.Subject || row.subject || row.Title || row.title || '',
          source
        });
      }
    }
    return events.sort((a, b) => new Date(a.start) - new Date(b.start));
  },

  normalizeTimeEntries(parsed, settings) {
    const entries = [];
    for (const { source, data } of parsed) {
      for (const row of data) {
        const date = this.findDate(row);
        const hours = parseFloat(row.Hours || row.hours || row.Duration || row.duration || 0);
        if (!date || hours <= 0) continue;

        entries.push({
          date: Utils.formatDate(date),
          hours,
          rate: settings.hourlyRate,
          amount: hours * settings.hourlyRate,
          narrativeRaw: row.Narrative || row.narrative || row.Description || row.description || '',
          evidenceRaw: row.Evidence || row.evidence || row['Evidence (short)'] || '',
          source,
          confidence: 'Low',
          flags: [],
          evidenceSuggested: '',
          clioNarrative: '',
          eventId: '',
          reviewStatus: 'pending',
          notes: ''
        });
      }
    }
    return entries;
  },

  // ============================================
  // FIELD FINDERS
  // ============================================

  findTimestamp(row, keys = ['Timestamp', 'timestamp', 'Date/Time', 'date/time', 'Date', 'date', 'Time', 'time']) {
    for (const k of keys) {
      if (row[k]) { const d = new Date(row[k]); if (!isNaN(d.getTime())) return d; }
    }
    if (row.Date && row.Time) {
      const d = new Date(`${row.Date} ${row.Time}`);
      if (!isNaN(d.getTime())) return d;
    }
    return null;
  },

  findDate(row) {
    for (const k of ['Date', 'date', 'Day', 'day', 'Work Date']) {
      if (row[k]) { const d = new Date(row[k]); if (!isNaN(d.getTime())) return d; }
    }
    return null;
  },

  // ============================================
  // CLASSIFICATION
  // ============================================

  classifyConfidence(entry, settings) {
    const text = `${entry.narrativeRaw} ${entry.evidenceRaw} ${entry.source}`.toLowerCase();
    const aliasLower = settings.aliases.map(a => a.toLowerCase());
    const phonesNorm = settings.phones.map(p => Utils.standardizePhone(p));
    const keyLower = settings.keyParties.map(k => k.toLowerCase());

    if (Utils.containsAny(text, aliasLower)) return 'High';
    for (const p of phonesNorm) { if (p && text.includes(p)) return 'High'; }
    if (Utils.containsAny(text, keyLower)) return 'Medium';
    return 'Low';
  },

  computeFlags(entry, settings) {
    const flags = [];
    if (!entry.evidenceRaw || entry.evidenceRaw.trim() === '' || entry.evidenceRaw === 'nan') flags.push('missingEvidence');
    if (entry.hours >= settings.longThreshold) flags.push('veryLong');
    if (entry.confidence === 'Medium') flags.push('mediumConfidence');
    return flags;
  },

  // ============================================
  // EVIDENCE SUGGESTIONS
  // ============================================

  suggestEvidence(entry, settings) {
    const d = new Date(entry.date);
    const dayBefore = new Date(d); dayBefore.setDate(d.getDate() - 1);
    const dayAfter = new Date(d); dayAfter.setDate(d.getDate() + 1);
    const window = [Utils.formatDate(dayBefore), Utils.formatDate(d), Utils.formatDate(dayAfter)];
    const parts = [];
    const aliasLower = settings.aliases.map(a => a.toLowerCase());

    const windowCalls = State.calls.filter(c => window.includes(c.date));
    if (windowCalls.length > 0) {
      const clientCalls = windowCalls.filter(c => Utils.containsAny(c.contact, aliasLower));
      if (clientCalls.length > 0) {
        const mins = clientCalls.reduce((sum, c) => sum + (c.minutes || 0), 0);
        parts.push(`Client calls ±1d: ${clientCalls.length} calls, ${Math.round(mins)} min`);
      } else {
        parts.push(`Calls ±1d: ${windowCalls.length} calls`);
      }
    }

    const windowEvents = State.calendar.filter(e => window.includes(e.date));
    if (windowEvents.length > 0) {
      const subjects = windowEvents.slice(0, 2).map(e => Utils.truncate(e.subject, 30)).join('; ');
      parts.push(`Calendar ±1d: ${windowEvents.length} events (${subjects})`);
    }

    return parts.join(' | ');
  },

  // ============================================
  // NARRATIVE GENERATION
  // ============================================

  craftNarrative(entry, settings) {
    const text = `${entry.narrativeRaw} ${entry.evidenceRaw}`.toLowerCase();
    const docMap = [
      [/injunction|civil stalking/, 'Draft/revise civil stalking injunction'],
      [/notice of appearance/, 'Prepare/file Notice of Appearance'],
      [/return of service|proof of service|service assistance/, 'Coordinate service / prepare proof of service'],
      [/acceptance of service/, 'Prepare/file Acceptance of Service'],
      [/attorney fees/, 'Draft/revise motion re attorney fees'],
      [/extension of time/, 'Draft/revise motion re extension of time'],
      [/meet\s*&\s*confer|meet and confer/, 'Meet & confer re case issues'],
      [/research/, 'Legal research'],
      [/review|analy/, 'Review/analyze materials'],
      [/draft|revise|edit/, 'Draft/revise documents'],
      [/email/, 'Email correspondence'],
      [/call|phone|voicemail|telephone/, 'Telephone conference / call'],
    ];

    let task = 'Case work (client matter)';
    for (const [pat, label] of docMap) {
      if (pat.test(text)) { task = label; break; }
    }

    let narrative = `${task}; ${settings.clientName}`;
    if (entry.evidenceRaw && entry.evidenceRaw !== 'nan') {
      narrative += ` (${Utils.truncate(entry.evidenceRaw.replace(/\s+/g, ' ').trim(), 80)})`;
    }
    return narrative;
  },

  // ============================================
  // DAILY SUMMARY
  // ============================================

  computeDailySummary(settings) {
    const byDate = {};
    for (const e of State.timeEntries) {
      if (!byDate[e.date]) byDate[e.date] = { entries: 0, hours: 0, amount: 0, flagCount: 0 };
      byDate[e.date].entries++;
      byDate[e.date].hours += e.hours;
      byDate[e.date].amount += e.amount;
      byDate[e.date].flagCount += e.flags.length;
    }
    return Object.entries(byDate)
      .map(([date, stats]) => ({ date, ...stats, overThreshold: stats.hours > settings.dayThreshold }))
      .sort((a, b) => b.hours - a.hours);
  },

  // ============================================
  // SPLIT ALTERNATIVES
  // ============================================

  generateSplits(settings) {
    const splits = [];
    const longEntries = State.timeEntries.filter(e => e.hours >= settings.longThreshold);
    const labels = ['Draft/revise sections', 'Review/edit for filing', 'Finalize/compile exhibits', 'Prepare e-filing package', 'Client update/coordination'];

    for (const entry of longEntries) {
      const n = Math.max(2, Math.min(5, Math.round(entry.hours / 2)));
      const base = Math.floor((entry.hours / n) * 100) / 100;
      let splitHours = Array(n).fill(base);
      let diff = Math.round((entry.hours - splitHours.reduce((a, b) => a + b, 0)) * 100) / 100;
      for (let i = 0; diff > 0; i = (i + 1) % n) {
        splitHours[i] = Math.round((splitHours[i] + 0.01) * 100) / 100;
        diff = Math.round((diff - 0.01) * 100) / 100;
      }

      splits.push({
        originalEntry: entry,
        splitEntries: splitHours.map((h, i) => ({
          hours: h, rate: settings.hourlyRate, amount: h * settings.hourlyRate,
          narrative: `${labels[i % labels.length]} (split from ${entry.hours.toFixed(2)}h entry)`
        })),
        accepted: false
      });
    }
    return splits;
  },

  // ============================================
  // QUALITY CHECKS
  // ============================================

  checkQuality(entries) {
    const issues = [];
    const vaguePatterns = [
      { pattern: /^(review|reviewed)\s*(documents?|files?|materials?)\.?$/i, issue: 'Vague description', suggestion: 'Specify what documents and purpose' },
      { pattern: /^(phone call|call|telephone)\.?$/i, issue: 'Missing details', suggestion: 'Include who, duration, and topic' },
      { pattern: /^(email|emails|correspondence)\.?$/i, issue: 'Missing details', suggestion: 'Include recipient and subject' },
      { pattern: /^(research|legal research)\.?$/i, issue: 'Missing topic', suggestion: 'Specify research topic' },
      { pattern: /^(meeting|conference)\.?$/i, issue: 'Missing details', suggestion: 'Include attendees and purpose' },
      { pattern: /^(work on|worked on)\s+/i, issue: 'Vague action', suggestion: 'Use specific verbs (draft, review, analyze)' }
    ];
    const blockBilling = /;\s*\w+.*;\s*\w+.*;\s*\w+/;
    const adminPatterns = /\b(schedule|scheduling|calendar|filing|copying|scanning|fax|mailing|postage)\b/i;
    const travelPatterns = /\b(travel|driving|drove|flight|flew|airport)\b/i;

    for (const entry of entries) {
      const narrative = entry.clioNarrative || entry.narrativeRaw || '';
      for (const { pattern, issue, suggestion } of vaguePatterns) {
        if (pattern.test(narrative.trim())) { issues.push({ entry, issue, suggestion, type: 'vague' }); break; }
      }
      if (blockBilling.test(narrative)) issues.push({ entry, issue: 'Block billing detected', suggestion: 'Split into separate entries', type: 'blockBilling' });
      if (narrative.length < 20 && entry.hours >= 0.5) issues.push({ entry, issue: 'Narrative too brief', suggestion: 'Add more detail', type: 'brief' });
      if (adminPatterns.test(narrative)) issues.push({ entry, issue: 'Possible clerical task', suggestion: 'Check if should be billed at attorney rate', type: 'clerical' });
      if (travelPatterns.test(narrative)) issues.push({ entry, issue: 'Travel time detected', suggestion: 'Verify correct rate per agreement', type: 'travel' });
    }
    return issues;
  },

  // ============================================
  // ROUNDING
  // ============================================

  applyRounding(entries, settings) {
    return entries.map(e => {
      let adjusted = e.hours;
      if (settings.minimumEntry > 0 && adjusted < settings.minimumEntry) adjusted = settings.minimumEntry;
      const inc = settings.roundingIncrement;
      if (settings.roundingDirection === 'up') adjusted = Math.ceil(adjusted / inc) * inc;
      else if (settings.roundingDirection === 'down') adjusted = Math.floor(adjusted / inc) * inc;
      else adjusted = Math.round(adjusted / inc) * inc;
      adjusted = Math.round(adjusted * 100) / 100;

      return {
        ...e, originalHours: e.hours, adjustedHours: adjusted,
        originalAmount: e.hours * e.rate, adjustedAmount: adjusted * e.rate,
        adjustmentReason: adjusted !== e.hours ? 'Rounding applied' : '', writeOff: false
      };
    });
  }
};

/**
 * State Module — Centralized reactive state for the billing pipeline
 */

export const State = {
  files: [],
  timeEntries: [],
  calls: [],
  calendar: [],
  docs: [],
  dailySummary: [],
  splits: [],
  qualityIssues: [],
  adjustments: [],
  reviewLog: [],
  currentReviewEntry: null,

  // Event bus for module communication
  _listeners: {},

  on(event, callback) {
    if (!this._listeners[event]) this._listeners[event] = [];
    this._listeners[event].push(callback);
  },

  emit(event, data) {
    (this._listeners[event] || []).forEach(cb => cb(data));
  },

  reset() {
    this.files = [];
    this.timeEntries = [];
    this.calls = [];
    this.calendar = [];
    this.docs = [];
    this.dailySummary = [];
    this.splits = [];
    this.qualityIssues = [];
    this.adjustments = [];
    this.reviewLog = [];
    this.currentReviewEntry = null;
  },

  // Snapshot for integration sync
  getSnapshot() {
    return {
      timeEntries: this.timeEntries,
      calls: this.calls,
      calendar: this.calendar,
      dailySummary: this.dailySummary,
      splits: this.splits,
      qualityIssues: this.qualityIssues,
      adjustments: this.adjustments,
      reviewLog: this.reviewLog
    };
  }
};

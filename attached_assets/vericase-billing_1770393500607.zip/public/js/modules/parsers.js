/**
 * Parsers Module — File parsing for CSV, XLSX, XLS, ZIP
 * 
 * Uses PapaParse (CSV), SheetJS (XLSX), JSZip (ZIP) — loaded via vendor scripts
 */

export const Parsers = {
  async parseFile(file) {
    const name = file.name.toLowerCase();
    if (name.endsWith('.zip')) return this.parseZip(file);
    if (name.endsWith('.csv')) return this.parseCSV(file);
    if (name.endsWith('.xlsx') || name.endsWith('.xls')) return this.parseExcel(file);
    return [];
  },

  async parseZip(file) {
    const zip = await JSZip.loadAsync(file);
    const results = [];
    for (const [path, zipEntry] of Object.entries(zip.files)) {
      if (zipEntry.dir) continue;
      const name = path.toLowerCase();
      if (name.endsWith('.csv')) {
        const content = await zipEntry.async('string');
        const parsed = Papa.parse(content, { header: true, skipEmptyLines: true });
        results.push({ source: path, data: parsed.data, type: this.detectType(parsed.data) });
      } else if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
        const content = await zipEntry.async('arraybuffer');
        const workbook = XLSX.read(content, { type: 'array' });
        for (const sheetName of workbook.SheetNames) {
          const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
          results.push({ source: `${path}::${sheetName}`, data, type: this.detectType(data) });
        }
      }
    }
    return results;
  },

  async parseCSV(file) {
    return new Promise((resolve) => {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          resolve([{ source: file.name, data: results.data, type: this.detectType(results.data) }]);
        }
      });
    });
  },

  async parseExcel(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const workbook = XLSX.read(e.target.result, { type: 'array' });
        const results = [];
        for (const sheetName of workbook.SheetNames) {
          const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
          results.push({ source: `${file.name}::${sheetName}`, data, type: this.detectType(data) });
        }
        resolve(results);
      };
      reader.readAsArrayBuffer(file);
    });
  },

  detectType(data) {
    if (!data || data.length === 0) return 'unknown';
    const cols = Object.keys(data[0]).join(' ').toLowerCase();
    if (cols.includes('minutes') && (cols.includes('incoming') || cols.includes('outgoing') || cols.includes('direction'))) return 'calls';
    if (cols.includes('subject') && (cols.includes('start') || cols.includes('begin'))) return 'calendar';
    if (cols.includes('document') && (cols.includes('touches') || cols.includes('first') || cols.includes('last'))) return 'docs';
    return 'time';
  }
};

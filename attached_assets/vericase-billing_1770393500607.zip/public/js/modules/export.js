/**
 * Export Module — Generate downloadable files client-side
 * 
 * PDF invoicing, Clio-ready XLSX, paste CSV, review log JSON
 */

import { State } from './state.js';
import { Settings } from './settings.js';
import { Utils } from './utils.js';

export const Export = {
  toPDF() {
    const settings = Settings.get();
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('p', 'mm', 'letter');
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    let yPos = margin;

    const primary = [37, 99, 235], dark = [26, 31, 54], gray = [94, 98, 120], lightGray = [226, 232, 240];

    const useAdj = State.adjustments.length > 0;
    const totalHours = useAdj
      ? State.adjustments.filter(a => !a.writeOff).reduce((s, a) => s + a.adjustedHours, 0)
      : State.timeEntries.reduce((s, e) => s + e.hours, 0);
    const totalAmount = useAdj
      ? State.adjustments.filter(a => !a.writeOff).reduce((s, a) => s + a.adjustedAmount, 0)
      : State.timeEntries.reduce((s, e) => s + e.amount, 0);

    const termsText = { receipt: 'Due Upon Receipt', net15: 'Net 15 Days', net30: 'Net 30 Days', net60: 'Net 60 Days' }[settings.paymentTerms] || 'Due Upon Receipt';

    // Header
    doc.setFontSize(18); doc.setFont('helvetica', 'bold'); doc.setTextColor(...primary);
    doc.text(settings.firmName || 'Law Firm Name', margin, yPos); yPos += 8;
    doc.setFontSize(11); doc.setFont('helvetica', 'normal'); doc.setTextColor(...dark);
    doc.text(settings.attorneyName || 'Attorney Name', margin, yPos); yPos += 5;
    doc.setFontSize(9); doc.setTextColor(...gray);
    for (const line of (settings.firmAddress || '').split('\n')) { doc.text(line, margin, yPos); yPos += 4; }
    yPos += 4;
    doc.setDrawColor(...lightGray); doc.setLineWidth(0.5);
    doc.line(margin, yPos, pageWidth - margin, yPos); yPos += 12;

    // Invoice title
    const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    doc.setFontSize(10); doc.setTextColor(...gray); doc.text(today, pageWidth - margin, yPos, { align: 'right' });
    doc.setFontSize(14); doc.setFont('helvetica', 'bold'); doc.setTextColor(...dark);
    doc.text('BILLING STATEMENT', margin, yPos); yPos += 10;
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.text(`Client: ${settings.clientName}`, margin, yPos); yPos += 5;
    doc.setTextColor(...gray);
    doc.text(`Period: ${settings.startDate} to ${settings.endDate}`, margin, yPos);
    doc.text(`Terms: ${termsText}`, pageWidth - margin, yPos, { align: 'right' }); yPos += 12;

    // Greeting
    doc.setFontSize(11); doc.setTextColor(...dark);
    doc.text(`Dear ${settings.clientName},`, margin, yPos); yPos += 8;
    doc.setFontSize(10);
    const greeting = `Please find enclosed the detailed billing statement for legal services rendered during the period of ${settings.startDate} through ${settings.endDate}.`;
    const gl = doc.splitTextToSize(greeting, pageWidth - margin * 2);
    doc.text(gl, margin, yPos); yPos += gl.length * 5 + 10;

    // Summary box
    doc.setFillColor(248, 250, 252); doc.roundedRect(margin, yPos, pageWidth - margin * 2, 28, 3, 3, 'F');
    yPos += 8; doc.setFontSize(9); doc.setTextColor(...gray);
    doc.text('TOTAL ENTRIES', margin + 10, yPos); doc.text('TOTAL HOURS', margin + 55, yPos);
    doc.text('HOURLY RATE', margin + 100, yPos); doc.text('TOTAL DUE', pageWidth - margin - 40, yPos);
    yPos += 6; doc.setFontSize(12); doc.setFont('helvetica', 'bold'); doc.setTextColor(...dark);
    const cnt = useAdj ? State.adjustments.filter(a => !a.writeOff).length : State.timeEntries.length;
    doc.text(String(cnt), margin + 10, yPos); doc.text(totalHours.toFixed(1), margin + 55, yPos);
    doc.text(Utils.formatCurrency(settings.hourlyRate), margin + 100, yPos);
    doc.setTextColor(...primary); doc.text(Utils.formatCurrency(totalAmount), pageWidth - margin - 40, yPos);
    yPos += 18;

    // Table
    doc.setFont('helvetica', 'normal');
    const tableEntries = useAdj ? State.adjustments.filter(a => !a.writeOff) : State.timeEntries;
    const tableData = tableEntries.map(e => [
      e.date, (e.adjustedHours || e.hours).toFixed(2),
      Utils.truncate(e.clioNarrative || e.narrativeRaw, 70),
      Utils.formatCurrency(e.adjustedAmount || e.amount)
    ]);

    doc.autoTable({
      startY: yPos,
      head: [['Date', 'Hours', 'Description', 'Amount']],
      body: tableData,
      margin: { left: margin, right: margin },
      styles: { fontSize: 9, cellPadding: 3, textColor: dark, lineColor: lightGray, lineWidth: 0.1 },
      headStyles: { fillColor: [248, 250, 252], textColor: gray, fontStyle: 'bold', fontSize: 8 },
      columnStyles: { 0: { cellWidth: 25 }, 1: { cellWidth: 18, halign: 'right' }, 3: { cellWidth: 25, halign: 'right' } },
      alternateRowStyles: { fillColor: [252, 252, 253] },
      didDrawPage: (data) => {
        doc.setFontSize(8); doc.setTextColor(...gray);
        doc.text(`Page ${data.pageNumber}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
      }
    });

    yPos = doc.lastAutoTable.finalY + 15;
    if (yPos > pageHeight - 80) { doc.addPage(); yPos = margin; }

    // Total
    doc.setDrawColor(...lightGray); doc.line(pageWidth - margin - 60, yPos, pageWidth - margin, yPos); yPos += 6;
    doc.setFontSize(11); doc.setFont('helvetica', 'bold'); doc.setTextColor(...dark);
    doc.text('Total Amount Due:', pageWidth - margin - 60, yPos);
    doc.setTextColor(...primary); doc.text(Utils.formatCurrency(totalAmount), pageWidth - margin, yPos, { align: 'right' });
    yPos += 20;

    // Closing
    doc.setFontSize(10); doc.setFont('helvetica', 'normal'); doc.setTextColor(...dark);
    doc.text('Respectfully submitted,', margin, yPos); yPos += 15;
    doc.setFont('helvetica', 'bold'); doc.text(settings.attorneyName || '', margin, yPos);

    const filename = `${settings.clientName.replace(/\s+/g, '_')}_${settings.startDate}_to_${settings.endDate}_Invoice.pdf`;
    doc.save(filename);
  },

  toExcel() {
    const settings = Settings.get();
    const wb = XLSX.utils.book_new();

    // At a Glance
    const glance = [
      ['Billing Verifier Export'], ['Client', settings.clientName],
      ['Date Range', `${settings.startDate} to ${settings.endDate}`],
      ['Total Entries', State.timeEntries.length],
      ['Total Hours', State.timeEntries.reduce((s, e) => s + e.hours, 0).toFixed(2)],
      ['Total Amount', State.timeEntries.reduce((s, e) => s + e.amount, 0).toFixed(2)],
      ['Generated', new Date().toISOString()]
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(glance), 'At a Glance');

    // Clio-ready
    const entries = State.timeEntries.map(e => ({
      Date: e.date, Hours: e.hours, Rate: e.rate, Amount: e.amount,
      'Clio Narrative': e.clioNarrative, 'Evidence (short)': Utils.truncate(e.evidenceRaw, 200),
      'Evidence Suggested': e.evidenceSuggested, Confidence: e.confidence,
      Flags: e.flags.join(', '), 'Review Status': e.reviewStatus, Source: e.source
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(entries), 'Clio-ready (as-is)');

    // Daily / Over Threshold / Splits / Calls / Calendar
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(State.dailySummary), 'Daily Totals');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(State.dailySummary.filter(d => d.overThreshold)), 'Days Over Threshold');

    const splitsData = State.splits.flatMap(s => s.splitEntries.map(se => ({
      'Original Date': s.originalEntry.date, 'Original Hours': s.originalEntry.hours,
      'Split Hours': se.hours, 'Split Narrative': se.narrative, Accepted: s.accepted ? 'Yes' : 'No'
    })));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(splitsData), 'Split Alternatives');

    if (State.calls.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(State.calls), 'Calls (normalized)');
    if (State.calendar.length) XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(State.calendar), 'Calendar (normalized)');

    XLSX.writeFile(wb, `${settings.clientName.replace(/\s+/g, '_')}_${settings.startDate}_to_${settings.endDate}_ClioReady.xlsx`);
  },

  toCSV() {
    const settings = Settings.get();
    const data = State.timeEntries.map(e => ({
      Date: e.date, Hours: e.hours, Rate: e.rate, Amount: e.amount,
      'Clio Narrative': e.clioNarrative, 'Evidence (short)': Utils.truncate(e.evidenceRaw, 200),
      'Evidence Suggested': e.evidenceSuggested, Confidence: e.confidence,
      'Review Needed': e.flags.length > 0 ? 'YES' : 'NO', Source: e.source
    }));
    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `${settings.clientName.replace(/\s+/g, '_')}_Paste.csv`;
    a.click(); URL.revokeObjectURL(a.href);
  },

  toReviewLog() {
    const settings = Settings.get();
    const log = {
      exportedAt: new Date().toISOString(), settings, reviewLog: State.reviewLog,
      entries: State.timeEntries.map(e => ({ eventId: e.eventId, date: e.date, hours: e.hours, reviewStatus: e.reviewStatus, notes: e.notes }))
    };
    const blob = new Blob([JSON.stringify(log, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `${settings.clientName.replace(/\s+/g, '_')}_ReviewLog.json`;
    a.click(); URL.revokeObjectURL(a.href);
  }
};

/**
 * Settings Module — Matter profile configuration
 */

const FIELDS = [
  { id: 'clientName', key: 'clientName', type: 'text' },
  { id: 'aliases', key: 'aliases', type: 'lines' },
  { id: 'phones', key: 'phones', type: 'lines' },
  { id: 'keyParties', key: 'keyParties', type: 'lines' },
  { id: 'startDate', key: 'startDate', type: 'text' },
  { id: 'endDate', key: 'endDate', type: 'text' },
  { id: 'hourlyRate', key: 'hourlyRate', type: 'number', default: 850 },
  { id: 'longThreshold', key: 'longThreshold', type: 'number', default: 6 },
  { id: 'dayThreshold', key: 'dayThreshold', type: 'number', default: 10 },
  { id: 'roundingIncrement', key: 'roundingIncrement', type: 'number', default: 0.1 },
  { id: 'roundingDirection', key: 'roundingDirection', type: 'text', default: 'up' },
  { id: 'minimumEntry', key: 'minimumEntry', type: 'number', default: 0 },
  { id: 'travelTimeRate', key: 'travelTimeRate', type: 'number', default: 1 },
  { id: 'paymentTerms', key: 'paymentTerms', type: 'text', default: 'receipt' },
  { id: 'retainerBalance', key: 'retainerBalance', type: 'number', default: 0 },
  { id: 'firmName', key: 'firmName', type: 'text' },
  { id: 'attorneyName', key: 'attorneyName', type: 'text' },
  { id: 'firmAddress', key: 'firmAddress', type: 'text' },
];

export const Settings = {
  get() {
    const settings = {};
    for (const f of FIELDS) {
      const el = document.getElementById(f.id);
      if (!el) { settings[f.key] = f.default || ''; continue; }
      
      if (f.type === 'lines') {
        settings[f.key] = el.value.split('\n').map(s => s.trim()).filter(Boolean);
      } else if (f.type === 'number') {
        settings[f.key] = parseFloat(el.value) || f.default || 0;
      } else {
        settings[f.key] = el.value.trim() || f.default || '';
      }
    }
    return settings;
  },

  set(settings) {
    for (const f of FIELDS) {
      if (settings[f.key] == null) continue;
      const el = document.getElementById(f.id);
      if (!el) continue;
      
      if (f.type === 'lines' && Array.isArray(settings[f.key])) {
        el.value = settings[f.key].join('\n');
      } else {
        el.value = settings[f.key];
      }
    }
  },

  toJSON() {
    return JSON.stringify(this.get(), null, 2);
  },

  fromJSON(json) {
    try {
      this.set(JSON.parse(json));
      return true;
    } catch { return false; }
  }
};

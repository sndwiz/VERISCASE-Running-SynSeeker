/**
 * HubSpot Integration
 * 
 * Search contacts, log billing activity to timelines,
 * sync deals with matter billing status.
 * Docs: https://developers.hubspot.com/docs/api/overview
 */

const axios = require('axios');

const HUBSPOT_API = 'https://api.hubapi.com';

function headers() {
  if (!process.env.HUBSPOT_API_KEY) throw new Error('HubSpot API key not configured');
  return {
    'Authorization': `Bearer ${process.env.HUBSPOT_API_KEY}`,
    'Content-Type': 'application/json'
  };
}

const hubspot = {
  async searchContacts(query) {
    const { data } = await axios.post(`${HUBSPOT_API}/crm/v3/objects/contacts/search`, {
      query,
      limit: 20,
      properties: ['firstname', 'lastname', 'email', 'phone', 'company']
    }, { headers: headers() });
    return data.results;
  },

  async getContact(contactId) {
    const { data } = await axios.get(
      `${HUBSPOT_API}/crm/v3/objects/contacts/${contactId}`,
      { headers: headers(), params: { properties: 'firstname,lastname,email,phone,company' } }
    );
    return data;
  },

  async getDeals(query = {}) {
    const { data } = await axios.post(`${HUBSPOT_API}/crm/v3/objects/deals/search`, {
      filterGroups: query.contactId ? [{
        filters: [{
          propertyName: 'associations.contact',
          operator: 'EQ',
          value: query.contactId
        }]
      }] : [],
      limit: 20,
      properties: ['dealname', 'amount', 'dealstage', 'closedate']
    }, { headers: headers() });
    return data.results;
  },

  async logBillingActivity({ contactId, dealId, matterId, summary }) {
    // Create a note on the contact/deal
    const noteBody = [
      `📋 Billing Pipeline Complete — ${summary?.clientName || 'Unknown'}`,
      `Entries: ${summary?.totalEntries || 0}`,
      `Hours: ${summary?.totalHours?.toFixed(1) || 0}`,
      `Amount: $${summary?.totalAmount?.toFixed(2) || 0}`,
      `Flagged: ${summary?.flaggedCount || 0}`,
      `Period: ${summary?.dateRange || 'N/A'}`,
      `Matter: ${matterId || 'N/A'}`
    ].join('\n');

    const { data } = await axios.post(`${HUBSPOT_API}/crm/v3/objects/notes`, {
      properties: {
        hs_note_body: noteBody,
        hs_timestamp: new Date().toISOString()
      },
      associations: [
        ...(contactId ? [{
          to: { id: contactId },
          types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 202 }]
        }] : []),
        ...(dealId ? [{
          to: { id: dealId },
          types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 214 }]
        }] : [])
      ]
    }, { headers: headers() });

    return data;
  },

  async updateDealAmount(dealId, amount) {
    const { data } = await axios.patch(
      `${HUBSPOT_API}/crm/v3/objects/deals/${dealId}`,
      { properties: { amount: String(amount) } },
      { headers: headers() }
    );
    return data;
  }
};

module.exports = hubspot;

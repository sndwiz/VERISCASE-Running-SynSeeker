/**
 * Monday.com Integration
 * 
 * Creates/updates billing items on Monday boards,
 * syncs pipeline results, and handles board queries.
 * Docs: https://developer.monday.com/api-reference
 */

const axios = require('axios');

const MONDAY_API = 'https://api.monday.com/v2';

async function mondayQuery(query, variables = {}) {
  if (!process.env.MONDAY_API_TOKEN) throw new Error('Monday API token not configured');
  
  const { data } = await axios.post(MONDAY_API, 
    { query, variables },
    {
      headers: {
        'Authorization': process.env.MONDAY_API_TOKEN,
        'Content-Type': 'application/json'
      }
    }
  );
  
  if (data.errors) throw new Error(data.errors[0]?.message || 'Monday API error');
  return data.data;
}

const monday = {
  async getBoards() {
    return mondayQuery(`
      query {
        boards(limit: 20) {
          id name state
          columns { id title type }
        }
      }
    `);
  },

  async createBillingItem({ boardId, matterName, clientName, totalHours, totalAmount, flaggedCount, status }) {
    const boardIdNum = boardId || process.env.MONDAY_BOARD_ID;
    if (!boardIdNum) throw new Error('No board ID specified');

    const columnValues = JSON.stringify({
      // Adapt these column IDs to your board setup
      text: clientName || '',
      numbers: totalHours || 0,
      numbers_1: totalAmount || 0,
      numbers_2: flaggedCount || 0,
      status: { label: status || 'In Review' }
    });

    return mondayQuery(`
      mutation ($boardId: ID!, $itemName: String!, $columnValues: JSON!) {
        create_item(
          board_id: $boardId
          item_name: $itemName
          column_values: $columnValues
        ) {
          id name
        }
      }
    `, {
      boardId: boardIdNum,
      itemName: matterName || 'Billing Review',
      columnValues
    });
  },

  async updateItem(itemId, columnValues) {
    return mondayQuery(`
      mutation ($itemId: ID!, $boardId: ID!, $columnValues: JSON!) {
        change_multiple_column_values(
          item_id: $itemId
          board_id: $boardId
          column_values: $columnValues
        ) {
          id
        }
      }
    `, {
      itemId,
      boardId: process.env.MONDAY_BOARD_ID,
      columnValues: JSON.stringify(columnValues)
    });
  },

  async syncBillingResults(matterId, summary, entries) {
    const flaggedCount = (entries || []).filter(e => e.flags?.length > 0).length;
    
    return this.createBillingItem({
      matterName: `Billing: ${summary?.clientName || matterId}`,
      clientName: summary?.clientName,
      totalHours: summary?.totalHours,
      totalAmount: summary?.totalAmount,
      flaggedCount,
      status: flaggedCount > 0 ? 'Needs Review' : 'Ready'
    });
  },

  async addUpdate(itemId, message) {
    return mondayQuery(`
      mutation ($itemId: ID!, $body: String!) {
        create_update(item_id: $itemId, body: $body) {
          id
        }
      }
    `, { itemId, body: message });
  }
};

module.exports = monday;

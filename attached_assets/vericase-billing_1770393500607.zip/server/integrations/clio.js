/**
 * Clio Integration
 * 
 * Handles OAuth2 flow, time entries, matters, and contacts.
 * Docs: https://app.clio.com/api/v4/documentation
 */

const axios = require('axios');

const BASE_URL = process.env.CLIO_API_BASE || 'https://app.clio.com/api/v4';
let tokens = { access_token: null, refresh_token: null, expires_at: null };

const clio = {
  // ============================================
  // AUTH
  // ============================================
  getAuthUrl() {
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: process.env.CLIO_CLIENT_ID,
      redirect_uri: process.env.CLIO_REDIRECT_URI
    });
    return `https://app.clio.com/oauth/authorize?${params}`;
  },

  async handleCallback(code) {
    const { data } = await axios.post('https://app.clio.com/oauth/token', {
      grant_type: 'authorization_code',
      code,
      client_id: process.env.CLIO_CLIENT_ID,
      client_secret: process.env.CLIO_CLIENT_SECRET,
      redirect_uri: process.env.CLIO_REDIRECT_URI
    });
    tokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in * 1000)
    };
    return tokens;
  },

  async refreshToken() {
    if (!tokens.refresh_token) throw new Error('No refresh token');
    const { data } = await axios.post('https://app.clio.com/oauth/token', {
      grant_type: 'refresh_token',
      refresh_token: tokens.refresh_token,
      client_id: process.env.CLIO_CLIENT_ID,
      client_secret: process.env.CLIO_CLIENT_SECRET
    });
    tokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + (data.expires_in * 1000)
    };
  },

  isConnected() {
    return !!tokens.access_token && Date.now() < (tokens.expires_at || 0);
  },

  tokenExpiresAt() {
    return tokens.expires_at ? new Date(tokens.expires_at).toISOString() : null;
  },

  async api(method, endpoint, data = null) {
    if (!this.isConnected() && tokens.refresh_token) {
      await this.refreshToken();
    }
    if (!tokens.access_token) throw new Error('Not connected to Clio');

    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {
        'Authorization': `Bearer ${tokens.access_token}`,
        'Content-Type': 'application/json'
      }
    };
    if (data) config.data = { data };
    
    const response = await axios(config);
    return response.data;
  },

  // ============================================
  // MATTERS
  // ============================================
  async getMatters(query = {}) {
    const params = new URLSearchParams({
      fields: 'id,display_number,description,status,client',
      limit: query.limit || 50,
      ...(query.status && { status: query.status }),
      ...(query.query && { query: query.query })
    });
    return this.api('get', `/matters.json?${params}`);
  },

  // ============================================
  // TIME ENTRIES
  // ============================================
  async getTimeEntries(matterId, query = {}) {
    const params = new URLSearchParams({
      fields: 'id,date,quantity,total,note,matter,user',
      matter_id: matterId,
      limit: query.limit || 200,
      ...(query.from && { from: query.from }),
      ...(query.to && { to: query.to })
    });
    return this.api('get', `/activities.json?${params}`);
  },

  async createTimeEntries(entries) {
    const results = [];
    for (const entry of entries) {
      try {
        const result = await this.api('post', '/activities.json', {
          type: 'TimeEntry',
          date: entry.date,
          quantity: entry.hours * 3600,  // Clio wants seconds
          note: entry.clioNarrative || entry.narrative,
          matter: { id: entry.matterId },
          ...(entry.utbmsCode && { utbms_activity: { id: entry.utbmsCode } })
        });
        results.push({ success: true, id: result.data?.id, date: entry.date });
      } catch (err) {
        results.push({ success: false, error: err.message, date: entry.date });
      }
    }
    return { results, created: results.filter(r => r.success).length };
  },

  // ============================================
  // CONTACTS
  // ============================================
  async searchContacts(query) {
    const params = new URLSearchParams({
      fields: 'id,name,type,email_addresses,phone_numbers',
      query,
      limit: 20
    });
    return this.api('get', `/contacts.json?${params}`);
  }
};

module.exports = clio;

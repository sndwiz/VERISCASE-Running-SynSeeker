/**
 * Integration API Routes
 * 
 * Handles OAuth flows, data sync, and API calls to
 * Clio, Monday.com, and HubSpot from the billing module.
 */

const express = require('express');
const router = express.Router();
const clio = require('../integrations/clio');
const monday = require('../integrations/monday');
const hubspot = require('../integrations/hubspot');

// ============================================
// CLIO INTEGRATION
// ============================================

// OAuth redirect — start Clio auth
router.get('/clio/auth', (req, res) => {
  const authUrl = clio.getAuthUrl();
  res.redirect(authUrl);
});

// OAuth callback
router.get('/clio/callback', async (req, res) => {
  try {
    const { code } = req.query;
    await clio.handleCallback(code);
    res.redirect('/?clio=connected');
  } catch (err) {
    res.status(500).json({ error: 'Clio auth failed: ' + err.message });
  }
});

// Get Clio matters
router.get('/clio/matters', async (req, res) => {
  try {
    const matters = await clio.getMatters(req.query);
    res.json(matters);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get Clio time entries for a matter
router.get('/clio/matters/:id/entries', async (req, res) => {
  try {
    const entries = await clio.getTimeEntries(req.params.id, req.query);
    res.json(entries);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Push verified entries back to Clio
router.post('/clio/entries', async (req, res) => {
  try {
    const result = await clio.createTimeEntries(req.body.entries);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get Clio connection status
router.get('/clio/status', (req, res) => {
  res.json({ connected: clio.isConnected(), expiresAt: clio.tokenExpiresAt() });
});

// ============================================
// MONDAY.COM INTEGRATION
// ============================================

// Get boards
router.get('/monday/boards', async (req, res) => {
  try {
    const boards = await monday.getBoards();
    res.json(boards);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create/update billing item on Monday board
router.post('/monday/items', async (req, res) => {
  try {
    const result = await monday.createBillingItem(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Sync pipeline results to Monday board
router.post('/monday/sync', async (req, res) => {
  try {
    const { matterId, summary, entries } = req.body;
    const result = await monday.syncBillingResults(matterId, summary, entries);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// HUBSPOT INTEGRATION
// ============================================

// Search contacts
router.get('/hubspot/contacts', async (req, res) => {
  try {
    const contacts = await hubspot.searchContacts(req.query.q);
    res.json(contacts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get deal/contact for a matter
router.get('/hubspot/deals', async (req, res) => {
  try {
    const deals = await hubspot.getDeals(req.query);
    res.json(deals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Log billing activity to HubSpot contact timeline
router.post('/hubspot/activity', async (req, res) => {
  try {
    const result = await hubspot.logBillingActivity(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// INTEGRATION STATUS (all-in-one check)
// ============================================
router.get('/status', (req, res) => {
  res.json({
    clio: { connected: clio.isConnected(), configured: !!process.env.CLIO_CLIENT_ID },
    monday: { configured: !!process.env.MONDAY_API_TOKEN },
    hubspot: { configured: !!process.env.HUBSPOT_API_KEY }
  });
});

module.exports = router;

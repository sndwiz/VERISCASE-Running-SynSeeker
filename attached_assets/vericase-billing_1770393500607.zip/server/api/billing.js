/**
 * Billing API Routes
 * 
 * Server-side storage for matter profiles, review logs,
 * and pipeline results. The actual pipeline processing
 * happens client-side for data privacy.
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const PROFILES_DIR = path.join(DATA_DIR, 'profiles');
const REVIEWS_DIR = path.join(DATA_DIR, 'reviews');

// Ensure data dirs exist
[DATA_DIR, PROFILES_DIR, REVIEWS_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ============================================
// MATTER PROFILES
// ============================================

// List all saved matter profiles
router.get('/profiles', (req, res) => {
  try {
    const files = fs.readdirSync(PROFILES_DIR).filter(f => f.endsWith('.json'));
    const profiles = files.map(f => {
      const data = JSON.parse(fs.readFileSync(path.join(PROFILES_DIR, f), 'utf8'));
      return {
        id: f.replace('.json', ''),
        clientName: data.clientName,
        dateRange: `${data.startDate} → ${data.endDate}`,
        updatedAt: fs.statSync(path.join(PROFILES_DIR, f)).mtime
      };
    });
    res.json({ profiles });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get a specific profile
router.get('/profiles/:id', (req, res) => {
  try {
    const filepath = path.join(PROFILES_DIR, `${req.params.id}.json`);
    if (!fs.existsSync(filepath)) return res.status(404).json({ error: 'Profile not found' });
    const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Save a matter profile
router.post('/profiles', (req, res) => {
  try {
    const profile = req.body;
    const id = (profile.clientName || 'unknown').replace(/\s+/g, '_').toLowerCase() + '_' + Date.now();
    const filepath = path.join(PROFILES_DIR, `${id}.json`);
    fs.writeFileSync(filepath, JSON.stringify(profile, null, 2));
    res.json({ id, message: 'Profile saved' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update a profile
router.put('/profiles/:id', (req, res) => {
  try {
    const filepath = path.join(PROFILES_DIR, `${req.params.id}.json`);
    fs.writeFileSync(filepath, JSON.stringify(req.body, null, 2));
    res.json({ message: 'Profile updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete a profile
router.delete('/profiles/:id', (req, res) => {
  try {
    const filepath = path.join(PROFILES_DIR, `${req.params.id}.json`);
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
    res.json({ message: 'Profile deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// REVIEW LOGS
// ============================================

// Save review log from client-side pipeline
router.post('/reviews', (req, res) => {
  try {
    const { matterId, reviewLog, summary } = req.body;
    const id = (matterId || 'review') + '_' + Date.now();
    const filepath = path.join(REVIEWS_DIR, `${id}.json`);
    fs.writeFileSync(filepath, JSON.stringify({
      id,
      matterId,
      reviewLog,
      summary,
      createdAt: new Date().toISOString()
    }, null, 2));
    res.json({ id, message: 'Review log saved' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get review logs for a matter
router.get('/reviews/:matterId', (req, res) => {
  try {
    const files = fs.readdirSync(REVIEWS_DIR).filter(f => f.startsWith(req.params.matterId));
    const reviews = files.map(f => JSON.parse(fs.readFileSync(path.join(REVIEWS_DIR, f), 'utf8')));
    res.json({ reviews });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// PIPELINE RESULTS (for integration sync)
// ============================================

// Client posts completed pipeline results for server-side integrations to consume
router.post('/results', (req, res) => {
  try {
    const { matterId, entries, summary, settings } = req.body;
    
    // Store for integration sync
    const resultPath = path.join(DATA_DIR, `result_${matterId || 'latest'}.json`);
    fs.writeFileSync(resultPath, JSON.stringify({
      matterId,
      entries,
      summary,
      settings,
      processedAt: new Date().toISOString()
    }, null, 2));

    res.json({ message: 'Results stored for integration sync' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

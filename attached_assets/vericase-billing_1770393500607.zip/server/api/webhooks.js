/**
 * Webhook Routes
 * 
 * Handles incoming webhooks from Monday.com, chatbot,
 * and VERICASE core module events.
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');

// ============================================
// MONDAY.COM WEBHOOKS
// ============================================
router.post('/monday', (req, res) => {
  // Monday sends a challenge on webhook setup
  if (req.body.challenge) {
    return res.json({ challenge: req.body.challenge });
  }

  const { event } = req.body;
  console.log('[Webhook] Monday event:', event?.type);

  // Handle status changes, new items, etc.
  if (event?.type === 'change_column_value') {
    // A matter status changed on Monday board
    console.log(`  Matter ${event.itemId} column "${event.columnId}" → "${event.value}"`);
  }

  res.json({ ok: true });
});

// ============================================
// CHATBOT WEBHOOK
// ============================================
router.post('/chatbot', (req, res) => {
  const { action, payload, sessionId } = req.body;
  console.log(`[Webhook] Chatbot action: ${action}`);

  let response = { message: 'Unknown action' };

  switch (action) {
    case 'get_billing_summary': {
      // Chatbot asks for a quick billing summary for a matter
      const { matterId } = payload || {};
      const resultPath = path.join(DATA_DIR, `result_${matterId || 'latest'}.json`);
      if (fs.existsSync(resultPath)) {
        const data = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
        response = {
          message: `Billing for ${data.settings?.clientName}: ${data.summary?.totalEntries || 0} entries, ${data.summary?.totalHours?.toFixed(1) || 0} hours, ${data.summary?.totalAmount?.toFixed(2) || 0} total.`,
          data: data.summary
        };
      } else {
        response = { message: 'No billing data found for that matter. Run the pipeline first.' };
      }
      break;
    }

    case 'get_flagged_count': {
      const { matterId } = payload || {};
      const resultPath = path.join(DATA_DIR, `result_${matterId || 'latest'}.json`);
      if (fs.existsSync(resultPath)) {
        const data = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
        const flagged = (data.entries || []).filter(e => e.flags?.length > 0);
        response = {
          message: `${flagged.length} flagged entries need review.`,
          count: flagged.length
        };
      } else {
        response = { message: 'No billing data found.' };
      }
      break;
    }

    case 'list_profiles': {
      const profilesDir = path.join(DATA_DIR, 'profiles');
      if (fs.existsSync(profilesDir)) {
        const files = fs.readdirSync(profilesDir).filter(f => f.endsWith('.json'));
        const names = files.map(f => {
          const d = JSON.parse(fs.readFileSync(path.join(profilesDir, f), 'utf8'));
          return d.clientName;
        });
        response = { message: `Active matter profiles: ${names.join(', ') || 'None'}`, profiles: names };
      }
      break;
    }

    default:
      response = { message: `Unknown chatbot action: ${action}` };
  }

  res.json(response);
});

// ============================================
// VERICASE CORE — MODULE EVENTS
// ============================================
router.post('/vericase', (req, res) => {
  const { event, data } = req.body;
  console.log(`[Webhook] VERICASE event: ${event}`);

  switch (event) {
    case 'matter.created':
      // Auto-create a billing profile stub when a new matter is created
      console.log(`  New matter: ${data?.matterName}`);
      break;

    case 'matter.updated':
      console.log(`  Matter updated: ${data?.matterId}`);
      break;

    case 'clio.sync.complete':
      console.log(`  Clio sync done, ${data?.entriesCount} entries available`);
      break;

    default:
      console.log(`  Unhandled event: ${event}`);
  }

  res.json({ received: true });
});

module.exports = router;

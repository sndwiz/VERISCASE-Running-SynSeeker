/**
 * VERICASE Billing Module — Server Entry Point
 * 
 * Express server that serves the billing UI and provides
 * API endpoints for Clio, Monday, HubSpot, and chatbot integrations.
 * 
 * Sensitive billing data still processes CLIENT-SIDE in the browser.
 * The server handles integration sync, webhooks, and profile storage.
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// MIDDLEWARE
// ============================================
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

// Static files — the billing UI
app.use(express.static(path.join(__dirname, '..', 'public')));

// ============================================
// API ROUTES
// ============================================
const billingRoutes = require('./api/billing');
const integrationsRoutes = require('./api/integrations');
const webhookRoutes = require('./api/webhooks');

app.use('/api/billing', billingRoutes);
app.use('/api/integrations', integrationsRoutes);
app.use('/api/webhooks', webhookRoutes);

// ============================================
// MODULE HEALTH & REGISTRATION
// ============================================
app.get('/api/health', (req, res) => {
  res.json({
    module: 'vericase-billing',
    version: '1.0.0',
    status: 'healthy',
    uptime: process.uptime(),
    integrations: {
      clio: !!process.env.CLIO_CLIENT_ID,
      monday: !!process.env.MONDAY_API_TOKEN,
      hubspot: !!process.env.HUBSPOT_API_KEY,
      chatbot: !!process.env.CHATBOT_ENDPOINT
    }
  });
});

// Module manifest — used by VERICASE core to register this module
app.get('/api/manifest', (req, res) => {
  res.json({
    id: 'billing',
    name: 'Billing Verifier',
    description: 'Legal time entry verification & Clio-ready export',
    version: '1.0.0',
    icon: 'receipt',
    routes: [
      { path: '/billing', label: 'Billing Verifier', icon: 'receipt' },
      { path: '/billing/matters', label: 'Matter Profiles', icon: 'folder' }
    ],
    capabilities: [
      'time-entry-verification',
      'clio-export',
      'pdf-invoicing',
      'utbms-coding',
      'quality-audit',
      'split-alternatives'
    ],
    integrations: ['clio', 'monday', 'hubspot', 'chatbot'],
    events: {
      emits: ['billing.pipeline.complete', 'billing.export.ready', 'billing.review.updated'],
      listens: ['matter.created', 'matter.updated', 'clio.sync.complete']
    }
  });
});

// SPA fallback — serve index.html for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ============================================
// START SERVER
// ============================================
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🧾 VERICASE Billing Module running on port ${PORT}`);
  console.log(`   UI:   http://localhost:${PORT}`);
  console.log(`   API:  http://localhost:${PORT}/api`);
  console.log(`   Health: http://localhost:${PORT}/api/health\n`);
});

module.exports = app;

# VERICASE Billing Module

Legal time entry verification, Clio-ready export, and CRM integration.

## Architecture

```
vericase-billing/
├── server/                      # Express backend
│   ├── index.js                 # Entry point (port 3000)
│   ├── api/
│   │   ├── billing.js           # Profiles, reviews, results storage
│   │   ├── integrations.js      # Clio/Monday/HubSpot API routes
│   │   └── webhooks.js          # Monday, chatbot, VERICASE events
│   └── integrations/
│       ├── clio.js              # Clio OAuth2 + time entries
│       ├── monday.js            # Monday.com GraphQL board sync
│       └── hubspot.js           # HubSpot contacts + activity log
│
├── public/                      # Client-side UI (all billing processing here)
│   ├── index.html               # Shell — loads modules
│   ├── css/billing.css          # Styles
│   └── js/
│       ├── app.js               # Main entry — wires everything
│       └── modules/
│           ├── state.js          # Centralized state + event bus
│           ├── settings.js       # Matter profile config
│           ├── parsers.js        # CSV/XLSX/ZIP file parsing
│           ├── pipeline.js       # Core verification engine
│           ├── ui.js             # DOM rendering
│           ├── export.js         # PDF/XLSX/CSV/JSON export
│           ├── utbms.js          # UTBMS code detection
│           ├── utils.js          # Shared utilities
│           └── integrations.js   # Client→Server API calls
│
├── data/                        # Auto-created: profiles, reviews, results
├── .replit                      # Replit run config
├── .env.example                 # Environment template
└── package.json
```

## Quick Start (Replit)

1. Import this repo into Replit
2. Copy `.env.example` → `.env`
3. Click **Run** — server starts on port 3000
4. Open the webview — drop CSV/XLSX files and run the pipeline

## Quick Start (Local)

```bash
npm install
cp .env.example .env
npm start
# Open http://localhost:3000
```

## Module Design

**Sensitive data stays client-side.** The browser handles:
- File parsing (CSV, XLSX, ZIP)
- Confidence classification
- Flagging + quality checks
- Narrative generation
- UTBMS code detection
- PDF/XLSX/CSV export

**Server handles integrations only:**
- Matter profile storage
- Review log persistence
- Clio OAuth + entry push
- Monday.com board sync
- HubSpot activity logging
- Webhook reception (chatbot, VERICASE core)

## Integration Setup

### Clio
1. Register app at [https://app.clio.com/nc/#/settings/developer_applications](https://app.clio.com/nc/#/settings/developer_applications)
2. Set redirect URI to `https://your-replit-url/api/integrations/clio/callback`
3. Add `CLIO_CLIENT_ID` and `CLIO_CLIENT_SECRET` to `.env`
4. Visit `/api/integrations/clio/auth` to connect

### Monday.com
1. Get API token from Monday.com admin
2. Add `MONDAY_API_TOKEN` and `MONDAY_BOARD_ID` to `.env`
3. Set webhook URL to `https://your-replit-url/api/webhooks/monday`

### HubSpot
1. Create private app at [https://app.hubspot.com](https://app.hubspot.com)
2. Add `HUBSPOT_API_KEY` to `.env`

### Chatbot
POST to `/api/webhooks/chatbot` with:
```json
{
  "action": "get_billing_summary",
  "payload": { "matterId": "david_gerber" }
}
```
Actions: `get_billing_summary`, `get_flagged_count`, `list_profiles`

## VERICASE Module Events

**Emits:** `billing.pipeline.complete`, `billing.export.ready`, `billing.review.updated`
**Listens:** `matter.created`, `matter.updated`, `clio.sync.complete`

Module manifest at `/api/manifest` for VERICASE core registration.

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/manifest` | Module registration manifest |
| GET | `/api/billing/profiles` | List matter profiles |
| POST | `/api/billing/profiles` | Save a profile |
| POST | `/api/billing/results` | Store pipeline results for sync |
| POST | `/api/billing/reviews` | Save review log |
| GET | `/api/integrations/status` | All integration status |
| GET | `/api/integrations/clio/auth` | Start Clio OAuth |
| POST | `/api/integrations/clio/entries` | Push entries to Clio |
| POST | `/api/integrations/monday/sync` | Sync to Monday board |
| POST | `/api/integrations/hubspot/activity` | Log billing to HubSpot |
| POST | `/api/webhooks/chatbot` | Chatbot queries |
| POST | `/api/webhooks/monday` | Monday webhook receiver |
| POST | `/api/webhooks/vericase` | VERICASE core events |

## Going Offline

To run without internet (original spec), swap CDN scripts in `index.html` for local vendor files:
```bash
mkdir -p public/vendor
# Download each lib to public/vendor/
# Update <script> tags to point to /vendor/...
```

// ============================================
// SYNSEEKER - Main Page Component
// Add to: client/src/pages/SynSeeker.tsx
// Route: /synseeker
// ============================================

import { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

// ---- Types ----
interface Investigation {
  id: string;
  targetName: string;
  targetDomain: string | null;
  targetState: string | null;
  templateId: string | null;
  status: string;
  progress: number;
  totalFindings: number;
  criticalFlags: number;
  entityCount: number;
  connectionCount: number;
  aiRiskScore: number | null;
  aiSummary: string | null;
  scanLog: ScanLogEntry[];
  createdAt: string;
  completedAt: string | null;
  scanDuration: number | null;
  findings?: Finding[];
  entities?: Entity[];
  connections?: Connection[];
}

interface ScanLogEntry {
  timestamp: string;
  source: string;
  result: string;
  message: string;
}

interface Finding {
  id: string;
  severity: 'critical' | 'warning' | 'info' | 'success';
  source: string;
  title: string;
  body: string;
  tags: string[];
  url: string | null;
  starred: boolean;
  dismissed: boolean;
  userNotes: string | null;
  createdAt: string;
}

interface Entity {
  id: string;
  type: string;
  name: string;
  role: string | null;
  address: string | null;
  state: string | null;
  npi: string | null;
  email: string | null;
  phone: string | null;
}

interface Connection {
  id: string;
  sourceEntityId: string;
  targetEntityId: string;
  relationship: string;
  strength: string | null;
  evidence: string | null;
  severity: string | null;
}

interface Template {
  id: string;
  name: string;
  description: string;
  sources: string[];
}

// ---- API helpers ----
async function apiGet<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

async function apiPost<T>(url: string, body: any): Promise<T> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

async function apiPatch<T>(url: string, body: any): Promise<T> {
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// ---- Severity colors ----
const SEVERITY_COLORS: Record<string, { bg: string; text: string; border: string; dot: string }> = {
  critical: { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/30', dot: 'bg-red-500' },
  warning: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/30', dot: 'bg-amber-500' },
  info: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/30', dot: 'bg-blue-500' },
  success: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30', dot: 'bg-emerald-500' },
};

const STATUS_COLORS: Record<string, string> = {
  queued: 'text-gray-400',
  scanning: 'text-cyan-400',
  analyzing: 'text-purple-400',
  complete: 'text-emerald-400',
  failed: 'text-red-400',
  archived: 'text-gray-500',
};

// ============================================
// MAIN PAGE COMPONENT
// ============================================

export default function SynSeekerPage() {
  const [view, setView] = useState<'list' | 'new' | 'detail' | 'scanning'>('list');
  const [activeId, setActiveId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const openInvestigation = useCallback((id: string) => {
    setActiveId(id);
    setView('detail');
  }, []);

  const startScanning = useCallback((id: string) => {
    setActiveId(id);
    setView('scanning');
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Header */}
      <div className="border-b border-gray-800 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">SynSeeker</h1>
              <p className="text-xs text-gray-500">Automated Entity Investigation</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {view !== 'list' && (
              <button
                onClick={() => { setView('list'); setActiveId(null); }}
                className="px-3 py-1.5 text-sm text-gray-400 hover:text-gray-200 transition"
              >
                ← Back to List
              </button>
            )}
            <button
              onClick={() => setView('new')}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-gray-950 text-sm font-medium rounded-lg transition"
            >
              + New Investigation
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {view === 'list' && (
          <InvestigationList
            onOpen={openInvestigation}
            onNew={() => setView('new')}
          />
        )}
        {view === 'new' && (
          <NewInvestigation
            onCreated={startScanning}
            onCancel={() => setView('list')}
          />
        )}
        {view === 'scanning' && activeId && (
          <ScanningView
            investigationId={activeId}
            onComplete={() => {
              queryClient.invalidateQueries({ queryKey: ['investigations'] });
              openInvestigation(activeId);
            }}
          />
        )}
        {view === 'detail' && activeId && (
          <InvestigationDetail investigationId={activeId} />
        )}
      </div>
    </div>
  );
}

// ============================================
// INVESTIGATION LIST
// ============================================

function InvestigationList({
  onOpen,
  onNew,
}: {
  onOpen: (id: string) => void;
  onNew: () => void;
}) {
  const { data, isLoading, error } = useQuery({
    queryKey: ['investigations'],
    queryFn: () => apiGet<{ data: Investigation[] }>('/api/investigations'),
    refetchInterval: 5000,
  });

  const investigations = data?.data || [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (investigations.length === 0) {
    return (
      <div className="text-center py-20">
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-800 flex items-center justify-center">
          <svg className="w-8 h-8 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        <h3 className="text-gray-400 mb-2">No investigations yet</h3>
        <p className="text-gray-600 text-sm mb-4">Start your first automated entity investigation</p>
        <button onClick={onNew}
          className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-gray-950 text-sm font-medium rounded-lg transition">
          + New Investigation
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {investigations.map((inv) => (
        <button
          key={inv.id}
          onClick={() => onOpen(inv.id)}
          className="w-full text-left p-4 bg-gray-900 hover:bg-gray-800/80 border border-gray-800 hover:border-gray-700 rounded-xl transition group"
        >
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium text-gray-100 truncate">{inv.targetName}</h3>
                <span className={`text-xs font-mono uppercase ${STATUS_COLORS[inv.status] || 'text-gray-500'}`}>
                  {inv.status}
                </span>
              </div>
              {inv.targetDomain && (
                <p className="text-sm text-gray-500 truncate">{inv.targetDomain}</p>
              )}
            </div>

            <div className="flex items-center gap-4 text-xs text-gray-500 ml-4 shrink-0">
              {inv.status === 'complete' && (
                <>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-gray-300">{inv.totalFindings}</div>
                    <div>findings</div>
                  </div>
                  {inv.criticalFlags > 0 && (
                    <div className="text-center">
                      <div className="text-lg font-semibold text-red-400">{inv.criticalFlags}</div>
                      <div>critical</div>
                    </div>
                  )}
                  {inv.aiRiskScore != null && (
                    <div className="text-center">
                      <div className={`text-lg font-semibold ${
                        inv.aiRiskScore >= 70 ? 'text-red-400' :
                        inv.aiRiskScore >= 40 ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {inv.aiRiskScore}
                      </div>
                      <div>risk</div>
                    </div>
                  )}
                </>
              )}
              {inv.status === 'scanning' && (
                <div className="flex items-center gap-2">
                  <div className="w-20 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-cyan-500 rounded-full transition-all duration-500"
                      style={{ width: `${inv.progress}%` }}
                    />
                  </div>
                  <span className="text-cyan-400 font-mono">{inv.progress}%</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 mt-2 text-xs text-gray-600">
            <span>{new Date(inv.createdAt).toLocaleDateString()}</span>
            {inv.templateId && inv.templateId !== 'custom' && (
              <span className="px-1.5 py-0.5 bg-gray-800 rounded text-gray-400">
                {inv.templateId.replace(/_/g, ' ')}
              </span>
            )}
            {inv.scanDuration && (
              <span>{inv.scanDuration}s scan</span>
            )}
          </div>
        </button>
      ))}
    </div>
  );
}

// ============================================
// NEW INVESTIGATION FORM
// ============================================

function NewInvestigation({
  onCreated,
  onCancel,
}: {
  onCreated: (id: string) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    targetName: '',
    targetDomain: '',
    targetAddress: '',
    targetState: 'CO',
    templateId: 'custom',
  });

  const { data: templates } = useQuery({
    queryKey: ['investigation-templates'],
    queryFn: () => apiGet<Template[]>('/api/investigations/templates'),
  });

  const mutation = useMutation({
    mutationFn: (data: typeof form) => apiPost<Investigation>('/api/investigations', data),
    onSuccess: (inv) => onCreated(inv.id),
  });

  const selectedTemplate = templates?.find((t) => t.id === form.templateId);

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-xl font-semibold mb-6">New Investigation</h2>

      <div className="space-y-5">
        {/* Template selector */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">Investigation Template</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <button
              onClick={() => setForm((f) => ({ ...f, templateId: 'custom' }))}
              className={`p-3 text-left rounded-lg border transition text-sm ${
                form.templateId === 'custom'
                  ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                  : 'border-gray-800 bg-gray-900 text-gray-400 hover:border-gray-700'
              }`}
            >
              <div className="font-medium">Custom</div>
              <div className="text-xs opacity-70 mt-0.5">All sources</div>
            </button>
            {(templates || []).map((t) => (
              <button
                key={t.id}
                onClick={() => setForm((f) => ({ ...f, templateId: t.id }))}
                className={`p-3 text-left rounded-lg border transition text-sm ${
                  form.templateId === t.id
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-300'
                    : 'border-gray-800 bg-gray-900 text-gray-400 hover:border-gray-700'
                }`}
              >
                <div className="font-medium">{t.name}</div>
                <div className="text-xs opacity-70 mt-0.5">{t.sources.length} sources</div>
              </button>
            ))}
          </div>
          {selectedTemplate && (
            <p className="text-xs text-gray-500 mt-2">{selectedTemplate.description}</p>
          )}
        </div>

        {/* Target name */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1.5">
            Target Name <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            value={form.targetName}
            onChange={(e) => setForm((f) => ({ ...f, targetName: e.target.value }))}
            placeholder="e.g. AccessCare Surgical Network"
            className="w-full px-4 py-2.5 bg-gray-900 border border-gray-800 rounded-lg text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-cyan-500 transition"
          />
        </div>

        {/* Domain */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1.5">Website Domain</label>
          <input
            type="text"
            value={form.targetDomain}
            onChange={(e) => setForm((f) => ({ ...f, targetDomain: e.target.value }))}
            placeholder="e.g. accesscaresurgical.com"
            className="w-full px-4 py-2.5 bg-gray-900 border border-gray-800 rounded-lg text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-cyan-500 transition"
          />
        </div>

        {/* State + Address row */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-1.5">State</label>
            <input
              type="text"
              value={form.targetState}
              onChange={(e) => setForm((f) => ({ ...f, targetState: e.target.value.toUpperCase().slice(0, 2) }))}
              maxLength={2}
              placeholder="CO"
              className="w-full px-4 py-2.5 bg-gray-900 border border-gray-800 rounded-lg text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-cyan-500 transition font-mono"
            />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-400 mb-1.5">Address (optional)</label>
            <input
              type="text"
              value={form.targetAddress}
              onChange={(e) => setForm((f) => ({ ...f, targetAddress: e.target.value }))}
              placeholder="Known business address"
              className="w-full px-4 py-2.5 bg-gray-900 border border-gray-800 rounded-lg text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-cyan-500 transition"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={() => mutation.mutate(form)}
            disabled={!form.targetName.trim() || mutation.isPending}
            className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:bg-gray-700 disabled:text-gray-500 text-gray-950 font-medium rounded-lg transition flex items-center gap-2"
          >
            {mutation.isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-gray-950 border-t-transparent rounded-full animate-spin" />
                Launching...
              </>
            ) : (
              <>🔍 Launch Investigation</>
            )}
          </button>
          <button onClick={onCancel} className="px-4 py-2.5 text-gray-400 hover:text-gray-200 transition">
            Cancel
          </button>
        </div>

        {mutation.isError && (
          <p className="text-red-400 text-sm">Failed to start investigation. Please try again.</p>
        )}
      </div>
    </div>
  );
}

// ============================================
// LIVE SCANNING VIEW (SSE)
// ============================================

function ScanningView({
  investigationId,
  onComplete,
}: {
  investigationId: string;
  onComplete: () => void;
}) {
  const [status, setStatus] = useState<string>('scanning');
  const [progress, setProgress] = useState(0);
  const [scanLog, setScanLog] = useState<ScanLogEntry[]>([]);
  const [stats, setStats] = useState({ findings: 0, critical: 0, entities: 0, connections: 0 });
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const evtSource = new EventSource(`/api/investigations/${investigationId}/stream`);

    evtSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setStatus(data.status);
        setProgress(data.progress || 0);
        if (data.scanLog) setScanLog(data.scanLog);
        setStats({
          findings: data.totalFindings || 0,
          critical: data.criticalFlags || 0,
          entities: data.entityCount || 0,
          connections: data.connectionCount || 0,
        });

        if (data.done) {
          evtSource.close();
          setTimeout(onComplete, 800);
        }
      } catch {
        // ignore parse errors
      }
    };

    evtSource.onerror = () => {
      evtSource.close();
      setTimeout(onComplete, 1000);
    };

    return () => evtSource.close();
  }, [investigationId, onComplete]);

  // Auto-scroll log
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [scanLog]);

  const logResultIcon = (result: string) => {
    switch (result) {
      case 'success': return '✓';
      case 'warning': return '⚠';
      case 'error': return '✗';
      default: return '→';
    }
  };

  const logResultColor = (result: string) => {
    switch (result) {
      case 'success': return 'text-emerald-400';
      case 'warning': return 'text-amber-400';
      case 'error': return 'text-red-400';
      default: return 'text-cyan-400';
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className={`text-sm font-mono uppercase ${STATUS_COLORS[status] || 'text-gray-400'}`}>
            {status === 'scanning' ? 'Scanning...' :
             status === 'analyzing' ? 'AI Analysis...' :
             status === 'complete' ? 'Complete' :
             status === 'failed' ? 'Failed' : status}
          </span>
          <span className="text-sm font-mono text-gray-500">{progress}%</span>
        </div>
        <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              status === 'failed' ? 'bg-red-500' :
              status === 'complete' ? 'bg-emerald-500' : 'bg-cyan-500'
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Live stats */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: 'Findings', value: stats.findings, color: 'text-blue-400' },
          { label: 'Critical', value: stats.critical, color: 'text-red-400' },
          { label: 'Entities', value: stats.entities, color: 'text-purple-400' },
          { label: 'Links', value: stats.connections, color: 'text-amber-400' },
        ].map((s) => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-lg p-3 text-center">
            <div className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Scan log */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-gray-800 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
          <span className="text-xs font-mono text-gray-400">SCAN LOG</span>
        </div>
        <div className="h-80 overflow-y-auto p-4 font-mono text-xs space-y-1">
          {scanLog.map((entry, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-gray-600 w-16 shrink-0">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
              <span className={`w-4 shrink-0 ${logResultColor(entry.result)}`}>
                {logResultIcon(entry.result)}
              </span>
              <span className="text-cyan-600 w-16 shrink-0 uppercase">[{entry.source}]</span>
              <span className={`${logResultColor(entry.result)} opacity-90`}>{entry.message}</span>
            </div>
          ))}
          <div ref={logEndRef} />
        </div>
      </div>
    </div>
  );
}

// ============================================
// INVESTIGATION DETAIL / RESULTS DASHBOARD
// ============================================

function InvestigationDetail({ investigationId }: { investigationId: string }) {
  const [activeTab, setActiveTab] = useState<'findings' | 'entities' | 'connections' | 'log'>('findings');
  const [severityFilter, setSeverityFilter] = useState<string | null>(null);

  const { data: investigation, isLoading } = useQuery({
    queryKey: ['investigation', investigationId],
    queryFn: () => apiGet<Investigation>(`/api/investigations/${investigationId}`),
  });

  const queryClient = useQueryClient();
  const toggleStar = useMutation({
    mutationFn: (finding: Finding) =>
      apiPatch(`/api/findings/${finding.id}`, { starred: !finding.starred }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['investigation', investigationId] }),
  });

  if (isLoading || !investigation) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const inv = investigation;
  const allFindings = inv.findings || [];
  const filteredFindings = severityFilter
    ? allFindings.filter((f) => f.severity === severityFilter)
    : allFindings;
  const entities = inv.entities || [];
  const connections = inv.connections || [];

  const severityCounts = {
    critical: allFindings.filter((f) => f.severity === 'critical').length,
    warning: allFindings.filter((f) => f.severity === 'warning').length,
    info: allFindings.filter((f) => f.severity === 'info').length,
    success: allFindings.filter((f) => f.severity === 'success').length,
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold">{inv.targetName}</h2>
            <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
              {inv.targetDomain && <span>{inv.targetDomain}</span>}
              {inv.targetState && <span>• {inv.targetState}</span>}
              <span>• {new Date(inv.createdAt).toLocaleDateString()}</span>
              {inv.scanDuration && <span>• {inv.scanDuration}s scan</span>}
            </div>
          </div>

          {/* Risk score badge */}
          {inv.aiRiskScore != null && (
            <div className={`text-center px-4 py-2 rounded-xl border ${
              inv.aiRiskScore >= 70 ? 'border-red-500/30 bg-red-500/10' :
              inv.aiRiskScore >= 40 ? 'border-amber-500/30 bg-amber-500/10' :
              'border-emerald-500/30 bg-emerald-500/10'
            }`}>
              <div className={`text-3xl font-bold font-mono ${
                inv.aiRiskScore >= 70 ? 'text-red-400' :
                inv.aiRiskScore >= 40 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {inv.aiRiskScore}
              </div>
              <div className="text-xs text-gray-500">Risk Score</div>
            </div>
          )}
        </div>

        {/* AI Summary */}
        {inv.aiSummary && (
          <div className="mt-4 p-4 bg-gray-900 border border-gray-800 rounded-xl">
            <div className="text-xs font-mono text-gray-500 mb-2">AI ANALYSIS</div>
            <p className="text-sm text-gray-300 whitespace-pre-line">{inv.aiSummary}</p>
          </div>
        )}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        {[
          { label: 'Total Findings', value: inv.totalFindings, color: 'text-blue-400' },
          { label: 'Critical Flags', value: inv.criticalFlags, color: 'text-red-400' },
          { label: 'Entities', value: inv.entityCount, color: 'text-purple-400' },
          { label: 'Connections', value: inv.connectionCount, color: 'text-amber-400' },
        ].map((s) => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-lg p-3 text-center">
            <div className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-4 border-b border-gray-800 pb-px">
        {[
          { key: 'findings', label: `Findings (${allFindings.length})` },
          { key: 'entities', label: `Entities (${entities.length})` },
          { key: 'connections', label: `Connections (${connections.length})` },
          { key: 'log', label: 'Scan Log' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-4 py-2 text-sm transition border-b-2 -mb-px ${
              activeTab === tab.key
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'findings' && (
        <div>
          {/* Severity filters */}
          <div className="flex items-center gap-2 mb-4">
            <button
              onClick={() => setSeverityFilter(null)}
              className={`px-3 py-1 text-xs rounded-full transition ${
                !severityFilter ? 'bg-gray-700 text-gray-200' : 'bg-gray-900 text-gray-500 hover:text-gray-300'
              }`}
            >
              All
            </button>
            {Object.entries(severityCounts).map(([sev, count]) => (
              <button
                key={sev}
                onClick={() => setSeverityFilter(severityFilter === sev ? null : sev)}
                className={`px-3 py-1 text-xs rounded-full transition flex items-center gap-1.5 ${
                  severityFilter === sev
                    ? `${SEVERITY_COLORS[sev].bg} ${SEVERITY_COLORS[sev].text}`
                    : 'bg-gray-900 text-gray-500 hover:text-gray-300'
                }`}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${SEVERITY_COLORS[sev].dot}`} />
                {sev} ({count})
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredFindings.map((finding) => (
              <FindingCard
                key={finding.id}
                finding={finding}
                onToggleStar={() => toggleStar.mutate(finding)}
              />
            ))}
            {filteredFindings.length === 0 && (
              <p className="text-gray-600 text-center py-8">No findings match the current filter.</p>
            )}
          </div>
        </div>
      )}

      {activeTab === 'entities' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {entities.map((entity) => (
            <EntityCard key={entity.id} entity={entity} />
          ))}
          {entities.length === 0 && (
            <p className="text-gray-600 col-span-full text-center py-8">No entities discovered.</p>
          )}
        </div>
      )}

      {activeTab === 'connections' && (
        <div className="space-y-2">
          {connections.map((conn) => {
            const source = entities.find((e) => e.id === conn.sourceEntityId);
            const target = entities.find((e) => e.id === conn.targetEntityId);
            return (
              <div key={conn.id} className="p-3 bg-gray-900 border border-gray-800 rounded-lg flex items-center gap-3">
                <span className="text-sm font-medium text-gray-300">{source?.name || '?'}</span>
                <span className="text-xs px-2 py-0.5 bg-gray-800 rounded text-gray-400">
                  {conn.relationship.replace(/_/g, ' ')}
                </span>
                <span className="text-sm font-medium text-gray-300">{target?.name || '?'}</span>
                {conn.strength && (
                  <span className="ml-auto text-xs text-gray-500">{conn.strength}</span>
                )}
              </div>
            );
          })}
          {connections.length === 0 && (
            <p className="text-gray-600 text-center py-8">No connections mapped.</p>
          )}
        </div>
      )}

      {activeTab === 'log' && (
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 font-mono text-xs space-y-1 max-h-96 overflow-y-auto">
          {(inv.scanLog || []).map((entry, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-gray-600 w-20 shrink-0">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
              <span className="text-cyan-600 w-16 shrink-0 uppercase">[{entry.source}]</span>
              <span className={`${
                entry.result === 'success' ? 'text-emerald-400' :
                entry.result === 'warning' ? 'text-amber-400' :
                entry.result === 'error' ? 'text-red-400' : 'text-cyan-400'
              }`}>
                {entry.message}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================
// SUB-COMPONENTS
// ============================================

function FindingCard({ finding, onToggleStar }: { finding: Finding; onToggleStar: () => void }) {
  const colors = SEVERITY_COLORS[finding.severity] || SEVERITY_COLORS.info;

  return (
    <div className={`p-4 border rounded-xl ${colors.border} ${colors.bg} ${finding.dismissed ? 'opacity-50' : ''}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <div className={`w-2 h-2 rounded-full ${colors.dot}`} />
            <span className={`text-xs font-mono uppercase ${colors.text}`}>{finding.severity}</span>
            <span className="text-xs text-gray-600">• {finding.source}</span>
          </div>
          <h4 className="font-medium text-gray-200 text-sm">{finding.title}</h4>
          <p className="text-sm text-gray-400 mt-1 leading-relaxed">{finding.body}</p>

          {finding.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-2">
              {finding.tags.map((tag) => (
                <span key={tag} className="px-2 py-0.5 bg-gray-800/50 rounded text-xs text-gray-500">
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onToggleStar}
            className={`p-1.5 rounded hover:bg-gray-800 transition ${finding.starred ? 'text-amber-400' : 'text-gray-600'}`}
          >
            {finding.starred ? '★' : '☆'}
          </button>
          {finding.url && (
            <a
              href={finding.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded text-gray-600 hover:text-gray-300 hover:bg-gray-800 transition"
            >
              ↗
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

function EntityCard({ entity }: { entity: Entity }) {
  const typeIcons: Record<string, string> = {
    company: '🏢',
    person: '👤',
    domain: '🌐',
    address: '📍',
    phone: '📞',
    email: '✉️',
    license: '📋',
    case: '⚖️',
  };

  return (
    <div className="p-3 bg-gray-900 border border-gray-800 rounded-xl">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-lg">{typeIcons[entity.type] || '•'}</span>
        <span className="text-xs font-mono text-gray-500 uppercase">{entity.type}</span>
      </div>
      <h4 className="font-medium text-gray-200 text-sm truncate">{entity.name}</h4>
      {entity.role && <p className="text-xs text-gray-500 mt-0.5 truncate">{entity.role}</p>}
      {entity.npi && <p className="text-xs text-cyan-500/60 font-mono mt-0.5">NPI: {entity.npi}</p>}
      {entity.address && <p className="text-xs text-gray-600 mt-0.5 truncate">{entity.address}</p>}
    </div>
  );
}

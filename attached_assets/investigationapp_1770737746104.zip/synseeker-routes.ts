// ============================================
// SYNSEEKER - Express Routes
// Add to: server/routes/synseeker.ts
// Then import in your main routes file:
//   import synseekerRouter from './synseeker';
//   app.use(synseekerRouter);
// ============================================

import { Router, Request, Response } from 'express';
import { db } from '../db';
import {
  investigations,
  findings,
  discoveredEntities,
  entityConnections,
} from '../../shared/schema';
import { eq, desc, and, sql } from 'drizzle-orm';
import { InvestigationEngine } from '../services/investigation-engine';
import { getAllTemplates } from '../services/investigation-templates';

const router = Router();

// ---- Validation helpers ----

function validateRequired(body: any, fields: string[]): string | null {
  for (const field of fields) {
    if (!body[field] || (typeof body[field] === 'string' && !body[field].trim())) {
      return `Missing required field: ${field}`;
    }
  }
  return null;
}

function isValidUUID(str: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
}

// ============================================
// INVESTIGATION ENDPOINTS
// ============================================

/**
 * GET /api/investigations
 * List all investigations (paginated, filterable)
 */
router.get('/api/investigations', async (req: Request, res: Response) => {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 50, 100);
    const offset = parseInt(req.query.offset as string) || 0;
    const status = req.query.status as string;
    const matterId = req.query.matterId as string;

    let query = db.select().from(investigations);

    // Build where conditions
    const conditions = [];
    if (status) {
      conditions.push(eq(investigations.status, status as any));
    }
    if (matterId && isValidUUID(matterId)) {
      conditions.push(eq(investigations.matterId, matterId));
    }

    const results = await db
      .select()
      .from(investigations)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(investigations.createdAt))
      .limit(limit)
      .offset(offset);

    // Get total count
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(investigations)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    res.json({
      data: results,
      pagination: { total: count, limit, offset },
    });
  } catch (err: any) {
    console.error('GET /api/investigations error:', err);
    res.status(500).json({ error: 'Failed to fetch investigations' });
  }
});

/**
 * GET /api/investigations/templates
 * List available investigation templates
 */
router.get('/api/investigations/templates', (_req: Request, res: Response) => {
  res.json(getAllTemplates());
});

/**
 * GET /api/investigations/:id
 * Get full investigation with findings, entities, and connections
 */
router.get('/api/investigations/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

    const [investigation] = await db
      .select()
      .from(investigations)
      .where(eq(investigations.id, id));

    if (!investigation) return res.status(404).json({ error: 'Investigation not found' });

    // Fetch all related data in parallel
    const [invFindings, entities, connections] = await Promise.all([
      db.select().from(findings)
        .where(eq(findings.investigationId, id))
        .orderBy(desc(findings.createdAt)),
      db.select().from(discoveredEntities)
        .where(eq(discoveredEntities.investigationId, id)),
      db.select().from(entityConnections)
        .where(eq(entityConnections.investigationId, id)),
    ]);

    res.json({
      ...investigation,
      findings: invFindings,
      entities,
      connections,
    });
  } catch (err: any) {
    console.error('GET /api/investigations/:id error:', err);
    res.status(500).json({ error: 'Failed to fetch investigation' });
  }
});

/**
 * POST /api/investigations
 * Start a new investigation (returns immediately, runs async)
 */
router.post('/api/investigations', async (req: Request, res: Response) => {
  try {
    const err = validateRequired(req.body, ['targetName']);
    if (err) return res.status(400).json({ error: err });

    const {
      targetName,
      targetDomain,
      targetAddress,
      targetState,
      matterId,
      sources,
      templateId,
    } = req.body;

    // Validate matterId if provided
    if (matterId && !isValidUUID(matterId)) {
      return res.status(400).json({ error: 'Invalid matter ID format' });
    }

    // Clean domain (strip protocol if provided)
    const cleanDomain = targetDomain
      ? targetDomain.replace(/^https?:\/\//, '').replace(/\/.*$/, '')
      : null;

    const [investigation] = await db
      .insert(investigations)
      .values({
        targetName: targetName.trim(),
        targetDomain: cleanDomain,
        targetAddress: targetAddress?.trim() || null,
        targetState: targetState?.toUpperCase() || 'CO',
        matterId: matterId || null,
        sources: sources || ['web', 'corp', 'domain', 'legal', 'npi', 'reviews', 'social', 'news'],
        templateId: templateId || 'custom',
        status: 'scanning',
        progress: 0,
      })
      .returning();

    // Fire and forget — engine runs async
    const engine = new InvestigationEngine(investigation.id);
    engine.run().catch((err) => {
      console.error(`[SynSeeker] Investigation ${investigation.id} failed:`, err.message);
      db.update(investigations)
        .set({ status: 'failed' })
        .where(eq(investigations.id, investigation.id))
        .catch(console.error);
    });

    res.status(201).json(investigation);
  } catch (err: any) {
    console.error('POST /api/investigations error:', err);
    res.status(500).json({ error: 'Failed to create investigation' });
  }
});

/**
 * GET /api/investigations/:id/stream
 * SSE endpoint for real-time investigation progress
 */
router.get('/api/investigations/:id/stream', async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

  // SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // nginx compatibility
  res.flushHeaders();

  let lastProgress = -1;
  let lastLogCount = 0;

  const interval = setInterval(async () => {
    try {
      const [inv] = await db
        .select()
        .from(investigations)
        .where(eq(investigations.id, id));

      if (!inv) {
        res.write(`data: ${JSON.stringify({ error: 'Investigation not found' })}\n\n`);
        clearInterval(interval);
        res.end();
        return;
      }

      const scanLog = (inv.scanLog as any[]) || [];

      // Only send if there's actually new data
      if (inv.progress !== lastProgress || scanLog.length !== lastLogCount) {
        lastProgress = inv.progress;
        lastLogCount = scanLog.length;

        res.write(
          `data: ${JSON.stringify({
            status: inv.status,
            progress: inv.progress,
            scanLog: scanLog.slice(-20), // last 20 log entries only (perf)
            totalFindings: inv.totalFindings,
            criticalFlags: inv.criticalFlags,
            entityCount: inv.entityCount,
            connectionCount: inv.connectionCount,
            aiRiskScore: inv.aiRiskScore,
          })}\n\n`
        );
      }

      // End stream when investigation completes
      if (inv.status === 'complete' || inv.status === 'failed') {
        // Send one final update
        res.write(
          `data: ${JSON.stringify({
            status: inv.status,
            progress: inv.progress,
            done: true,
          })}\n\n`
        );
        clearInterval(interval);
        res.end();
      }
    } catch (err) {
      // Don't crash the stream on transient DB errors
      console.error('[SSE] Poll error:', err);
    }
  }, 800); // Poll every 800ms (reasonable balance)

  // Clean up on client disconnect
  req.on('close', () => {
    clearInterval(interval);
    res.end();
  });
});

/**
 * DELETE /api/investigations/:id
 * Archive (soft-delete) an investigation
 */
router.delete('/api/investigations/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

    const [updated] = await db
      .update(investigations)
      .set({ status: 'archived' })
      .where(eq(investigations.id, id))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Investigation not found' });
    res.json(updated);
  } catch (err: any) {
    console.error('DELETE /api/investigations/:id error:', err);
    res.status(500).json({ error: 'Failed to archive investigation' });
  }
});

// ============================================
// FINDINGS ENDPOINTS
// ============================================

/**
 * PATCH /api/findings/:id
 * Update finding metadata (star, dismiss, add notes)
 */
router.patch('/api/findings/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid finding ID' });

    const { starred, dismissed, userNotes } = req.body;

    const updateData: any = {};
    if (typeof starred === 'boolean') updateData.starred = starred;
    if (typeof dismissed === 'boolean') updateData.dismissed = dismissed;
    if (typeof userNotes === 'string') updateData.userNotes = userNotes;

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    const [updated] = await db
      .update(findings)
      .set(updateData)
      .where(eq(findings.id, id))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Finding not found' });
    res.json(updated);
  } catch (err: any) {
    console.error('PATCH /api/findings/:id error:', err);
    res.status(500).json({ error: 'Failed to update finding' });
  }
});

/**
 * GET /api/investigations/:id/findings
 * Get findings for an investigation with optional severity filter
 */
router.get('/api/investigations/:id/findings', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

    const severity = req.query.severity as string;
    const showDismissed = req.query.showDismissed === 'true';

    const conditions = [eq(findings.investigationId, id)];
    if (severity) {
      conditions.push(eq(findings.severity, severity as any));
    }
    if (!showDismissed) {
      conditions.push(eq(findings.dismissed, false));
    }

    const result = await db
      .select()
      .from(findings)
      .where(and(...conditions))
      .orderBy(desc(findings.createdAt));

    res.json(result);
  } catch (err: any) {
    console.error('GET /api/investigations/:id/findings error:', err);
    res.status(500).json({ error: 'Failed to fetch findings' });
  }
});

// ============================================
// ENTITY & CONNECTION ENDPOINTS
// ============================================

/**
 * GET /api/investigations/:id/entities
 * Get discovered entities for an investigation
 */
router.get('/api/investigations/:id/entities', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

    const result = await db
      .select()
      .from(discoveredEntities)
      .where(eq(discoveredEntities.investigationId, id));

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch entities' });
  }
});

/**
 * GET /api/investigations/:id/connections
 * Get entity connections for an investigation
 */
router.get('/api/investigations/:id/connections', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });

    const result = await db
      .select()
      .from(entityConnections)
      .where(eq(entityConnections.investigationId, id));

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch connections' });
  }
});

// ============================================
// MATTER LINKING
// ============================================

/**
 * POST /api/investigations/:id/link-matter
 * Link an investigation to a VERICASE matter
 */
router.post('/api/investigations/:id/link-matter', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { matterId } = req.body;

    if (!isValidUUID(id)) return res.status(400).json({ error: 'Invalid investigation ID' });
    if (!matterId || !isValidUUID(matterId)) {
      return res.status(400).json({ error: 'Valid matterId is required' });
    }

    const [updated] = await db
      .update(investigations)
      .set({ matterId })
      .where(eq(investigations.id, id))
      .returning();

    if (!updated) return res.status(404).json({ error: 'Investigation not found' });
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to link matter' });
  }
});

export default router;

// ============================================
// SYNSEEKER - Investigation Module Schema
// Add to: shared/schema.ts
// ============================================
// 
// INSTRUCTIONS:
// 1. Paste this block into your existing shared/schema.ts
// 2. Make sure the `matters` table reference exists (adjust FK if your table is named differently)
// 3. Run: npx drizzle-kit push
// 4. Verify tables created in your Postgres DB
//
// If your matters table uses `serial` instead of `uuid` for the PK,
// change the matterId column type to match.
// ============================================

import {
  pgTable,
  uuid,
  text,
  timestamp,
  jsonb,
  integer,
  boolean,
  pgEnum,
  index,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
// import { matters } from './schema'; // Uncomment if in separate file

// ---- Enums ----
export const investigationStatusEnum = pgEnum('investigation_status', [
  'queued',
  'scanning',
  'analyzing',
  'complete',
  'failed',
  'archived',
]);

export const findingSeverityEnum = pgEnum('finding_severity', [
  'critical',
  'warning',
  'info',
  'success',
]);

export const entityTypeEnum = pgEnum('entity_type', [
  'company',
  'person',
  'domain',
  'address',
  'phone',
  'email',
  'license',
  'case',
]);

// ---- Core Investigations Table ----
export const investigations = pgTable(
  'investigations',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    // Link to existing matter — adjust reference if your matters table is different
    matterId: uuid('matter_id'),
    // .references(() => matters.id, { onDelete: 'set null' }),

    // Target info
    targetName: text('target_name').notNull(),
    targetDomain: text('target_domain'),
    targetAddress: text('target_address'),
    targetState: text('target_state'),

    // Config
    sources: jsonb('sources')
      .$type<string[]>()
      .default(['web', 'corp', 'domain', 'legal', 'npi', 'reviews', 'social', 'news']),
    templateId: text('template_id'),

    // Status & progress
    status: investigationStatusEnum('status').default('queued').notNull(),
    progress: integer('progress').default(0).notNull(),
    scanLog: jsonb('scan_log').$type<Array<{
      timestamp: string;
      source: string;
      action: string;
      result: string;
      message: string;
      dataFound?: boolean;
    }>>().default([]),

    // Results summary (denormalized for list views)
    totalFindings: integer('total_findings').default(0).notNull(),
    criticalFlags: integer('critical_flags').default(0).notNull(),
    entityCount: integer('entity_count').default(0).notNull(),
    connectionCount: integer('connection_count').default(0).notNull(),

    // AI analysis
    aiSummary: text('ai_summary'),
    aiRiskScore: integer('ai_risk_score'),

    // Metadata
    createdBy: uuid('created_by'),
    createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
    completedAt: timestamp('completed_at', { withTimezone: true }),
    scanDuration: integer('scan_duration'), // seconds
  },
  (table) => [
    index('idx_investigations_status').on(table.status),
    index('idx_investigations_matter').on(table.matterId),
    index('idx_investigations_created').on(table.createdAt),
  ]
);

// ---- Findings Table ----
export const findings = pgTable(
  'findings',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    investigationId: uuid('investigation_id')
      .references(() => investigations.id, { onDelete: 'cascade' })
      .notNull(),

    severity: findingSeverityEnum('severity').notNull(),
    source: text('source').notNull(),
    title: text('title').notNull(),
    body: text('body').notNull(),
    rawData: jsonb('raw_data'),

    tags: jsonb('tags').$type<string[]>().default([]),
    url: text('url'),
    screenshot: text('screenshot'),

    // AI scoring
    aiRelevance: integer('ai_relevance'),
    aiNotes: text('ai_notes'),

    // User interaction
    starred: boolean('starred').default(false).notNull(),
    dismissed: boolean('dismissed').default(false).notNull(),
    userNotes: text('user_notes'),

    createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index('idx_findings_investigation').on(table.investigationId),
    index('idx_findings_severity').on(table.severity),
  ]
);

// ---- Discovered Entities Table ----
export const discoveredEntities = pgTable(
  'discovered_entities',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    investigationId: uuid('investigation_id')
      .references(() => investigations.id, { onDelete: 'cascade' })
      .notNull(),

    type: entityTypeEnum('type').notNull(),
    name: text('name').notNull(),
    role: text('role'),
    details: jsonb('details'),

    // Person fields
    title: text('title'),
    email: text('email'),
    phone: text('phone'),

    // Company/address fields
    address: text('address'),
    state: text('state'),
    sosId: text('sos_id'),
    npi: text('npi'),

    // Domain fields
    registrar: text('registrar'),
    registrationDate: timestamp('registration_date', { withTimezone: true }),

    createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index('idx_entities_investigation').on(table.investigationId),
    index('idx_entities_type').on(table.type),
  ]
);

// ---- Entity Connections Table ----
export const entityConnections = pgTable(
  'entity_connections',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    investigationId: uuid('investigation_id')
      .references(() => investigations.id, { onDelete: 'cascade' })
      .notNull(),

    sourceEntityId: uuid('source_entity_id')
      .references(() => discoveredEntities.id, { onDelete: 'cascade' })
      .notNull(),
    targetEntityId: uuid('target_entity_id')
      .references(() => discoveredEntities.id, { onDelete: 'cascade' })
      .notNull(),

    relationship: text('relationship').notNull(),
    strength: text('strength'), // 'confirmed' | 'suspected' | 'inferred'
    evidence: text('evidence'),
    severity: findingSeverityEnum('severity'),

    createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index('idx_connections_investigation').on(table.investigationId),
  ]
);

// ---- Relations (for Drizzle query builder) ----
export const investigationsRelations = relations(investigations, ({ many }) => ({
  findings: many(findings),
  entities: many(discoveredEntities),
  connections: many(entityConnections),
}));

export const findingsRelations = relations(findings, ({ one }) => ({
  investigation: one(investigations, {
    fields: [findings.investigationId],
    references: [investigations.id],
  }),
}));

export const discoveredEntitiesRelations = relations(discoveredEntities, ({ one, many }) => ({
  investigation: one(investigations, {
    fields: [discoveredEntities.investigationId],
    references: [investigations.id],
  }),
  outgoingConnections: many(entityConnections, { relationName: 'sourceEntity' }),
  incomingConnections: many(entityConnections, { relationName: 'targetEntity' }),
}));

export const entityConnectionsRelations = relations(entityConnections, ({ one }) => ({
  investigation: one(investigations, {
    fields: [entityConnections.investigationId],
    references: [investigations.id],
  }),
  sourceEntity: one(discoveredEntities, {
    fields: [entityConnections.sourceEntityId],
    references: [discoveredEntities.id],
    relationName: 'sourceEntity',
  }),
  targetEntity: one(discoveredEntities, {
    fields: [entityConnections.targetEntityId],
    references: [discoveredEntities.id],
    relationName: 'targetEntity',
  }),
}));

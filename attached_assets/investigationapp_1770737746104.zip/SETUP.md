# SynSeeker — Setup & Integration Guide

## Quick Start (5 minutes)

### 1. Install dependency
```bash
npm install cheerio
```

### 2. Copy files into your project

```
shared/types/synseeker.ts       ← Types (copy from types/synseeker.ts)
shared/schema.ts                ← Paste schema block from schema/synseeker-schema.ts
server/services/investigation-engine.ts
server/services/investigation-templates.ts
server/routes/synseeker.ts
client/src/pages/SynSeekerPage.tsx
```

### 3. Update shared/schema.ts

Paste the schema from `synseeker-schema.ts` into your existing `shared/schema.ts`.

**Important:** Uncomment the `matters` foreign key reference if your `matters` table uses `uuid` primary keys. If your `matters` table uses `serial` IDs, change the `matterId` column type to `integer`.

### 4. Push database schema
```bash
npx drizzle-kit push
```

Verify these tables were created:
- `investigations`
- `findings`
- `discovered_entities`
- `entity_connections`

### 5. Register routes

In your `server/routes/index.ts` (or wherever routes are mounted):

```typescript
import synseekerRouter from './synseeker';
app.use(synseekerRouter);
```

### 6. Add frontend route

In your React router config:

```typescript
import SynSeekerPage from './pages/SynSeekerPage';

// Add to your routes:
<Route path="/synseeker" element={<SynSeekerPage />} />
```

### 7. Add sidebar link (optional)

Add to your sidebar navigation:
```tsx
<NavLink to="/synseeker" icon={SearchIcon}>
  SynSeeker
</NavLink>
```

### 8. Environment variables

Add to your `.env`:
```bash
# REQUIRED (you probably already have this)
ANTHROPIC_API_KEY=sk-ant-...

# OPTIONAL — enhances results but not required
COURTLISTENER_API_KEY=       # Free at courtlistener.com (5000 req/day)
GOOGLE_CSE_KEY=              # Google Custom Search (100 req/day free)
GOOGLE_CSE_ID=               # Your Custom Search Engine ID
NEWSAPI_KEY=                 # newsapi.org (100 req/day free)
```

**Without optional keys:** Web scraping, WHOIS, NPI, and OpenCorporates still work (they're free, no key needed). You just won't get reviews, social, or news results.

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/investigations` | List all (paginated) |
| GET | `/api/investigations/templates` | Available templates |
| GET | `/api/investigations/:id` | Full detail + findings + entities |
| POST | `/api/investigations` | Start new investigation |
| GET | `/api/investigations/:id/stream` | SSE real-time progress |
| DELETE | `/api/investigations/:id` | Archive investigation |
| PATCH | `/api/findings/:id` | Star/dismiss/note a finding |
| GET | `/api/investigations/:id/findings` | Findings with filter |
| GET | `/api/investigations/:id/entities` | Discovered entities |
| GET | `/api/investigations/:id/connections` | Entity connections |
| POST | `/api/investigations/:id/link-matter` | Link to a matter |

### Start Investigation (POST /api/investigations)
```json
{
  "targetName": "AccessCare Surgical Network",
  "targetDomain": "accesscaresurgical.com",
  "targetState": "CO",
  "templateId": "medical_lien"
}
```

---

## Architecture

```
POST /api/investigations
  → Creates DB record (status: scanning)
  → Returns immediately with investigation ID
  → Spawns InvestigationEngine.run() async

InvestigationEngine.run()
  → Phase 1: Data Collection (8 sources, batched parallel)
  → Phase 2: AI Analysis (Claude Sonnet, or heuristic fallback)
  → Phase 3: Connection Mapping (address/state/NPI matching)
  → Phase 4: Finalize (count results, mark complete)

GET /api/investigations/:id/stream
  → SSE endpoint, polls DB every 800ms
  → Sends progress, scan log, stats
  → Auto-closes when status = complete|failed
```

---

## Data Sources (all free tier)

| Source | What it checks | API | Needs key? |
|--------|---------------|-----|-----------|
| Web Scrape | Homepage, team pages, contact info | cheerio | No |
| WHOIS | Domain age, registrant, privacy | who-dat.as93.net | No |
| Corporate | State filings, status, registered agent | OpenCorporates | No |
| Legal | Federal court records, cases | CourtListener | Optional |
| NPI | Provider records, practice locations | CMS NPI Registry | No |
| Reviews | BBB, complaints, online reviews | Google CSE | Optional |
| Social | LinkedIn profiles, company pages | Google CSE | Optional |
| News | News coverage, press mentions | NewsAPI | Optional |

**Monthly cost estimate: $0-15** depending on AI token usage.

---

## Troubleshooting

**Schema push fails:** Make sure you have the `pgEnum` imports at the top. If you get enum conflicts, check that `investigation_status`, `finding_severity`, and `entity_type` don't already exist in your schema.

**Engine times out:** Each source has a 60-second timeout. If your Replit is on the free tier, cold starts can be slow. The engine handles timeouts gracefully and continues with other sources.

**No findings returned:** Check your `.env` for API keys. Without `GOOGLE_CSE_KEY`, reviews/social/news sources will be skipped. The engine logs this in the scan log.

**SSE not working:** Make sure nothing is buffering the response (nginx, reverse proxy). The route sets `X-Accel-Buffering: no` for nginx compatibility. If using Replit's built-in proxy, SSE should work out of the box.

**OpenCorporates rate limit:** Free tier is 50 requests/day. If you hit the limit, the engine logs a warning and continues. Consider caching results or upgrading to their paid tier for production use.

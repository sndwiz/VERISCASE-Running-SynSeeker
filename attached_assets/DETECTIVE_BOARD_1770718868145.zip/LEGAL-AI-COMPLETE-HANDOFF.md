# LEGAL AI INVESTIGATION PLATFORM
## Complete Project Handoff Document
### December 21, 2024

---

# QUICK START FOR NEW CONVERSATION

**What This Is:**
A legal investigation platform disguised as a playful detective cork board. Cute on the surface, enterprise-grade AI and security underneath. Built for medical malpractice attorneys, extensible to all legal work.

**What's Built:**
- Complete RAG pipeline (4,000+ lines Python) - document ingestion, OCR, AI analysis, vector storage
- Interactive cork board prototype (HTML/React)
- Full architecture specs

**What's Designed (Ready to Build):**
- Monday.com-style case/task management backend
- Protected source/informant vault
- 5-tier permission system
- Two operating modes (Private / Wash)
- Boss-only external processing authorization

**Immediate Next Step:**
Get everything into GitHub with proper structure, then continue building.

---

# THE PHILOSOPHY

```
┌────────────────────────────────────────────────────────────────────┐
│                                                                    │
│   WHAT LAWYERS SEE:              WHAT'S ACTUALLY RUNNING:         │
│                                                                    │
│   🪵 Cork board                  Enterprise document AI            │
│   📌 Push pins                   Vector similarity search          │
│   🧵 Red string                  Contradiction detection           │
│   📝 Sticky notes                Full audit trail                  │
│   👤 Photo cards                 Entity extraction                 │
│   📅 Timeline                    Temporal analysis                 │
│                                                                    │
│   "This is fun!"                 "This is a $50K system"          │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

**Why the disguise?** Lawyers aren't tech people. They want to catch bad guys, not configure databases. Give them something familiar (detective board), hide the complexity.

---

# SYSTEM OVERVIEW

## The Three Layers

```
┌─────────────────────────────────────────────────────────────────────┐
│ LAYER 1: PRESENTATION                                               │
│                                                                      │
│   Cork Board UI          Monday View           Source Vault         │
│   (Investigation)        (Management)          (Protected)          │
│                                                                      │
│   • Drag cards           • Cases list          • Codenames          │
│   • Draw strings         • Task boards         • Encrypted IDs      │
│   • Pan/zoom             • Deadlines           • Boss-only access   │
│   • Timeline view        • Team assign         • Audit every view   │
│                                                                      │
├─────────────────────────────────────────────────────────────────────┤
│ LAYER 2: INTELLIGENCE                                                │
│                                                                      │
│   Document Pipeline      Analysis Engine       Version Control      │
│                                                                      │
│   • OCR (any format)     • Contradictions      • Git-like history   │
│   • Text extraction      • Timeline gaps       • Branching          │
│   • Metadata             • Tone analysis       • Restore any point  │
│   • Chunking             • Entity extraction   • Diff views         │
│                                                                      │
├─────────────────────────────────────────────────────────────────────┤
│ LAYER 3: SECURITY & DATA                                            │
│                                                                      │
│   Permission System      Encryption            Audit Trail          │
│                                                                      │
│   • 5 access levels      • AES-256 at rest     • Every action       │
│   • Role-based           • TLS 1.3 transit     • Who/what/when      │
│   • Source protection    • HSM key storage     • Discovery-ready    │
│   • Wash authorization   • Source double-enc   • Immutable log      │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

# COMPONENT 1: RAG PIPELINE

## Status: ✅ BUILT AND READY

**Location:** Code created this session, needs to go into GitHub

**What It Does:**

```
Document (any format)
        │
        ▼
┌───────────────┐
│ File Handler  │ ─── Detect type (PDF, image, scan, Word, etc.)
└───────┬───────┘
        │
        ▼
┌───────────────┐
│  PaddleOCR    │ ─── Extract text, handle handwriting
│               │ ─── Confidence scoring per section
└───────┬───────┘
        │
        ▼
┌───────────────┐
│ Tone Analyzer │ ─── Claude API or local Ollama
│               │ ─── Detect: contradictions, evasion, aggression
│               │ ─── Flag: timeline issues, gaps, patterns
└───────┬───────┘
        │
        ▼
┌───────────────┐
│   Chunker     │ ─── Semantic chunking (not arbitrary tokens)
│               │ ─── Preserve paragraph/section boundaries
└───────┬───────┘
        │
        ▼
┌───────────────┐
│  Embeddings   │ ─── Sentence transformers
│               │ ─── Legal-aware if available
└───────┬───────┘
        │
        ▼
┌───────────────┐
│    Qdrant     │ ─── Vector storage with full metadata
│               │ ─── Source file, page, tone flags, confidence
└───────────────┘
```

**Files Created:**
```
legal-rag-pipeline/
├── document_pipeline.py      # Main orchestrator (FileHandler, OCRProcessor, etc.)
├── qdrant_manager.py         # Vector DB operations (create, store, search)
├── tone_analyzer.py          # AI analysis (Claude/Ollama integration)
├── query_engine.py           # Search interface
├── config.yaml               # All configuration
├── requirements.txt          # Dependencies
└── README.md                 # Documentation
```

**Key Features:**
- Handles ANY file format (PDF, PNG, TIFF, DOCX, scans, faxes, handwriting)
- OCR confidence scoring (flag low-confidence sections)
- Tone analysis identifies legal-specific patterns (not generic sentiment)
- Semantic chunking preserves meaning
- Full metadata in Qdrant (source, page, flags, timestamp)
- Audit trail of every operation

---

# COMPONENT 2: INVESTIGATION BOARD

## Status: 🟡 PROTOTYPE BUILT, NEEDS ELECTRON APP

**Location:** `investigation-board-v2.html` in outputs

**What It Does:**
Visual cork board interface for case investigation. Drag evidence cards, connect with string, see AI findings.

**Element Types:**

| Element | Purpose | AI-Generated? |
|---------|---------|---------------|
| Evidence Card | Document quotes, findings | Yes |
| Person Card | Key individuals in case | Yes |
| Contradiction Card | Conflicting statements | Yes |
| Timeline Node | Events in sequence | Yes |
| Sticky Note | Attorney annotations | No |
| Document Thumbnail | Source file reference | Partial |
| Gap Indicator | Missing evidence | Yes |
| Question Card | Open investigation items | Either |

**Connection Types (The String):**

| Color | Meaning |
|-------|---------|
| 🔴 Red | Contradiction - these conflict |
| 🔵 Blue | Supports - proves element |
| 🟡 Yellow | Related - same topic/person |
| 🟢 Green | Timeline - sequence |
| 🟣 Purple | Causation - cause/effect |
| ⚪ White dashed | Needs investigation |

**The 4 Zones (Medical Malpractice):**

```
┌─────────────────┬─────────────────┐
│                 │                 │
│   1. DUTY       │   2. BREACH     │
│   (Blue)        │   (Red)         │
│                 │                 │
│   Did doctor-   │   Did they      │
│   patient       │   deviate from  │
│   relationship  │   standard of   │
│   exist?        │   care?         │
│                 │                 │
├─────────────────┼─────────────────┤
│                 │                 │
│  3. CAUSATION   │   4. DAMAGES    │
│  (Yellow)       │   (Green)       │
│                 │                 │
│   Did breach    │   What harm     │
│   directly      │   resulted?     │
│   cause injury? │                 │
│                 │                 │
└─────────────────┴─────────────────┘
```

Each zone shows:
- Completeness percentage
- Number of evidence cards
- Gaps detected
- AI flags

**Version History:**
Git-like versioning for the entire board. Every change tracked. Can restore any point. Branch for "what if" theories.

```
Case: Doe v. Memorial Hospital
│
├── v1.0 (Initial upload) ─────────────── Nov 20
├── v1.1 (First AI run) ───────────────── Nov 21
├── v2.0 (Major discovery) ────────────── Dec 5
│   └── v2.2-branch (Alternative theory)
├── v3.0 (Depositions added) ──────────── Dec 18
└── CURRENT ───────────────────────────── Dec 21
```

---

# COMPONENT 3: MONDAY-STYLE BACKEND

## Status: 📋 DESIGNED, READY TO BUILD

**Purpose:** Case management, task tracking, team coordination. The "work" behind the "board."

### Case Management

```
┌─────────────────────────────────────────────────────────────────────┐
│ ALL CASES                                          [+ New Case]    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ● Doe v. Memorial Hospital                                        │
│    Status: Active │ 67 docs │ 14 contradictions │ Updated: 2h ago │
│    Team: Sarah, Mike │ Next deadline: Dec 28                       │
│                                                                     │
│  ○ Smith v. Metro Clinic                                           │
│    Status: Discovery │ 23 docs │ 3 contradictions │ Updated: 1d    │
│    Team: Jennifer │ Next deadline: Jan 5                           │
│                                                                     │
│  ○ Johnson Insurance Dispute                                       │
│    Status: Review │ 12 docs │ 0 contradictions │ Updated: 3d      │
│    Team: Mike │ No deadlines                                       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Task Board (Per Case)

```
┌─────────────────────────────────────────────────────────────────────┐
│ Doe v. Memorial Hospital - Tasks                                    │
├──────────────────┬──────────────────┬──────────────────┬───────────┤
│      TO DO       │   IN PROGRESS    │     REVIEW       │   DONE    │
├──────────────────┼──────────────────┼──────────────────┼───────────┤
│                  │                  │                  │           │
│ □ Request P&P    │ □ Schedule Smith │ □ Expert report  │ ■ Initial │
│   manual         │   deposition     │   review         │   upload  │
│   Sarah │ Dec 23 │   Mike │ Dec 28  │   Boss │ Dec 22  │           │
│                  │                  │                  │ ■ OCR     │
│ □ Expert witness │                  │                  │   complete│
│   - causation    │                  │                  │           │
│   Boss │ Jan 5   │                  │                  │ ■ AI run  │
│                  │                  │                  │   #1      │
│ ⚠️ AI FLAGGED:   │                  │                  │           │
│ Address 7-hour   │                  │                  │           │
│ gap in records   │                  │                  │           │
│                  │                  │                  │           │
└──────────────────┴──────────────────┴──────────────────┴───────────┘
```

### Workflow Stages

```
Intake → Document Collection → AI Analysis → Attorney Review → 
Expert Phase → Discovery → Deposition Prep → Trial Prep → Resolution
```

Each case moves through stages. Dashboard shows where everything is.

### Team Features
- Assign attorneys/paralegals to cases
- Track who's working on what
- Hours logging (optional)
- Deadline alerts
- Calendar integration
- Notifications

---

# COMPONENT 4: SOURCE VAULT

## Status: 📋 DESIGNED, READY TO BUILD

**Purpose:** Protect confidential informants, sensitive witnesses, protected sources. Their identity is encrypted beyond normal security.

### How It Works

**Creating a Source:**
```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔒 ADD PROTECTED SOURCE                                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Codename: ________________  (This is how they appear on board)    │
│                                                                     │
│  ─── ENCRYPTED FIELDS (Boss-only access) ───                       │
│                                                                     │
│  Real Name: ________________                                        │
│  Contact Method: ________________                                   │
│  Address: ________________                                          │
│                                                                     │
│  ─── VISIBLE FIELDS ───                                            │
│                                                                     │
│  Relationship to Case: Former employee, defendant's office         │
│  Type of Information: Internal communications, policy docs         │
│  Reliability Assessment: High - provided verifiable docs           │
│                                                                     │
│                                        [Cancel]  [🔐 Save Source]  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**On The Board (What Everyone Sees):**
```
┌─────────────────────────────────────┐
│ 📋 EVIDENCE                         │
├─────────────────────────────────────┤
│ Internal Memo: Staffing Shortages   │
│                                     │
│ "Management aware of monitoring     │
│ gaps since January 2024..."         │
│                                     │
│ Source: 🔒 CARDINAL                 │
│ Date: January 15, 2024              │
│                                     │
│ ⚠️ PROTECTED SOURCE                 │
└─────────────────────────────────────┘
```

**What Boss Sees (With Authorization):**
```
┌─────────────────────────────────────┐
│ 📋 EVIDENCE                         │
├─────────────────────────────────────┤
│ Internal Memo: Staffing Shortages   │
│                                     │
│ "Management aware of monitoring     │
│ gaps since January 2024..."         │
│                                     │
│ Source: 🔓 CARDINAL                 │
│   Real ID: [Click to decrypt]       │
│ Date: January 15, 2024              │
│                                     │
│ 🔐 PROTECTED - Boss access granted  │
└─────────────────────────────────────┘
```

**Security Rules:**
- Real identity encrypted with Boss-only key
- Codename used everywhere else
- Every access attempt logged
- Source info NEVER included in Wash data
- Decryption requires active authentication (not just being logged in)

---

# COMPONENT 5: PERMISSION SYSTEM

## Status: 📋 DESIGNED, READY TO BUILD

### The 5 Levels

```
┌─────────────────────────────────────────────────────────────────────┐
│ PERMISSION LEVELS                                                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  👁️  VIEWER                                                        │
│      │  • View board (filtered view)                               │
│      │  • Export sanitized reports                                 │
│      │  • Cannot edit, cannot see sources                          │
│      │  Use: Outside counsel, clients                              │
│      │                                                              │
│  ✏️  EDITOR                                                         │
│      │  • Everything Viewer can do                                 │
│      │  • Add/edit cards, notes                                    │
│      │  • Upload documents                                          │
│      │  • Cannot see sources, cannot run AI                        │
│      │  Use: Paralegals                                            │
│      │                                                              │
│  ⚙️  ANALYST                                                        │
│      │  • Everything Editor can do                                 │
│      │  • Run local AI analysis                                    │
│      │  • Full board access                                        │
│      │  • Cannot see source identities                             │
│      │  Use: Associate attorneys                                   │
│      │                                                              │
│  🔓  SENIOR                                                         │
│      │  • Everything Analyst can do                                │
│      │  • See source CODENAMES (not real IDs)                      │
│      │  • View audit logs                                          │
│      │  • Cannot decrypt sources, cannot authorize Wash            │
│      │  Use: Senior associates                                     │
│      │                                                              │
│  👑  BOSS                                                           │
│      │  • EVERYTHING                                               │
│      │  • Decrypt source identities                                │
│      │  • Authorize Wash runs                                       │
│      │  • Manage users and permissions                             │
│      │  • Access all audit logs                                    │
│      │  Use: Partners, firm owner                                  │
│      │                                                              │
└─────────────────────────────────────────────────────────────────────┘
```

### Access Control Matrix

| Resource | 👁️ Viewer | ✏️ Editor | ⚙️ Analyst | 🔓 Senior | 👑 Boss |
|----------|----------|----------|-----------|----------|--------|
| View board | Filtered | ✓ | ✓ | ✓ | ✓ |
| Edit elements | - | ✓ | ✓ | ✓ | ✓ |
| Upload docs | - | ✓ | ✓ | ✓ | ✓ |
| Run local AI | - | - | ✓ | ✓ | ✓ |
| See source codenames | - | - | - | ✓ | ✓ |
| Decrypt source ID | - | - | - | - | ✓ |
| Request Wash | - | ✓ | ✓ | ✓ | ✓ |
| Approve Wash | - | - | - | - | ✓ |
| View audit log | - | - | - | ✓ | ✓ |
| Manage users | - | - | - | - | ✓ |
| Delete cases | - | - | - | - | ✓ |

---

# COMPONENT 6: TWO OPERATING MODES

## Status: 📋 DESIGNED, READY TO BUILD

### Mode 1: PRIVATE (Default)

**What It Means:**
- ALL processing on local hardware
- NO data leaves the building
- Full detail visible (based on permission)
- Sources accessible to authorized users
- AI runs on local Ollama

**UI Indicator:**
```
┌─────────────────────────────────────────────────────────────────────┐
│ 🟢 PRIVATE MODE                                   [Switch Mode ▼]  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  All data local. Full detail. Sources protected by permission.     │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │                    [CORK BOARD]                             │   │
│  │                                                             │   │
│  │     Dr. James Smith          Jane Doe                       │   │
│  │     123 Main Street          456 Oak Ave                    │   │
│  │     SSN: XXX-XX-1234         DOB: 03/15/1972               │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Mode 2: WASH (Preview / Active)

**What It Means:**
- Shows ANONYMIZED view of data
- What external AI would see if Wash is run
- All names → Party_A, Party_B
- All addresses → Location_A
- Protected sources → [REDACTED]
- SSNs, phones, emails → stripped

**UI Indicator:**
```
┌─────────────────────────────────────────────────────────────────────┐
│ 🟡 WASH MODE (Preview)                            [Switch Mode ▼]  │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ⚠️ Showing what external AI will see. No real data exposed.       │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                                                             │   │
│  │                    [CORK BOARD]                             │   │
│  │                                                             │   │
│  │     Provider_A               Patient_A                      │   │
│  │     [Location_A]             [Location_B]                   │   │
│  │     [REDACTED]               DOB: [REDACTED]                │   │
│  │                                                             │   │
│  │     Source: [REDACTED - NOT SENT]                          │   │
│  │                                                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Anonymization Map:                                                 │
│  • "Dr. James Smith" → "Provider_A"                                │
│  • "Jane Doe" → "Patient_A"                                        │
│  • "Memorial Hospital" → "Facility_A"                              │
│  • Source [CARDINAL] → [NOT SENT]                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

**Use Cases:**
1. **Preview Before Wash** - Attorney sees exactly what will be sent
2. **During Wash Run** - Board shows Wash view while processing
3. **Client Demo** - Show how data is protected
4. **Training** - Teach team about the security model

---

# COMPONENT 7: THE WASH SYSTEM

## Status: 📋 DESIGNED, READY TO BUILD

### What It Is

External AI processing for heavy analysis. Uses cloud compute (Claude API, 70B+ models) while protecting data through anonymization.

### The Flow

```
┌─────────────────────────────────────────────────────────────────────┐
│ WASH RUN PROCESS                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. ANYONE can REQUEST a Wash run                                  │
│     └─→ Request goes to Boss for approval                          │
│                                                                     │
│  2. BOSS reviews in Wash Mode (preview)                            │
│     └─→ Sees exactly what will be sent                             │
│     └─→ Confirms no sensitive data exposed                         │
│                                                                     │
│  3. BOSS AUTHORIZES                                                 │
│     └─→ Requires password + 2FA                                    │
│     └─→ Logged in audit trail                                      │
│                                                                     │
│  4. SYSTEM ANONYMIZES                                               │
│     └─→ Names → Party_A, Party_B                                   │
│     └─→ Addresses → Location_A                                     │
│     └─→ SSN/Phone/Email → stripped                                 │
│     └─→ Protected sources → completely removed                     │
│     └─→ Mapping table saved locally (encrypted)                    │
│                                                                     │
│  5. ENCRYPTED TRANSFER                                              │
│     └─→ TLS 1.3 to Wash Center                                     │
│     └─→ Checksum verification                                      │
│                                                                     │
│  6. EXTERNAL PROCESSING                                             │
│     └─→ Large models analyze patterns                              │
│     └─→ Cross-reference with other cases (anonymized)              │
│     └─→ Generate insights                                          │
│                                                                     │
│  7. RESULTS RETURN                                                  │
│     └─→ Insights only (not raw data)                               │
│     └─→ "Pattern matches fraud signature 87%"                      │
│     └─→ Boss reviews first                                         │
│                                                                     │
│  8. RE-INTEGRATION                                                  │
│     └─→ System maps Party_A back to real names                     │
│     └─→ Insights attached to actual cases                          │
│     └─→ Board updated with new findings                            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### The Boss Button

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│                    🔴 RUN EXTERNAL ANALYSIS                         │
│                                                                     │
│              ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                    │
│              ⚠️  BOSS AUTHORIZATION REQUIRED                        │
│              ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                    │
│                                                                     │
│   This will:                                                        │
│   ✓ Anonymize 67 documents                                         │
│   ✓ Strip all protected source references                          │
│   ✓ Send to external AI for analysis                               │
│   ✓ Return insights only (no raw data returned)                    │
│                                                                     │
│   Documents to process: 67                                          │
│   Estimated time: 15-30 minutes                                     │
│   Estimated cost: $12.50                                            │
│                                                                     │
│   Preview: [View Wash Mode]                                         │
│                                                                     │
│          [Cancel]              [🔐 Authorize & Run]                 │
│                                                                     │
│   Requires: Password + 2FA                                          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

# COMPONENT 8: AUDIT TRAIL

## Status: 📋 DESIGNED, READY TO BUILD

**Everything is logged. Everything.**

### What's Logged

| Action | Details Captured |
|--------|------------------|
| Document upload | Who, when, filename, size, hash |
| Board edit | Who, when, what changed, before/after |
| AI run | Who triggered, what analyzed, findings |
| Source access | Who, when, which source, decrypt or just view |
| Wash request | Who requested, when |
| Wash approval | Who approved, when, what was sent |
| Login/logout | Who, when, from where (IP) |
| Permission change | Who changed, whose permission, old/new level |
| Export | Who, when, what format, what data |
| Delete | Who, when, what deleted (preserved in log) |

### Audit Log View

```
┌─────────────────────────────────────────────────────────────────────┐
│ AUDIT LOG - Doe v. Memorial Hospital                    [Export]   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ Dec 21, 4:15 PM │ Sarah (Editor)                                   │
│ EDIT │ Added sticky note in Breach zone                            │
│ Content: "DEPO PREP: Question Smith on 7-hour gap"                 │
│                                                                     │
│ Dec 21, 3:30 PM │ SYSTEM                                           │
│ AI_RUN │ Analysis complete                                          │
│ Findings: +2 contradictions, +3 timeline events                    │
│                                                                     │
│ Dec 21, 2:15 PM │ Mike (Analyst)                                   │
│ UPLOAD │ Smith_Deposition_Transcript.pdf                           │
│ Size: 2.4MB │ Pages: 127 │ Hash: a3f2c...                          │
│                                                                     │
│ Dec 21, 2:00 PM │ Boss (Boss)                                      │
│ 🔒 SOURCE_ACCESS │ Viewed source: CARDINAL                         │
│ Action: View codename (did not decrypt identity)                   │
│                                                                     │
│ Dec 20, 4:30 PM │ Boss (Boss)                                      │
│ 🌐 WASH_APPROVED │ External analysis authorized                     │
│ Documents: 67 │ Cost: $12.50 │ Duration: 18 minutes                │
│                                                                     │
│ Dec 20, 4:15 PM │ Sarah (Editor)                                   │
│ WASH_REQUEST │ Requested external analysis                          │
│ Status: Pending Boss approval                                       │
│                                                                     │
│ Dec 20, 3:00 PM │ Boss (Boss)                                      │
│ 🔓 SOURCE_DECRYPT │ Decrypted identity: CARDINAL                   │
│ Reason: Verify source reliability for Wash                         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Why This Matters

1. **Legal Discovery** - Can prove exactly what happened when
2. **Security** - Detect unauthorized access attempts
3. **Accountability** - Everyone knows their actions are logged
4. **Compliance** - Meet legal/regulatory requirements
5. **Debugging** - Reconstruct issues if something goes wrong

---

# TECHNICAL ARCHITECTURE

## Full Stack

```
┌─────────────────────────────────────────────────────────────────────┐
│                         DESKTOP APP                                 │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                      ELECTRON                                  │ │
│  │                                                                │ │
│  │  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐          │ │
│  │  │ Cork Board   │ │ Monday View  │ │ Source Vault │          │ │
│  │  │              │ │              │ │              │          │ │
│  │  │ React+Konva  │ │ React+Table  │ │ React+Forms  │          │ │
│  │  └──────────────┘ └──────────────┘ └──────────────┘          │ │
│  │                                                                │ │
│  │  React 18 + TypeScript + Tailwind + Zustand (state)           │ │
│  │                                                                │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                               │                                     │
└───────────────────────────────┼─────────────────────────────────────┘
                                │ HTTP/WebSocket
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                           BACKEND                                   │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                       FASTAPI                                  │ │
│  │                                                                │ │
│  │  /api/auth        - Login, logout, 2FA                        │ │
│  │  /api/users       - User management (Boss only)               │ │
│  │  /api/cases       - Case CRUD                                 │ │
│  │  /api/tasks       - Task management                           │ │
│  │  /api/documents   - Upload, retrieve                          │ │
│  │  /api/elements    - Board elements CRUD                       │ │
│  │  /api/connections - Element connections                       │ │
│  │  /api/versions    - Version control                           │ │
│  │  /api/sources     - Protected source vault                    │ │
│  │  /api/analysis    - Trigger local AI                          │ │
│  │  /api/wash        - Request, approve, execute Wash            │ │
│  │  /api/audit       - Audit log queries                         │ │
│  │                                                                │ │
│  │  WebSocket: Real-time board sync                              │ │
│  │                                                                │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                               │                                     │
└───────────────────────────────┼─────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          DATA LAYER                                 │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │  PostgreSQL  │  │    Qdrant    │  │    Files     │             │
│  │              │  │              │  │              │             │
│  │ • Users      │  │ • Vectors    │  │ • Documents  │             │
│  │ • Cases      │  │ • Embeddings │  │ • OCR text   │             │
│  │ • Tasks      │  │ • Similarity │  │ • Thumbnails │             │
│  │ • Elements   │  │              │  │ • Exports    │             │
│  │ • Versions   │  │              │  │              │             │
│  │ • Sources    │  │              │  │              │             │
│  │ • Audit log  │  │              │  │              │             │
│  │ • Wash runs  │  │              │  │              │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         AI LAYER                                    │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │
│  │  PaddleOCR   │  │    Ollama    │  │  Claude API  │             │
│  │  (Local)     │  │   (Local)    │  │   (Wash)     │             │
│  │              │  │              │  │              │             │
│  │ • OCR        │  │ • Llama 70B  │  │ • Heavy      │             │
│  │ • Handwriting│  │ • Tone       │  │   analysis   │             │
│  │ • Multi-lang │  │ • Entities   │  │ • Pattern    │             │
│  │              │  │ • Analysis   │  │   matching   │             │
│  │              │  │              │  │ • Anonymized │             │
│  └──────────────┘  └──────────────┘  └──────────────┘             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## Database Schema (Key Tables)

```sql
-- Users with permission levels
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    permission_level VARCHAR(20) NOT NULL,  -- viewer, editor, analyst, senior, boss
    totp_secret VARCHAR(255),  -- For 2FA
    created_at TIMESTAMP DEFAULT NOW(),
    last_login TIMESTAMP
);

-- Cases
CREATE TABLE cases (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    case_number VARCHAR(100),
    case_type VARCHAR(100),  -- med_mal, contract, employment, etc.
    status VARCHAR(50) DEFAULT 'intake',
    created_at TIMESTAMP DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    current_version_id UUID
);

-- Tasks (Monday-style)
CREATE TABLE tasks (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) DEFAULT 'todo',
    assigned_to UUID REFERENCES users(id),
    due_date DATE,
    priority VARCHAR(20) DEFAULT 'medium',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    ai_generated BOOLEAN DEFAULT FALSE
);

-- Protected Sources (Vault)
CREATE TABLE protected_sources (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    codename VARCHAR(100) NOT NULL,
    real_identity_encrypted BYTEA,  -- AES-256, Boss-only key
    contact_encrypted BYTEA,
    relationship TEXT,
    reliability VARCHAR(50),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Board Versions
CREATE TABLE versions (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_number VARCHAR(20) NOT NULL,
    parent_version_id UUID REFERENCES versions(id),
    description TEXT,
    is_branch BOOLEAN DEFAULT FALSE,
    board_state JSONB,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Board Elements
CREATE TABLE elements (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_id UUID REFERENCES versions(id),
    element_type VARCHAR(50) NOT NULL,
    position_x FLOAT,
    position_y FLOAT,
    rotation FLOAT DEFAULT 0,
    data JSONB NOT NULL,
    source_document_id UUID,
    protected_source_id UUID REFERENCES protected_sources(id),
    ai_generated BOOLEAN DEFAULT FALSE,
    ai_confidence FLOAT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Wash Runs
CREATE TABLE wash_runs (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    requested_by UUID REFERENCES users(id),
    requested_at TIMESTAMP DEFAULT NOW(),
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    document_count INT,
    anonymization_map_encrypted BYTEA,
    results JSONB,
    cost DECIMAL(10,2),
    completed_at TIMESTAMP
);

-- Audit Log (append-only)
CREATE TABLE audit_log (
    id UUID PRIMARY KEY,
    case_id UUID,
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id UUID,
    details JSONB,
    ip_address INET,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_audit_case ON audit_log(case_id);
CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_time ON audit_log(timestamp);
CREATE INDEX idx_elements_case ON elements(case_id);
CREATE INDEX idx_tasks_case ON tasks(case_id);
```

---

# GITHUB STRUCTURE

## Recommended Repository Layout

```
legal-ai-platform/
│
├── README.md                 # Project overview
├── LICENSE                   # License file
├── .gitignore               # Git ignore rules
├── docker-compose.yml       # Container orchestration
│
├── docs/                    # Documentation
│   ├── architecture.md
│   ├── api-reference.md
│   ├── security.md
│   └── user-guide.md
│
├── backend/                 # FastAPI backend
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py          # FastAPI app entry
│   │   ├── config.py        # Configuration
│   │   ├── database.py      # DB connection
│   │   │
│   │   ├── api/             # API routes
│   │   │   ├── auth.py
│   │   │   ├── cases.py
│   │   │   ├── tasks.py
│   │   │   ├── documents.py
│   │   │   ├── elements.py
│   │   │   ├── sources.py
│   │   │   ├── analysis.py
│   │   │   ├── wash.py
│   │   │   └── audit.py
│   │   │
│   │   ├── models/          # SQLAlchemy models
│   │   │   ├── user.py
│   │   │   ├── case.py
│   │   │   ├── task.py
│   │   │   ├── element.py
│   │   │   ├── source.py
│   │   │   └── audit.py
│   │   │
│   │   ├── services/        # Business logic
│   │   │   ├── ocr.py
│   │   │   ├── analysis.py
│   │   │   ├── anonymization.py
│   │   │   ├── wash.py
│   │   │   └── version_control.py
│   │   │
│   │   └── utils/           # Utilities
│   │       ├── security.py
│   │       ├── encryption.py
│   │       └── audit.py
│   │
│   ├── requirements.txt
│   ├── Dockerfile
│   └── alembic/             # DB migrations
│
├── frontend/                # React/Electron app
│   ├── src/
│   │   ├── components/
│   │   │   ├── Board/       # Cork board components
│   │   │   ├── Monday/      # Task management
│   │   │   ├── Vault/       # Source vault
│   │   │   └── Common/      # Shared components
│   │   │
│   │   ├── stores/          # Zustand state
│   │   ├── hooks/           # Custom hooks
│   │   ├── utils/           # Utilities
│   │   ├── types/           # TypeScript types
│   │   └── App.tsx
│   │
│   ├── electron/            # Electron main process
│   │   ├── main.ts
│   │   └── preload.ts
│   │
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   └── vite.config.ts
│
├── pipeline/                # RAG pipeline (already built)
│   ├── document_pipeline.py
│   ├── qdrant_manager.py
│   ├── tone_analyzer.py
│   ├── query_engine.py
│   ├── config.yaml
│   └── requirements.txt
│
└── scripts/                 # Utility scripts
    ├── setup.sh
    ├── dev.sh
    └── build.sh
```

## .gitignore

```gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
.env
venv/
.venv/

# Node
node_modules/
dist/
.next/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Secrets (NEVER commit)
*.pem
*.key
secrets.yaml
.env.local
.env.production

# Data (don't commit case data)
data/
uploads/
*.pdf
*.docx

# Logs
logs/
*.log

# Build artifacts
build/
out/
*.egg-info/

# Database
*.db
*.sqlite
```

---

# HARDWARE

## Development/Test (Ryzen Build)
- **CPU:** Ryzen 9 7900X
- **GPU:** RTX 4060 Ti 8GB
- **RAM:** 64GB
- **Storage:** NVMe SSD
- **Cost:** ~$2,460

## Production (BIZON X5500 G2)
- **CPU:** Threadripper Pro
- **GPU:** 2x RTX 5090 32GB
- **RAM:** 256GB
- **Network:** 10GbE
- **Storage:** Enterprise NVMe
- **Cost:** ~$20K

## Wash Center Options
1. **Your cloud** (AWS/GCP) - You control, moderate cost
2. **Private contractor** - They process, you pay per run
3. **Secondary on-prem** - Ultra paranoid, expensive

---

# IMPLEMENTATION PHASES

## Phase 1: Foundation ✅ COMPLETE
- [x] RAG pipeline
- [x] OCR + analysis
- [x] Vector storage
- [x] Query engine

## Phase 2: Core App 🔄 IN PROGRESS
- [x] Cork board prototype
- [ ] Set up GitHub repo ← NEXT
- [ ] Electron shell
- [ ] Backend API (basic)
- [ ] Database setup

## Phase 3: Case Management
- [ ] Monday-style backend
- [ ] Task boards
- [ ] Team assignment
- [ ] Workflows

## Phase 4: Security
- [ ] Permission system
- [ ] Source vault
- [ ] Encryption
- [ ] Audit logging

## Phase 5: Wash System
- [ ] Anonymization
- [ ] Boss approval flow
- [ ] External integration
- [ ] Mode switching

## Phase 6: Polish
- [ ] Full Electron packaging
- [ ] Auto-updates
- [ ] Backup system
- [ ] Documentation

---

# FILES FROM THIS SESSION

| File | Location | Description |
|------|----------|-------------|
| RAG Pipeline | `/home/claude/legal-rag-pipeline/` | Complete Python pipeline |
| Board Prototype v2 | `/mnt/user-data/outputs/investigation-board-v2.html` | Polished UI prototype |
| Architecture Spec | `/mnt/user-data/outputs/investigation-board-architecture.md` | Technical design |
| Vision Document | `/mnt/user-data/outputs/legal-vision-final.pdf` | Client-facing doc |
| This Master Doc | Current file | Everything for handoff |

---

# TO START NEXT CONVERSATION

Copy and paste this:

```
I'm continuing a legal AI project. Here's the complete context:

[Attach: LEGAL-AI-COMPLETE-HANDOFF.md]

What we're building:
- Legal investigation platform disguised as a detective cork board
- RAG pipeline already built (OCR, AI analysis, vector storage)
- Cork board UI prototype exists
- Need to add: Monday-style backend, source vault, permissions, two-mode operation

Immediate next step:
Get everything into GitHub properly, then continue building.

Key concepts:
- "Private Mode" = all local, full detail
- "Wash Mode" = anonymized view, external processing
- Only Boss can authorize Wash runs
- Protected sources have encrypted identities
- Everything is audited

Let's get this into Git.
```

---

# CONTACT

**Wesley Thompson**
385-461-4164

---

*Document Version: 1.0*
*Created: December 21, 2024*
*Session: Complete System Design*

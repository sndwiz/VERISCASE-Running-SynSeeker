"""
Embedding Generator
===================
Generates vector embeddings using sentence transformers.
Optimized for legal document retrieval.
"""

from dataclasses import dataclass, field
from typing import Optional
import numpy as np

import torch
from sentence_transformers import SentenceTransformer

from .config import get_config
from .logger import get_logger, get_audit_logger
from .chunk_processor import TextChunk


@dataclass
class EmbeddedChunk:
    """A text chunk with its vector embedding."""
    chunk: TextChunk
    embedding: np.ndarray
    
    @property
    def vector(self) -> list[float]:
        """Get embedding as list for Qdrant."""
        return self.embedding.tolist()


class EmbeddingGenerator:
    """
    Generates embeddings for text chunks using sentence transformers.
    Supports GPU acceleration and batched processing.
    """
    
    def __init__(self):
        self.config = get_config().embedding
        self.logger = get_logger()
        self.audit = get_audit_logger()
        
        # Determine device
        if self.config.use_gpu and torch.cuda.is_available():
            self.device = "cuda"
            self.logger.info("using_gpu", device=torch.cuda.get_device_name(0))
        else:
            self.device = "cpu"
            if self.config.use_gpu:
                self.logger.warning("gpu_requested_but_not_available")
        
        # Load model
        self.logger.info(
            "loading_embedding_model",
            model=self.config.model,
            device=self.device
        )
        
        self.model = SentenceTransformer(
            self.config.model,
            device=self.device
        )
        
        # Verify dimension matches config
        test_embedding = self.model.encode("test", convert_to_numpy=True)
        actual_dim = len(test_embedding)
        
        if actual_dim != self.config.dimension:
            self.logger.warning(
                "dimension_mismatch",
                expected=self.config.dimension,
                actual=actual_dim,
                message=f"Update config.yaml embedding.dimension to {actual_dim}"
            )
        
        self.dimension = actual_dim
        
        self.logger.info(
            "embedding_model_loaded",
            model=self.config.model,
            dimension=self.dimension
        )
    
    def _prepare_text(self, text: str, is_query: bool = False) -> str:
        """
        Prepare text for embedding with appropriate prefix.
        Some models (like BGE) require prefixes for best performance.
        """
        if is_query:
            prefix = self.config.query_prefix
        else:
            prefix = self.config.document_prefix
        
        return f"{prefix}{text}" if prefix else text
    
    def embed_text(self, text: str, is_query: bool = False) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            is_query: True if this is a query (vs document)
        
        Returns:
            Numpy array of embedding vector
        """
        prepared = self._prepare_text(text, is_query)
        
        embedding = self.model.encode(
            prepared,
            convert_to_numpy=True,
            normalize_embeddings=self.config.normalize
        )
        
        return embedding
    
    def embed_texts(
        self,
        texts: list[str],
        is_query: bool = False,
        show_progress: bool = True
    ) -> list[np.ndarray]:
        """
        Generate embeddings for multiple texts (batched).
        
        Args:
            texts: List of texts to embed
            is_query: True if these are queries
            show_progress: Show progress bar
        
        Returns:
            List of numpy embedding arrays
        """
        if not texts:
            return []
        
        prepared = [self._prepare_text(t, is_query) for t in texts]
        
        embeddings = self.model.encode(
            prepared,
            batch_size=self.config.batch_size,
            convert_to_numpy=True,
            normalize_embeddings=self.config.normalize,
            show_progress_bar=show_progress
        )
        
        return list(embeddings)
    
    def embed_chunk(self, chunk: TextChunk) -> EmbeddedChunk:
        """
        Generate embedding for a text chunk.
        
        Args:
            chunk: TextChunk to embed
        
        Returns:
            EmbeddedChunk with vector
        """
        embedding = self.embed_text(chunk.text, is_query=False)
        return EmbeddedChunk(chunk=chunk, embedding=embedding)
    
    def embed_chunks(
        self,
        chunks: list[TextChunk],
        source_file: str = ""
    ) -> list[EmbeddedChunk]:
        """
        Generate embeddings for multiple chunks.
        
        Args:
            chunks: List of TextChunks to embed
            source_file: Source filename for logging
        
        Returns:
            List of EmbeddedChunks
        """
        if not chunks:
            return []
        
        self.logger.info(
            "embedding_chunks",
            source_file=source_file,
            chunk_count=len(chunks),
            model=self.config.model
        )
        
        # Extract texts
        texts = [chunk.text for chunk in chunks]
        
        # Batch embed
        embeddings = self.embed_texts(texts, is_query=False)
        
        # Create embedded chunks
        embedded = [
            EmbeddedChunk(chunk=chunk, embedding=emb)
            for chunk, emb in zip(chunks, embeddings)
        ]
        
        self.logger.info(
            "embedding_complete",
            source_file=source_file,
            chunks_embedded=len(embedded),
            dimension=self.dimension
        )
        
        self.audit.log_embedding(
            source_file=source_file,
            status="completed",
            chunks_embedded=len(embedded),
            model=self.config.model
        )
        
        return embedded
    
    def embed_query(self, query: str) -> np.ndarray:
        """
        Generate embedding for a search query.
        Uses query prefix for models that need it.
        
        Args:
            query: Search query text
        
        Returns:
            Numpy array of query embedding
        """
        return self.embed_text(query, is_query=True)
    
    def similarity(
        self,
        embedding1: np.ndarray,
        embedding2: np.ndarray
    ) -> float:
        """
        Calculate cosine similarity between two embeddings.
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
        
        Returns:
            Similarity score (0-1 for normalized vectors)
        """
        # For normalized vectors, dot product = cosine similarity
        if self.config.normalize:
            return float(np.dot(embedding1, embedding2))
        else:
            norm1 = np.linalg.norm(embedding1)
            norm2 = np.linalg.norm(embedding2)
            if norm1 == 0 or norm2 == 0:
                return 0.0
            return float(np.dot(embedding1, embedding2) / (norm1 * norm2))

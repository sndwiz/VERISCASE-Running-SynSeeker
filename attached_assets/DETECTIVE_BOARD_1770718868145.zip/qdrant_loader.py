"""
Qdrant Loader
=============
Stores and retrieves document embeddings with full metadata.
Every vector traces back to source document.
"""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional, Any
import uuid

from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.http.models import (
    Distance,
    VectorParams,
    PointStruct,
    Filter,
    FieldCondition,
    MatchValue,
    MatchAny,
    Range,
    PayloadSchemaType,
)

from .config import get_config
from .logger import get_logger, get_audit_logger
from .embedding_generator import EmbeddedChunk
from .tone_analyzer import ToneAnalysisResult


@dataclass
class DocumentPayload:
    """
    Metadata payload for each vector in Qdrant.
    This is the whole point - rich metadata for legal search.
    """
    # Source tracking
    source_file: str
    source_path: str
    file_type: str
    file_hash: str
    
    # Position in document
    page_number: Optional[int]
    chunk_index: int
    start_char: int
    end_char: int
    section_header: Optional[str]
    
    # The actual text (for reference/display)
    chunk_text: str
    
    # OCR info
    ocr_confidence: float
    
    # Tone analysis
    tone_flags: list[str]
    tone_confidence: float
    tone_summary: str
    tone_details: dict
    
    # Metadata
    upload_date: str  # ISO format
    language_detected: str
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for Qdrant payload."""
        return asdict(self)


class QdrantLoader:
    """
    Manages vector storage in Qdrant with full metadata.
    Handles collection creation, indexing, and point management.
    """
    
    def __init__(self):
        self.config = get_config().qdrant
        self.logger = get_logger()
        self.audit = get_audit_logger()
        
        # Connect to Qdrant
        self.logger.info(
            "connecting_to_qdrant",
            host=self.config.host,
            port=self.config.port
        )
        
        self.client = QdrantClient(
            host=self.config.host,
            port=self.config.port,
            grpc_port=self.config.grpc_port,
            prefer_grpc=True,
        )
        
        # Ensure collection exists
        self._ensure_collection()
        
        self.logger.info(
            "qdrant_connected",
            collection=self.config.collection_name
        )
    
    def _ensure_collection(self) -> None:
        """Create collection if it doesn't exist."""
        collections = self.client.get_collections().collections
        collection_names = [c.name for c in collections]
        
        if self.config.collection_name not in collection_names:
            self.logger.info(
                "creating_collection",
                name=self.config.collection_name,
                vector_size=self.config.vector_config.size
            )
            
            # Create collection with vector config
            self.client.create_collection(
                collection_name=self.config.collection_name,
                vectors_config=VectorParams(
                    size=self.config.vector_config.size,
                    distance=Distance.COSINE,
                ),
                hnsw_config=models.HnswConfigDiff(
                    m=self.config.indexing.hnsw_m,
                    ef_construct=self.config.indexing.hnsw_ef_construct,
                ),
                optimizers_config=models.OptimizersConfigDiff(
                    indexing_threshold=20000,
                ),
            )
            
            # Create payload indexes for filtering
            self._create_payload_indexes()
            
            self.audit.log_qdrant(
                operation_type="create_collection",
                status="completed",
                collection=self.config.collection_name
            )
        else:
            self.logger.info(
                "collection_exists",
                name=self.config.collection_name
            )
    
    def _create_payload_indexes(self) -> None:
        """Create indexes on payload fields for efficient filtering."""
        for field in self.config.indexing.payload_indexes:
            try:
                # Determine field type
                if field in ["tone_flags"]:
                    schema_type = PayloadSchemaType.KEYWORD
                elif field in ["confidence_score", "ocr_confidence", "tone_confidence"]:
                    schema_type = PayloadSchemaType.FLOAT
                elif field in ["upload_date"]:
                    schema_type = PayloadSchemaType.DATETIME
                else:
                    schema_type = PayloadSchemaType.KEYWORD
                
                self.client.create_payload_index(
                    collection_name=self.config.collection_name,
                    field_name=field,
                    field_schema=schema_type,
                )
                
                self.logger.debug(
                    "payload_index_created",
                    field=field,
                    type=str(schema_type)
                )
            except Exception as e:
                self.logger.warning(
                    "payload_index_failed",
                    field=field,
                    error=str(e)
                )
    
    def _generate_point_id(self) -> str:
        """Generate unique point ID."""
        return str(uuid.uuid4())
    
    def store_document(
        self,
        embedded_chunks: list[EmbeddedChunk],
        source_file: str,
        source_path: str,
        file_type: str,
        file_hash: str,
        ocr_confidence: float,
        tone_results: list[ToneAnalysisResult],
        language: str = "en"
    ) -> list[str]:
        """
        Store all chunks from a document with full metadata.
        
        Args:
            embedded_chunks: List of chunks with embeddings
            source_file: Original filename
            source_path: Full path to original file
            file_type: Type of file (pdf, image, etc.)
            file_hash: SHA-256 hash of original file
            ocr_confidence: Average OCR confidence
            tone_results: Tone analysis results per chunk
            language: Detected language
        
        Returns:
            List of point IDs created
        """
        if not embedded_chunks:
            return []
        
        self.logger.info(
            "storing_document",
            source_file=source_file,
            chunk_count=len(embedded_chunks)
        )
        
        upload_date = datetime.now(timezone.utc).isoformat()
        points = []
        point_ids = []
        
        # Create tone lookup by chunk index
        tone_by_chunk = {r.chunk_index: r for r in tone_results}
        
        for embedded in embedded_chunks:
            chunk = embedded.chunk
            point_id = self._generate_point_id()
            point_ids.append(point_id)
            
            # Get tone result for this chunk
            tone = tone_by_chunk.get(chunk.index, ToneAnalysisResult(
                chunk_index=chunk.index,
                flags=[],
                confidence=0.0,
                summary="No analysis",
                details={}
            ))
            
            # Build payload
            payload = DocumentPayload(
                source_file=source_file,
                source_path=source_path,
                file_type=file_type,
                file_hash=file_hash,
                page_number=chunk.page_number,
                chunk_index=chunk.index,
                start_char=chunk.start_char,
                end_char=chunk.end_char,
                section_header=chunk.section_header,
                chunk_text=chunk.text,
                ocr_confidence=ocr_confidence,
                tone_flags=tone.flags,
                tone_confidence=tone.confidence,
                tone_summary=tone.summary,
                tone_details=tone.details,
                upload_date=upload_date,
                language_detected=language,
            )
            
            points.append(PointStruct(
                id=point_id,
                vector=embedded.vector,
                payload=payload.to_dict()
            ))
        
        # Upsert in batches
        batch_size = 100
        for i in range(0, len(points), batch_size):
            batch = points[i:i + batch_size]
            self.client.upsert(
                collection_name=self.config.collection_name,
                points=batch,
            )
        
        self.logger.info(
            "document_stored",
            source_file=source_file,
            points_created=len(point_ids)
        )
        
        self.audit.log_qdrant(
            operation_type="store_document",
            status="completed",
            collection=self.config.collection_name,
            points_affected=len(point_ids),
            source_file=source_file
        )
        
        return point_ids
    
    def delete_by_source(self, source_file: str) -> int:
        """
        Delete all points from a source file.
        
        Args:
            source_file: Filename to delete
        
        Returns:
            Number of points deleted
        """
        # First count existing points
        count_result = self.client.count(
            collection_name=self.config.collection_name,
            count_filter=Filter(
                must=[
                    FieldCondition(
                        key="source_file",
                        match=MatchValue(value=source_file)
                    )
                ]
            )
        )
        
        count = count_result.count
        
        if count > 0:
            self.client.delete(
                collection_name=self.config.collection_name,
                points_selector=models.FilterSelector(
                    filter=Filter(
                        must=[
                            FieldCondition(
                                key="source_file",
                                match=MatchValue(value=source_file)
                            )
                        ]
                    )
                )
            )
            
            self.logger.info(
                "points_deleted",
                source_file=source_file,
                count=count
            )
            
            self.audit.log_qdrant(
                operation_type="delete_by_source",
                status="completed",
                collection=self.config.collection_name,
                points_affected=count,
                source_file=source_file
            )
        
        return count
    
    def get_collection_info(self) -> dict:
        """Get collection statistics."""
        info = self.client.get_collection(self.config.collection_name)
        return {
            "name": self.config.collection_name,
            "vectors_count": info.vectors_count,
            "points_count": info.points_count,
            "indexed_vectors_count": info.indexed_vectors_count,
            "status": info.status.value,
        }
    
    def list_sources(self) -> list[str]:
        """List all unique source files in the collection."""
        # Scroll through all points to get unique sources
        sources = set()
        offset = None
        
        while True:
            results, offset = self.client.scroll(
                collection_name=self.config.collection_name,
                limit=1000,
                offset=offset,
                with_payload=["source_file"],
                with_vectors=False,
            )
            
            for point in results:
                if "source_file" in point.payload:
                    sources.add(point.payload["source_file"])
            
            if offset is None:
                break
        
        return sorted(sources)

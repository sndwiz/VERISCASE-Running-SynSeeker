# Legal AI RAG Pipeline

Privacy-preserving document analysis system for legal case files. Extracts text from any format, analyzes tone/intent/contradictions, and stores searchable embeddings in Qdrant.

## Features

- **Universal OCR**: PDFs, scans, images, handwriting via PaddleOCR
- **Intelligent Chunking**: Respects paragraphs and sections (not arbitrary 512-token splits)
- **Tone Analysis**: Contradictions, evasive language, timeline issues, aggressive/defensive markers
- **Vector Search**: Find patterns across all cases with Qdrant
- **Full Traceability**: Every vector links back to source document + page
- **Audit Trail**: Immutable log of all operations for legal compliance

## Quick Start

### 1. Prerequisites

```bash
# Python 3.10+
python --version

# Docker (for Qdrant)
docker --version
```

### 2. Setup

```bash
# Clone and enter directory
cd legal-rag-pipeline

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Download spaCy model
python -m spacy download en_core_web_lg

# Set API key (if using Claude for tone analysis)
export ANTHROPIC_API_KEY="your-key-here"
```

### 3. Start Infrastructure

```bash
# Start Qdrant (vector database)
docker compose up -d qdrant

# Optional: Start Ollama for local LLM
docker compose up -d ollama

# Optional: Pull Llama model (if using local LLM)
docker exec legal-rag-ollama ollama pull llama3:70b
```

### 4. Process Documents

```bash
# Put documents in data/input/
cp your-documents/* data/input/

# Process all files
python main.py process

# Process single file
python main.py process -f data/input/document.pdf

# Check status
python main.py status
```

### 5. Search

```bash
# Search for content
python qdrant_query.py "conflicting statements about timeline"

# Find contradictions
python qdrant_query.py --contradictions

# Find evasive language
python qdrant_query.py --evasive

# Export results
python qdrant_query.py "timeline issues" --export json > results.json
```

## Configuration

Edit `config/config.yaml` to customize:

```yaml
# OCR settings
ocr:
  confidence_threshold: 0.85
  use_gpu: true

# Tone analysis
tone_analysis:
  provider: "claude"  # or "ollama" for local
  
# Embedding model
embedding:
  model: "BAAI/bge-large-en-v1.5"
  
# Qdrant
qdrant:
  host: "localhost"
  port: 6333
```

## Project Structure

```
legal-rag-pipeline/
├── main.py                 # Entry point
├── qdrant_query.py         # Search interface
├── config/
│   └── config.yaml         # Configuration
├── src/
│   ├── config.py           # Config loader
│   ├── logger.py           # Structured logging + audit
│   ├── file_handler.py     # File detection/loading
│   ├── ocr_processor.py    # PaddleOCR wrapper
│   ├── tone_analyzer.py    # Claude/Ollama analysis
│   ├── chunk_processor.py  # Semantic chunking
│   ├── embedding_generator.py  # Vector embeddings
│   ├── qdrant_loader.py    # Vector storage
│   └── document_pipeline.py    # Orchestrator
├── data/
│   ├── input/              # Drop files here
│   ├── processed/          # After processing
│   └── archive/            # Original backups
├── logs/
│   ├── pipeline.log        # Operations log
│   └── audit.log           # Immutable audit trail
├── docker-compose.yml      # Infrastructure
└── requirements.txt        # Dependencies
```

## Pipeline Flow

```
File Upload
    │
    ▼
File Handler (detect type, validate)
    │
    ▼
OCR Processor (PaddleOCR → text + confidence)
    │
    ▼
Chunk Processor (semantic boundaries, preserve context)
    │
    ▼
Tone Analyzer (Claude/Ollama → flags + patterns)
    │
    ▼
Embedding Generator (sentence-transformers → vectors)
    │
    ▼
Qdrant Loader (store with full metadata)
    │
    ▼
Searchable Database
```

## Metadata Stored Per Chunk

```json
{
  "source_file": "deposition_smith_2024.pdf",
  "source_path": "/full/path/to/file.pdf",
  "file_type": "pdf",
  "file_hash": "sha256...",
  "page_number": 5,
  "chunk_index": 12,
  "chunk_text": "The actual text content...",
  "ocr_confidence": 0.94,
  "tone_flags": ["contradictory", "evasive"],
  "tone_summary": "Statement conflicts with prior testimony",
  "tone_confidence": 0.87,
  "upload_date": "2024-01-15T10:30:00Z",
  "language_detected": "en"
}
```

## Hardware Requirements

**Test Environment** (Ryzen build):
- CPU: Ryzen 9 7900X
- GPU: RTX 4060 Ti 8GB
- RAM: 64GB
- Est. throughput: ~10 pages/minute

**Production Environment** (BIZON X5500):
- CPU: Threadripper Pro
- GPU: 2x RTX 5090 32GB
- RAM: 256GB
- Est. throughput: ~100+ pages/minute

## Tone Flags

The system detects:

| Flag | Description |
|------|-------------|
| `contradictory` | Statements that conflict with each other |
| `evasive` | Vague, non-committal language |
| `aggressive` | Hostile or confrontational tone |
| `defensive` | Over-explaining, deflection |
| `timeline_issue` | Chronological inconsistencies |
| `detail_inconsistency` | Varying specificity levels |
| `unusual_word_choice` | Suspicious phrasing |
| `missing_info` | Expected information absent |

## API Usage

```python
from src.document_pipeline import DocumentPipeline
from qdrant_query import QdrantQuery

# Process a document
pipeline = DocumentPipeline()
result = pipeline.process_file("document.pdf")
print(f"Stored {result.points_stored} vectors")

# Search
query = QdrantQuery()
results = query.search("conflicting statements")
query.display_results(results)

# Find specific patterns
contradictions = query.find_contradictions()
```

## Troubleshooting

**OCR quality issues:**
- Check `logs/pipeline.log` for confidence scores
- Low confidence pages are flagged automatically
- Try increasing `pdf_dpi` in config for scans

**Tone analysis not working:**
- Verify `ANTHROPIC_API_KEY` is set (for Claude)
- Or switch to `provider: ollama` and pull model first
- Check `logs/audit.log` for errors

**Qdrant connection issues:**
```bash
docker compose logs qdrant
docker compose restart qdrant
```

## License

Proprietary - Internal use only.

## Contact

Wesley Thompson - 385-461-4164

"""
Chunk Processor
===============
Intelligently chunks documents by semantic boundaries.
Respects paragraphs, sections, and sentence structure.
NOT arbitrary 512-token chunks - this is legal-aware chunking.
"""

import re
from dataclasses import dataclass, field
from typing import Optional

from .config import get_config
from .logger import get_logger


@dataclass
class TextChunk:
    """A semantically meaningful chunk of text."""
    index: int
    text: str
    start_char: int  # Character offset in original document
    end_char: int
    page_number: Optional[int] = None  # If from multi-page document
    section_header: Optional[str] = None  # Section title if detected
    metadata: dict = field(default_factory=dict)
    
    @property
    def char_count(self) -> int:
        return len(self.text)


class ChunkProcessor:
    """
    Chunks documents intelligently by semantic boundaries.
    Prioritizes paragraph and sentence boundaries over arbitrary cuts.
    """
    
    # Patterns for section headers (common in legal docs)
    SECTION_PATTERNS = [
        r'^(?:SECTION|Section|ARTICLE|Article)\s+\d+',
        r'^\d+\.\s+[A-Z][A-Za-z\s]+$',
        r'^[A-Z][A-Z\s]{2,}$',  # ALL CAPS headers
        r'^(?:I{1,3}|IV|VI{0,3}|IX|X{0,3})[\.\)]\s+',  # Roman numerals
    ]
    
    # Sentence ending patterns
    SENTENCE_END = re.compile(r'[.!?]\s+(?=[A-Z])|[.!?]$')
    
    def __init__(self):
        self.config = get_config().chunking
        self.logger = get_logger()
        
        # Compile section patterns
        self.section_regex = re.compile(
            '|'.join(f'({p})' for p in self.SECTION_PATTERNS),
            re.MULTILINE
        )
    
    def _split_into_paragraphs(self, text: str) -> list[tuple[str, int]]:
        """
        Split text into paragraphs with their starting positions.
        
        Returns:
            List of (paragraph_text, start_position) tuples
        """
        paragraphs = []
        current_pos = 0
        
        # Split on double newlines (paragraph breaks)
        parts = re.split(r'\n\s*\n', text)
        
        for part in parts:
            part = part.strip()
            if part:
                # Find actual position in original text
                start = text.find(part, current_pos)
                if start == -1:
                    start = current_pos
                paragraphs.append((part, start))
                current_pos = start + len(part)
        
        return paragraphs
    
    def _split_into_sentences(self, text: str) -> list[str]:
        """Split text into sentences."""
        # Handle common abbreviations to avoid false splits
        protected = text
        abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Inc.', 'Ltd.', 
                        'Corp.', 'vs.', 'v.', 'e.g.', 'i.e.', 'etc.', 'U.S.']
        
        placeholders = {}
        for i, abbr in enumerate(abbreviations):
            placeholder = f"__ABBR{i}__"
            placeholders[placeholder] = abbr
            protected = protected.replace(abbr, placeholder)
        
        # Split on sentence boundaries
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', protected)
        
        # Restore abbreviations
        result = []
        for sent in sentences:
            for placeholder, abbr in placeholders.items():
                sent = sent.replace(placeholder, abbr)
            result.append(sent.strip())
        
        return [s for s in result if s]
    
    def _detect_section_header(self, text: str) -> Optional[str]:
        """Detect if text starts with a section header."""
        lines = text.strip().split('\n')
        if lines:
            first_line = lines[0].strip()
            if self.section_regex.match(first_line):
                return first_line
        return None
    
    def _merge_small_chunks(self, chunks: list[TextChunk]) -> list[TextChunk]:
        """Merge chunks that are too small."""
        if not chunks:
            return chunks
        
        min_size = self.config.semantic.min_chunk_size
        merged = []
        current = None
        
        for chunk in chunks:
            if current is None:
                current = chunk
            elif current.char_count < min_size:
                # Merge with next chunk
                current = TextChunk(
                    index=current.index,
                    text=current.text + "\n\n" + chunk.text,
                    start_char=current.start_char,
                    end_char=chunk.end_char,
                    page_number=current.page_number,
                    section_header=current.section_header,
                    metadata={**current.metadata, **chunk.metadata}
                )
            else:
                merged.append(current)
                current = chunk
        
        if current:
            merged.append(current)
        
        return merged
    
    def _add_overlap(self, chunks: list[TextChunk], original_text: str) -> list[TextChunk]:
        """Add sentence overlap between chunks for context preservation."""
        if not chunks or self.config.semantic.overlap_sentences == 0:
            return chunks
        
        overlap_count = self.config.semantic.overlap_sentences
        
        for i in range(1, len(chunks)):
            prev_chunk = chunks[i - 1]
            current_chunk = chunks[i]
            
            # Get last N sentences from previous chunk
            prev_sentences = self._split_into_sentences(prev_chunk.text)
            overlap_sentences = prev_sentences[-overlap_count:] if prev_sentences else []
            
            if overlap_sentences:
                overlap_text = " ".join(overlap_sentences)
                current_chunk.text = f"[...] {overlap_text}\n\n{current_chunk.text}"
                current_chunk.metadata["has_overlap"] = True
        
        return chunks
    
    def chunk_semantic(self, text: str, page_number: Optional[int] = None) -> list[TextChunk]:
        """
        Chunk text using semantic boundaries (paragraphs, sentences).
        
        Args:
            text: Text to chunk
            page_number: Page number if from multi-page document
        
        Returns:
            List of TextChunk objects
        """
        target_size = self.config.semantic.target_chunk_size
        max_size = self.config.semantic.max_chunk_size
        
        paragraphs = self._split_into_paragraphs(text)
        chunks: list[TextChunk] = []
        
        current_text = ""
        current_start = 0
        current_section = None
        chunk_index = 0
        
        for para_text, para_start in paragraphs:
            # Check for section header
            section = self._detect_section_header(para_text)
            
            # If we hit a new section and have content, start new chunk
            if section and current_text.strip() and self.config.semantic.respect_sections:
                chunks.append(TextChunk(
                    index=chunk_index,
                    text=current_text.strip(),
                    start_char=current_start,
                    end_char=para_start,
                    page_number=page_number,
                    section_header=current_section,
                ))
                chunk_index += 1
                current_text = ""
                current_start = para_start
                current_section = section
            
            # Check if adding this paragraph exceeds max size
            potential_size = len(current_text) + len(para_text) + 2  # +2 for \n\n
            
            if potential_size > max_size and current_text.strip():
                # Need to split - try to split at sentence boundary
                if len(para_text) > max_size:
                    # Paragraph itself is too large, split by sentences
                    sentences = self._split_into_sentences(para_text)
                    
                    # First, save current content
                    if current_text.strip():
                        chunks.append(TextChunk(
                            index=chunk_index,
                            text=current_text.strip(),
                            start_char=current_start,
                            end_char=para_start,
                            page_number=page_number,
                            section_header=current_section,
                        ))
                        chunk_index += 1
                        current_text = ""
                        current_start = para_start
                    
                    # Add sentences until we hit target
                    for sent in sentences:
                        if len(current_text) + len(sent) > target_size and current_text:
                            chunks.append(TextChunk(
                                index=chunk_index,
                                text=current_text.strip(),
                                start_char=current_start,
                                end_char=current_start + len(current_text),
                                page_number=page_number,
                                section_header=current_section,
                            ))
                            chunk_index += 1
                            current_text = sent + " "
                            current_start = current_start + len(current_text)
                        else:
                            current_text += sent + " "
                else:
                    # Save current chunk, start new one with this paragraph
                    chunks.append(TextChunk(
                        index=chunk_index,
                        text=current_text.strip(),
                        start_char=current_start,
                        end_char=para_start,
                        page_number=page_number,
                        section_header=current_section,
                    ))
                    chunk_index += 1
                    current_text = para_text + "\n\n"
                    current_start = para_start
                    if section:
                        current_section = section
            
            elif len(current_text) >= target_size and self.config.semantic.respect_paragraphs:
                # Hit target size at paragraph boundary
                chunks.append(TextChunk(
                    index=chunk_index,
                    text=current_text.strip(),
                    start_char=current_start,
                    end_char=para_start,
                    page_number=page_number,
                    section_header=current_section,
                ))
                chunk_index += 1
                current_text = para_text + "\n\n"
                current_start = para_start
                if section:
                    current_section = section
            
            else:
                # Keep accumulating
                current_text += para_text + "\n\n"
                if section:
                    current_section = section
        
        # Don't forget the last chunk
        if current_text.strip():
            chunks.append(TextChunk(
                index=chunk_index,
                text=current_text.strip(),
                start_char=current_start,
                end_char=len(text),
                page_number=page_number,
                section_header=current_section,
            ))
        
        # Merge small chunks
        chunks = self._merge_small_chunks(chunks)
        
        # Re-index after merging
        for i, chunk in enumerate(chunks):
            chunk.index = i
        
        # Add overlap
        chunks = self._add_overlap(chunks, text)
        
        return chunks
    
    def chunk_sliding(self, text: str, page_number: Optional[int] = None) -> list[TextChunk]:
        """
        Chunk text using sliding window (fallback method).
        
        Args:
            text: Text to chunk
            page_number: Page number if from multi-page document
        
        Returns:
            List of TextChunk objects
        """
        window_size = self.config.sliding.window_size
        overlap = self.config.sliding.overlap
        step = window_size - overlap
        
        chunks = []
        chunk_index = 0
        
        for start in range(0, len(text), step):
            end = min(start + window_size, len(text))
            chunk_text = text[start:end]
            
            if chunk_text.strip():
                chunks.append(TextChunk(
                    index=chunk_index,
                    text=chunk_text,
                    start_char=start,
                    end_char=end,
                    page_number=page_number,
                    metadata={"method": "sliding_window"}
                ))
                chunk_index += 1
            
            if end >= len(text):
                break
        
        return chunks
    
    def chunk(self, text: str, page_number: Optional[int] = None) -> list[TextChunk]:
        """
        Chunk text using configured strategy.
        
        Args:
            text: Text to chunk
            page_number: Page number if from multi-page document
        
        Returns:
            List of TextChunk objects
        """
        if not text.strip():
            return []
        
        self.logger.debug(
            "chunking_text",
            strategy=self.config.strategy,
            text_length=len(text)
        )
        
        if self.config.strategy == "semantic":
            chunks = self.chunk_semantic(text, page_number)
        else:
            chunks = self.chunk_sliding(text, page_number)
        
        self.logger.info(
            "chunking_complete",
            strategy=self.config.strategy,
            input_length=len(text),
            chunk_count=len(chunks),
            avg_chunk_size=sum(c.char_count for c in chunks) / len(chunks) if chunks else 0
        )
        
        return chunks
    
    def chunk_document_pages(
        self,
        pages: list[tuple[int, str]]  # (page_number, text)
    ) -> list[TextChunk]:
        """
        Chunk a multi-page document, preserving page numbers.
        
        Args:
            pages: List of (page_number, text) tuples
        
        Returns:
            List of TextChunk objects with page numbers
        """
        all_chunks: list[TextChunk] = []
        global_index = 0
        
        for page_num, page_text in pages:
            page_chunks = self.chunk(page_text, page_number=page_num)
            
            # Update indices to be global
            for chunk in page_chunks:
                chunk.index = global_index
                global_index += 1
            
            all_chunks.extend(page_chunks)
        
        self.logger.info(
            "document_chunking_complete",
            page_count=len(pages),
            total_chunks=len(all_chunks)
        )
        
        return all_chunks

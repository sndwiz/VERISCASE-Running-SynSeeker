#!/usr/bin/env python3
"""
Legal AI RAG Pipeline - Main Entry Point
=========================================
Process legal documents through OCR → Tone Analysis → Embedding → Storage
"""

import argparse
import sys
from pathlib import Path

from src.document_pipeline import DocumentPipeline
from src.logger import setup_logging, get_logger
from src.config import load_config


def process_files(args):
    """Process files or directory."""
    pipeline = DocumentPipeline()
    
    if args.file:
        result = pipeline.process_file(args.file)
        if result.success:
            print(f"✓ Processed {result.source_file}")
            print(f"  Pages: {result.page_count}")
            print(f"  Chunks: {result.chunk_count}")
            print(f"  Stored: {result.points_stored} vectors")
            print(f"  OCR Confidence: {result.ocr_confidence:.1%}")
            if result.tone_flags:
                print(f"  Tone Flags: {', '.join(result.tone_flags.keys())}")
            print(f"  Time: {result.processing_time_seconds:.1f}s")
        else:
            print(f"✗ Failed: {result.source_file}")
            print(f"  Error: {result.error}")
            sys.exit(1)
    
    elif args.directory:
        results = pipeline.process_directory(
            directory=args.directory,
            max_files=args.max_files
        )
        
        successful = sum(1 for r in results if r.success)
        failed = sum(1 for r in results if not r.success)
        
        print(f"\n{'='*50}")
        print(f"Batch Processing Complete")
        print(f"{'='*50}")
        print(f"Total Files: {len(results)}")
        print(f"Successful: {successful}")
        print(f"Failed: {failed}")
        
        if failed > 0:
            print(f"\nFailed files:")
            for r in results:
                if not r.success:
                    print(f"  - {r.source_file}: {r.error}")
    
    else:
        # Default: process input directory
        results = pipeline.process_directory(max_files=args.max_files)
        
        successful = sum(1 for r in results if r.success)
        print(f"\nProcessed {successful}/{len(results)} files from input directory")


def show_status(args):
    """Show pipeline status."""
    pipeline = DocumentPipeline()
    status = pipeline.get_status()
    
    print("\n=== Pipeline Status ===")
    print(f"\nCollection: {status['collection']['name']}")
    print(f"  Vectors: {status['collection']['vectors_count']}")
    print(f"  Status: {status['collection']['status']}")
    
    print(f"\nSources indexed: {len(status['sources'])}")
    for source in status['sources'][:10]:
        print(f"  - {source}")
    if len(status['sources']) > 10:
        print(f"  ... and {len(status['sources']) - 10} more")
    
    print(f"\nConfiguration:")
    print(f"  OCR Threshold: {status['config']['ocr_threshold']}")
    print(f"  Tone Provider: {status['config']['tone_provider']}")
    print(f"  Embedding Model: {status['config']['embedding_model']}")


def main():
    parser = argparse.ArgumentParser(
        description="Legal AI RAG Pipeline - Document Processing",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process a single file
  python main.py process -f document.pdf
  
  # Process all files in input directory
  python main.py process
  
  # Process specific directory
  python main.py process -d /path/to/docs
  
  # Show pipeline status
  python main.py status
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Process command
    process_parser = subparsers.add_parser("process", help="Process documents")
    process_parser.add_argument("-f", "--file", help="Single file to process")
    process_parser.add_argument("-d", "--directory", help="Directory to process")
    process_parser.add_argument("-n", "--max-files", type=int, help="Max files to process")
    process_parser.set_defaults(func=process_files)
    
    # Status command
    status_parser = subparsers.add_parser("status", help="Show pipeline status")
    status_parser.set_defaults(func=show_status)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == "__main__":
    main()

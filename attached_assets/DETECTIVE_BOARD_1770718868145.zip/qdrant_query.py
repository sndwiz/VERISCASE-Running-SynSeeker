"""
Qdrant Query Interface
======================
Search and retrieve documents with context.
Designed for attorney use - returns source + tone context.
"""

from dataclasses import dataclass, field
from typing import Optional, Any
from enum import Enum

from qdrant_client import QdrantClient
from qdrant_client.http.models import (
    Filter,
    FieldCondition,
    MatchValue,
    MatchAny,
    Range,
    SearchParams,
)
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from src.config import get_config
from src.logger import get_logger
from src.embedding_generator import EmbeddingGenerator


class ToneFilter(Enum):
    """Pre-defined tone filters for common searches."""
    CONTRADICTIONS = ["contradictory", "timeline_issue"]
    EVASIVE = ["evasive", "missing_info"]
    AGGRESSIVE = ["aggressive", "defensive"]
    ALL_FLAGS = ["contradictory", "evasive", "aggressive", "defensive", 
                 "timeline_issue", "detail_inconsistency", "unusual_word_choice", "missing_info"]


@dataclass
class SearchResult:
    """A single search result with full context."""
    score: float
    chunk_text: str
    source_file: str
    source_path: str
    page_number: Optional[int]
    chunk_index: int
    section_header: Optional[str]
    tone_flags: list[str]
    tone_summary: str
    tone_confidence: float
    ocr_confidence: float
    upload_date: str
    point_id: str
    
    @property
    def has_tone_issues(self) -> bool:
        return len(self.tone_flags) > 0


@dataclass 
class SearchResponse:
    """Complete search response."""
    query: str
    results: list[SearchResult]
    total_found: int
    filters_applied: dict = field(default_factory=dict)


class QdrantQuery:
    """
    Search interface for querying the legal document database.
    Returns results with full source and tone context.
    """
    
    def __init__(self):
        self.config = get_config().qdrant
        self.logger = get_logger()
        self.console = Console()
        
        # Connect to Qdrant
        self.client = QdrantClient(
            host=self.config.host,
            port=self.config.port,
            prefer_grpc=True,
        )
        
        # Initialize embedding generator for query encoding
        self.embedder = EmbeddingGenerator()
        
        self.logger.info("query_interface_initialized")
    
    def _build_filter(
        self,
        source_files: Optional[list[str]] = None,
        tone_flags: Optional[list[str]] = None,
        min_ocr_confidence: Optional[float] = None,
        file_types: Optional[list[str]] = None,
    ) -> Optional[Filter]:
        """Build Qdrant filter from parameters."""
        conditions = []
        
        if source_files:
            conditions.append(
                FieldCondition(
                    key="source_file",
                    match=MatchAny(any=source_files)
                )
            )
        
        if tone_flags:
            # Match any of the specified flags
            for flag in tone_flags:
                conditions.append(
                    FieldCondition(
                        key="tone_flags",
                        match=MatchValue(value=flag)
                    )
                )
        
        if min_ocr_confidence is not None:
            conditions.append(
                FieldCondition(
                    key="ocr_confidence",
                    range=Range(gte=min_ocr_confidence)
                )
            )
        
        if file_types:
            conditions.append(
                FieldCondition(
                    key="file_type",
                    match=MatchAny(any=file_types)
                )
            )
        
        if conditions:
            return Filter(must=conditions)
        return None
    
    def search(
        self,
        query: str,
        limit: int = 10,
        source_files: Optional[list[str]] = None,
        tone_flags: Optional[list[str]] = None,
        tone_filter: Optional[ToneFilter] = None,
        min_ocr_confidence: Optional[float] = None,
        file_types: Optional[list[str]] = None,
        score_threshold: Optional[float] = None,
    ) -> SearchResponse:
        """
        Search for relevant passages.
        
        Args:
            query: Natural language search query
            limit: Maximum results to return
            source_files: Filter to specific source files
            tone_flags: Filter to chunks with these tone flags
            tone_filter: Pre-defined tone filter
            min_ocr_confidence: Minimum OCR confidence threshold
            file_types: Filter to specific file types
            score_threshold: Minimum similarity score
        
        Returns:
            SearchResponse with results and context
        """
        self.logger.info("searching", query=query[:100], limit=limit)
        
        # Use tone_filter if provided
        if tone_filter is not None:
            tone_flags = tone_filter.value
        
        # Generate query embedding
        query_vector = self.embedder.embed_query(query)
        
        # Build filter
        search_filter = self._build_filter(
            source_files=source_files,
            tone_flags=tone_flags,
            min_ocr_confidence=min_ocr_confidence,
            file_types=file_types,
        )
        
        # Search
        search_results = self.client.search(
            collection_name=self.config.collection_name,
            query_vector=query_vector.tolist(),
            limit=limit,
            query_filter=search_filter,
            search_params=SearchParams(
                hnsw_ef=self.config.query.hnsw_ef,
            ),
            score_threshold=score_threshold or self.config.query.score_threshold,
        )
        
        # Convert to SearchResult objects
        results = []
        for hit in search_results:
            payload = hit.payload
            results.append(SearchResult(
                score=hit.score,
                chunk_text=payload.get("chunk_text", ""),
                source_file=payload.get("source_file", ""),
                source_path=payload.get("source_path", ""),
                page_number=payload.get("page_number"),
                chunk_index=payload.get("chunk_index", 0),
                section_header=payload.get("section_header"),
                tone_flags=payload.get("tone_flags", []),
                tone_summary=payload.get("tone_summary", ""),
                tone_confidence=payload.get("tone_confidence", 0.0),
                ocr_confidence=payload.get("ocr_confidence", 0.0),
                upload_date=payload.get("upload_date", ""),
                point_id=str(hit.id),
            ))
        
        self.logger.info(
            "search_complete",
            query=query[:50],
            results_found=len(results)
        )
        
        return SearchResponse(
            query=query,
            results=results,
            total_found=len(results),
            filters_applied={
                "source_files": source_files,
                "tone_flags": tone_flags,
                "min_ocr_confidence": min_ocr_confidence,
                "file_types": file_types,
            }
        )
    
    def find_contradictions(
        self,
        source_files: Optional[list[str]] = None,
        limit: int = 50
    ) -> SearchResponse:
        """
        Find all contradictions across cases.
        
        Args:
            source_files: Filter to specific files
            limit: Maximum results
        
        Returns:
            SearchResponse with contradictory passages
        """
        return self.search(
            query="contradictory statements inconsistent claims conflicting information",
            limit=limit,
            source_files=source_files,
            tone_filter=ToneFilter.CONTRADICTIONS,
        )
    
    def find_evasive_language(
        self,
        source_files: Optional[list[str]] = None,
        limit: int = 50
    ) -> SearchResponse:
        """
        Find evasive or unclear language.
        
        Args:
            source_files: Filter to specific files
            limit: Maximum results
        
        Returns:
            SearchResponse with evasive passages
        """
        return self.search(
            query="vague response unclear answer avoiding question hedge language",
            limit=limit,
            source_files=source_files,
            tone_filter=ToneFilter.EVASIVE,
        )
    
    def display_results(self, response: SearchResponse) -> None:
        """
        Display search results in a formatted table.
        
        Args:
            response: SearchResponse to display
        """
        self.console.print(f"\n[bold]Query:[/bold] {response.query}")
        self.console.print(f"[dim]Found {response.total_found} results[/dim]\n")
        
        for i, result in enumerate(response.results, 1):
            # Create header with source info
            header = f"[{i}] {result.source_file}"
            if result.page_number:
                header += f" (Page {result.page_number})"
            header += f" | Score: {result.score:.3f}"
            
            # Tone flags indicator
            if result.tone_flags:
                flags_str = ", ".join(result.tone_flags)
                header += f" | [red]⚠ {flags_str}[/red]"
            
            # Create text content
            text = Text()
            
            # Section header if present
            if result.section_header:
                text.append(f"Section: {result.section_header}\n", style="bold")
            
            # Chunk text (truncated if long)
            chunk_display = result.chunk_text[:500]
            if len(result.chunk_text) > 500:
                chunk_display += "..."
            text.append(chunk_display)
            
            # Tone summary
            if result.tone_summary and result.tone_summary != "No analysis":
                text.append(f"\n\n[Tone Analysis] ", style="bold yellow")
                text.append(result.tone_summary)
            
            # OCR confidence warning
            if result.ocr_confidence < 0.85:
                text.append(f"\n[OCR Confidence: {result.ocr_confidence:.0%}]", style="dim red")
            
            panel = Panel(
                text,
                title=header,
                border_style="blue" if not result.tone_flags else "red",
            )
            self.console.print(panel)
            self.console.print()
    
    def export_results(
        self,
        response: SearchResponse,
        format: str = "json"
    ) -> str:
        """
        Export results as structured data.
        
        Args:
            response: SearchResponse to export
            format: Output format (json, csv)
        
        Returns:
            Formatted string
        """
        import json
        import csv
        import io
        
        if format == "json":
            data = {
                "query": response.query,
                "total_found": response.total_found,
                "filters": response.filters_applied,
                "results": [
                    {
                        "score": r.score,
                        "source_file": r.source_file,
                        "page_number": r.page_number,
                        "chunk_index": r.chunk_index,
                        "section_header": r.section_header,
                        "text": r.chunk_text,
                        "tone_flags": r.tone_flags,
                        "tone_summary": r.tone_summary,
                    }
                    for r in response.results
                ]
            }
            return json.dumps(data, indent=2)
        
        elif format == "csv":
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow([
                "Score", "Source File", "Page", "Section", 
                "Tone Flags", "Tone Summary", "Text Preview"
            ])
            for r in response.results:
                writer.writerow([
                    f"{r.score:.3f}",
                    r.source_file,
                    r.page_number or "",
                    r.section_header or "",
                    "|".join(r.tone_flags),
                    r.tone_summary,
                    r.chunk_text[:200] + "..." if len(r.chunk_text) > 200 else r.chunk_text
                ])
            return output.getvalue()
        
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def get_document_summary(self, source_file: str) -> dict:
        """
        Get summary of a specific document.
        
        Args:
            source_file: Filename to summarize
        
        Returns:
            Dict with document statistics
        """
        # Get all chunks for this document
        results, _ = self.client.scroll(
            collection_name=self.config.collection_name,
            scroll_filter=Filter(
                must=[
                    FieldCondition(
                        key="source_file",
                        match=MatchValue(value=source_file)
                    )
                ]
            ),
            limit=1000,
            with_payload=True,
            with_vectors=False,
        )
        
        if not results:
            return {"error": f"No data found for {source_file}"}
        
        # Aggregate stats
        all_flags = []
        page_numbers = set()
        ocr_confidences = []
        
        for point in results:
            payload = point.payload
            all_flags.extend(payload.get("tone_flags", []))
            if payload.get("page_number"):
                page_numbers.add(payload["page_number"])
            ocr_confidences.append(payload.get("ocr_confidence", 0))
        
        # Count flag occurrences
        flag_counts = {}
        for flag in all_flags:
            flag_counts[flag] = flag_counts.get(flag, 0) + 1
        
        return {
            "source_file": source_file,
            "chunk_count": len(results),
            "page_count": len(page_numbers),
            "avg_ocr_confidence": sum(ocr_confidences) / len(ocr_confidences) if ocr_confidences else 0,
            "tone_flags": flag_counts,
            "total_flags": len(all_flags),
        }


# CLI interface
def main():
    """Command-line interface for searching."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Search legal document database")
    parser.add_argument("query", nargs="?", help="Search query")
    parser.add_argument("-n", "--limit", type=int, default=10, help="Number of results")
    parser.add_argument("-f", "--file", help="Filter to specific source file")
    parser.add_argument("--contradictions", action="store_true", help="Find contradictions")
    parser.add_argument("--evasive", action="store_true", help="Find evasive language")
    parser.add_argument("--export", choices=["json", "csv"], help="Export format")
    parser.add_argument("--summary", help="Get summary for a document")
    
    args = parser.parse_args()
    
    query_interface = QdrantQuery()
    
    if args.summary:
        summary = query_interface.get_document_summary(args.summary)
        print(json.dumps(summary, indent=2))
        return
    
    if args.contradictions:
        response = query_interface.find_contradictions(
            source_files=[args.file] if args.file else None,
            limit=args.limit
        )
    elif args.evasive:
        response = query_interface.find_evasive_language(
            source_files=[args.file] if args.file else None,
            limit=args.limit
        )
    elif args.query:
        response = query_interface.search(
            query=args.query,
            limit=args.limit,
            source_files=[args.file] if args.file else None,
        )
    else:
        parser.print_help()
        return
    
    if args.export:
        print(query_interface.export_results(response, args.export))
    else:
        query_interface.display_results(response)


if __name__ == "__main__":
    import json
    main()

"""
Legal AI RAG Pipeline
=====================
A privacy-preserving document analysis system for legal case files.

Modules:
    - config: Configuration management
    - logger: Structured logging with audit trail
    - file_handler: File type detection and loading
    - ocr_processor: PaddleOCR text extraction
    - tone_analyzer: Legal tone/intent analysis
    - chunk_processor: Intelligent semantic chunking
    - embedding_generator: Vector embedding generation
    - qdrant_loader: Vector database storage
    - document_pipeline: Main orchestration
"""

__version__ = "0.1.0"
__author__ = "Legal RAG Team"

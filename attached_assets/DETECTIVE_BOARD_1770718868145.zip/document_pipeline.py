"""
Document Pipeline
=================
Main orchestrator that ties together all pipeline components.
File → OCR → Tone Analysis → Chunk → Embed → Store
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import traceback

from langdetect import detect, LangDetectException

from .config import get_config, PipelineConfig
from .logger import get_logger, get_audit_logger, setup_logging, log_operation
from .file_handler import FileHandler, LoadedFile
from .ocr_processor import OCRProcessor, DocumentOCRResult
from .tone_analyzer import ToneAnalyzer, DocumentToneResult
from .chunk_processor import ChunkProcessor, TextChunk
from .embedding_generator import EmbeddingGenerator, EmbeddedChunk
from .qdrant_loader import QdrantLoader


@dataclass
class ProcessingResult:
    """Result of processing a single document."""
    source_file: str
    success: bool
    error: Optional[str] = None
    
    # Stats
    page_count: int = 0
    chunk_count: int = 0
    points_stored: int = 0
    
    # Quality metrics
    ocr_confidence: float = 0.0
    low_confidence_pages: list[int] = field(default_factory=list)
    
    # Tone analysis
    tone_flags: dict[str, int] = field(default_factory=dict)
    contradictions_found: int = 0
    timeline_issues_found: int = 0
    
    # Timing
    processing_time_seconds: float = 0.0
    
    def to_dict(self) -> dict:
        """Convert to dictionary for logging/export."""
        return {
            "source_file": self.source_file,
            "success": self.success,
            "error": self.error,
            "page_count": self.page_count,
            "chunk_count": self.chunk_count,
            "points_stored": self.points_stored,
            "ocr_confidence": self.ocr_confidence,
            "low_confidence_pages": self.low_confidence_pages,
            "tone_flags": self.tone_flags,
            "contradictions_found": self.contradictions_found,
            "timeline_issues_found": self.timeline_issues_found,
            "processing_time_seconds": self.processing_time_seconds,
        }


class DocumentPipeline:
    """
    Main document processing pipeline.
    
    Flow:
    1. Load file (any format)
    2. Extract text via OCR
    3. Chunk intelligently
    4. Analyze tone/patterns
    5. Generate embeddings
    6. Store in Qdrant with metadata
    """
    
    def __init__(self, config: Optional[PipelineConfig] = None):
        """
        Initialize pipeline with all components.
        
        Args:
            config: Pipeline configuration. Uses global if not provided.
        """
        self.config = config or get_config()
        self.logger = setup_logging(self.config.logging)
        self.audit = get_audit_logger()
        
        self.logger.info("initializing_pipeline")
        
        # Initialize components
        self.file_handler = FileHandler()
        self.ocr_processor = OCRProcessor()
        self.chunk_processor = ChunkProcessor()
        self.tone_analyzer = ToneAnalyzer()
        self.embedding_generator = EmbeddingGenerator()
        self.qdrant_loader = QdrantLoader()
        
        self.logger.info("pipeline_initialized")
    
    def _detect_language(self, text: str) -> str:
        """Detect language of text."""
        try:
            if len(text) < 50:
                return "en"  # Too short for reliable detection
            return detect(text[:5000])  # Sample first 5000 chars
        except LangDetectException:
            return "en"
    
    @log_operation("process_document")
    def process_file(self, file_path: str) -> ProcessingResult:
        """
        Process a single file through the entire pipeline.
        
        Args:
            file_path: Path to file to process
        
        Returns:
            ProcessingResult with stats and any errors
        """
        start_time = datetime.now(timezone.utc)
        path = Path(file_path)
        source_file = path.name
        
        self.logger.info("processing_file", file=source_file)
        
        result = ProcessingResult(source_file=source_file, success=False)
        
        try:
            # Step 1: Load file
            self.logger.info("step_1_loading_file", file=source_file)
            loaded_file = self.file_handler.load(file_path)
            
            # Step 2: OCR extraction
            self.logger.info("step_2_ocr_extraction", file=source_file)
            ocr_result = self.ocr_processor.process_document(loaded_file)
            
            result.page_count = ocr_result.page_count
            result.ocr_confidence = ocr_result.average_confidence
            result.low_confidence_pages = ocr_result.low_confidence_pages
            
            # Validate OCR result
            validation = self.ocr_processor.validate_result(ocr_result)
            if not validation["valid"]:
                self.logger.warning(
                    "ocr_validation_issues",
                    file=source_file,
                    issues=validation["issues"]
                )
            
            # Step 3: Chunk the text
            self.logger.info("step_3_chunking", file=source_file)
            
            # If multi-page, chunk with page numbers
            if ocr_result.page_count > 1:
                pages = [
                    (page.page_number, page.text)
                    for page in ocr_result.pages
                ]
                chunks = self.chunk_processor.chunk_document_pages(pages)
            else:
                chunks = self.chunk_processor.chunk(ocr_result.full_text)
            
            result.chunk_count = len(chunks)
            
            if not chunks:
                raise ValueError("No chunks generated from document")
            
            # Step 4: Tone analysis
            self.logger.info("step_4_tone_analysis", file=source_file, chunks=len(chunks))
            
            chunk_texts = [chunk.text for chunk in chunks]
            tone_result = self.tone_analyzer.analyze_document(
                chunks=chunk_texts,
                source_file=source_file
            )
            
            result.tone_flags = tone_result.aggregate_flags
            result.contradictions_found = len(tone_result.contradictions)
            result.timeline_issues_found = len(tone_result.timeline_issues)
            
            # Step 5: Generate embeddings
            self.logger.info("step_5_embedding", file=source_file, chunks=len(chunks))
            
            embedded_chunks = self.embedding_generator.embed_chunks(
                chunks=chunks,
                source_file=source_file
            )
            
            # Step 6: Store in Qdrant
            self.logger.info("step_6_storing", file=source_file)
            
            # Detect language
            language = self._detect_language(ocr_result.full_text)
            
            point_ids = self.qdrant_loader.store_document(
                embedded_chunks=embedded_chunks,
                source_file=source_file,
                source_path=loaded_file.metadata.original_path,
                file_type=loaded_file.metadata.file_type.value,
                file_hash=loaded_file.metadata.file_hash,
                ocr_confidence=ocr_result.average_confidence,
                tone_results=tone_result.chunk_results,
                language=language
            )
            
            result.points_stored = len(point_ids)
            
            # Archive original if configured
            if self.config.files.processing.archive_originals:
                self.file_handler.archive(file_path)
            
            # Success!
            result.success = True
            
            end_time = datetime.now(timezone.utc)
            result.processing_time_seconds = (end_time - start_time).total_seconds()
            
            self.logger.info(
                "file_processed_successfully",
                file=source_file,
                pages=result.page_count,
                chunks=result.chunk_count,
                points=result.points_stored,
                time_seconds=result.processing_time_seconds,
                tone_flags=list(result.tone_flags.keys())
            )
            
            return result
        
        except Exception as e:
            result.error = str(e)
            result.success = False
            
            end_time = datetime.now(timezone.utc)
            result.processing_time_seconds = (end_time - start_time).total_seconds()
            
            self.logger.error(
                "file_processing_failed",
                file=source_file,
                error=str(e),
                traceback=traceback.format_exc()
            )
            
            return result
    
    def process_directory(
        self,
        directory: Optional[str] = None,
        max_files: Optional[int] = None
    ) -> list[ProcessingResult]:
        """
        Process all files in a directory.
        
        Args:
            directory: Directory path. Uses config input dir if not provided.
            max_files: Maximum number of files to process
        
        Returns:
            List of ProcessingResults
        """
        if directory is None:
            directory = self.config.files.paths.input
        
        files = self.file_handler.list_input_files()
        
        if max_files:
            files = files[:max_files]
        
        self.logger.info(
            "processing_directory",
            directory=directory,
            file_count=len(files)
        )
        
        results = []
        for file_path in files:
            result = self.process_file(str(file_path))
            results.append(result)
        
        # Summary
        successful = sum(1 for r in results if r.success)
        failed = sum(1 for r in results if not r.success)
        total_chunks = sum(r.chunk_count for r in results)
        total_points = sum(r.points_stored for r in results)
        
        self.logger.info(
            "batch_processing_complete",
            total_files=len(results),
            successful=successful,
            failed=failed,
            total_chunks=total_chunks,
            total_points=total_points
        )
        
        return results
    
    def get_status(self) -> dict:
        """Get pipeline status and collection info."""
        return {
            "collection": self.qdrant_loader.get_collection_info(),
            "sources": self.qdrant_loader.list_sources(),
            "config": {
                "ocr_threshold": self.config.ocr.confidence_threshold,
                "tone_provider": self.config.tone_analysis.provider,
                "embedding_model": self.config.embedding.model,
            }
        }


# Convenience function for direct use
def process_document(file_path: str) -> ProcessingResult:
    """
    Process a single document (convenience function).
    
    Args:
        file_path: Path to document
    
    Returns:
        ProcessingResult
    """
    pipeline = DocumentPipeline()
    return pipeline.process_file(file_path)

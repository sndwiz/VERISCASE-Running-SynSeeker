"""
Structured Logging with Audit Trail
====================================
Provides structured logging and immutable audit trail for legal compliance.
Every operation is logged with context for discovery/compliance requirements.
"""

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from functools import wraps
import hashlib

import structlog
from structlog.types import Processor

from .config import get_config, LoggingConfig


class AuditLogger:
    """
    Immutable audit trail logger for legal compliance.
    Records all operations with timestamps and checksums.
    """
    
    def __init__(self, log_path: str):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._file = open(self.log_path, 'a', encoding='utf-8')
        self._entry_count = 0
    
    def _compute_checksum(self, data: dict) -> str:
        """Compute SHA-256 checksum of log entry."""
        serialized = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()[:16]
    
    def log(
        self,
        operation: str,
        status: str,
        details: dict[str, Any],
        source_file: Optional[str] = None,
        error: Optional[str] = None
    ) -> str:
        """
        Log an audit entry.
        
        Args:
            operation: Type of operation (ocr, tone_analysis, embedding, qdrant, etc.)
            status: Status (started, completed, failed)
            details: Operation-specific details
            source_file: Source document if applicable
            error: Error message if status is 'failed'
        
        Returns:
            Entry ID for reference
        """
        self._entry_count += 1
        timestamp = datetime.now(timezone.utc).isoformat()
        
        entry = {
            "entry_id": f"AUDIT-{timestamp.replace(':', '-').replace('.', '-')}",
            "timestamp": timestamp,
            "operation": operation,
            "status": status,
            "source_file": source_file,
            "details": details,
        }
        
        if error:
            entry["error"] = error
        
        entry["checksum"] = self._compute_checksum(entry)
        
        # Write as single line JSON (append-only)
        self._file.write(json.dumps(entry, default=str) + "\n")
        self._file.flush()
        
        return entry["entry_id"]
    
    def log_ocr(
        self,
        source_file: str,
        status: str,
        pages_processed: int = 0,
        confidence_scores: Optional[list[float]] = None,
        low_confidence_pages: Optional[list[int]] = None,
        error: Optional[str] = None
    ) -> str:
        """Log OCR operation."""
        details = {
            "pages_processed": pages_processed,
            "avg_confidence": sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0,
            "low_confidence_pages": low_confidence_pages or [],
        }
        return self.log("ocr", status, details, source_file, error)
    
    def log_tone_analysis(
        self,
        source_file: str,
        status: str,
        provider: str = "",
        flags_detected: Optional[list[str]] = None,
        chunks_analyzed: int = 0,
        error: Optional[str] = None
    ) -> str:
        """Log tone analysis operation."""
        details = {
            "provider": provider,
            "flags_detected": flags_detected or [],
            "chunks_analyzed": chunks_analyzed,
        }
        return self.log("tone_analysis", status, details, source_file, error)
    
    def log_embedding(
        self,
        source_file: str,
        status: str,
        chunks_embedded: int = 0,
        model: str = "",
        error: Optional[str] = None
    ) -> str:
        """Log embedding generation."""
        details = {
            "chunks_embedded": chunks_embedded,
            "model": model,
        }
        return self.log("embedding", status, details, source_file, error)
    
    def log_qdrant(
        self,
        operation_type: str,
        status: str,
        collection: str = "",
        points_affected: int = 0,
        source_file: Optional[str] = None,
        error: Optional[str] = None
    ) -> str:
        """Log Qdrant operation."""
        details = {
            "operation_type": operation_type,
            "collection": collection,
            "points_affected": points_affected,
        }
        return self.log("qdrant", status, details, source_file, error)
    
    def close(self):
        """Close the audit log file."""
        self._file.close()


def add_timestamp(
    logger: logging.Logger, method_name: str, event_dict: dict
) -> dict:
    """Add ISO timestamp to log entries."""
    event_dict["timestamp"] = datetime.now(timezone.utc).isoformat()
    return event_dict


def add_log_level(
    logger: logging.Logger, method_name: str, event_dict: dict
) -> dict:
    """Add log level to log entries."""
    event_dict["level"] = method_name.upper()
    return event_dict


def setup_logging(config: Optional[LoggingConfig] = None) -> structlog.BoundLogger:
    """
    Configure structured logging.
    
    Args:
        config: Logging configuration. Uses global config if not provided.
    
    Returns:
        Configured structlog logger
    """
    if config is None:
        config = get_config().logging
    
    # Create log directory
    log_dir = Path(config.file.path).parent
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Configure processors based on format
    shared_processors: list[Processor] = [
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        add_timestamp,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]
    
    if config.format == "json":
        processors = shared_processors + [
            structlog.processors.JSONRenderer()
        ]
    else:
        processors = shared_processors + [
            structlog.dev.ConsoleRenderer(colors=True)
        ]
    
    # Configure structlog
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
    
    # Configure standard logging
    log_level = getattr(logging, config.level.upper())
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # Clear existing handlers
    root_logger.handlers = []
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    root_logger.addHandler(console_handler)
    
    # File handler
    if config.file.enabled:
        file_handler = logging.FileHandler(config.file.path, encoding='utf-8')
        file_handler.setLevel(log_level)
        root_logger.addHandler(file_handler)
    
    return structlog.get_logger()


# Global instances
_logger: Optional[structlog.BoundLogger] = None
_audit_logger: Optional[AuditLogger] = None


def get_logger() -> structlog.BoundLogger:
    """Get the global logger instance."""
    global _logger
    if _logger is None:
        _logger = setup_logging()
    return _logger


def get_audit_logger() -> AuditLogger:
    """Get the global audit logger instance."""
    global _audit_logger
    if _audit_logger is None:
        config = get_config().logging.audit
        _audit_logger = AuditLogger(config.path)
    return _audit_logger


def log_operation(operation: str):
    """
    Decorator to log function execution with timing.
    
    Usage:
        @log_operation("process_document")
        def process_document(path):
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            logger = get_logger()
            start_time = datetime.now(timezone.utc)
            
            logger.info(
                f"{operation}_started",
                operation=operation,
                args=str(args)[:200],  # Truncate for logging
            )
            
            try:
                result = func(*args, **kwargs)
                duration = (datetime.now(timezone.utc) - start_time).total_seconds()
                logger.info(
                    f"{operation}_completed",
                    operation=operation,
                    duration_seconds=duration,
                )
                return result
            except Exception as e:
                duration = (datetime.now(timezone.utc) - start_time).total_seconds()
                logger.error(
                    f"{operation}_failed",
                    operation=operation,
                    duration_seconds=duration,
                    error=str(e),
                    exc_info=True,
                )
                raise
        
        return wrapper
    return decorator

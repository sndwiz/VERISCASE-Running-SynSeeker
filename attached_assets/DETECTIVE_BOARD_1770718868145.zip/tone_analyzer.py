"""
Tone Analyzer
=============
Analyzes legal documents for tone, intent, contradictions, and manipulation patterns.
Uses Claude API for best quality or local Ollama for offline operation.
"""

import json
import os
from dataclasses import dataclass, field
from typing import Optional, Literal
from enum import Enum

import anthropic
import ollama

from .config import get_config
from .logger import get_logger, get_audit_logger


class ToneFlag(Enum):
    """Legal document tone flags."""
    CONTRADICTORY = "contradictory"
    EVASIVE = "evasive"
    AGGRESSIVE = "aggressive"
    DEFENSIVE = "defensive"
    TIMELINE_ISSUE = "timeline_issue"
    DETAIL_INCONSISTENCY = "detail_inconsistency"
    UNUSUAL_WORD_CHOICE = "unusual_word_choice"
    MISSING_INFO = "missing_info"


@dataclass
class ToneAnalysisResult:
    """Result of tone analysis on a text chunk."""
    chunk_index: int
    flags: list[str]
    confidence: float  # 0-1 confidence in the analysis
    summary: str  # Brief summary of findings
    details: dict = field(default_factory=dict)  # Flag-specific details
    raw_response: Optional[str] = None  # Full LLM response for audit


@dataclass
class DocumentToneResult:
    """Complete tone analysis for a document."""
    source_file: str
    provider: str  # "claude" or "ollama"
    model: str
    chunks_analyzed: int
    chunk_results: list[ToneAnalysisResult]
    aggregate_flags: dict[str, int]  # Flag counts across document
    contradictions: list[dict]  # Specific contradictions found
    timeline_issues: list[dict]  # Timeline inconsistencies
    summary: str  # Overall document summary


# System prompt for legal tone analysis
LEGAL_ANALYSIS_PROMPT = """You are an expert legal analyst specializing in identifying manipulation, inconsistencies, and concerning patterns in legal documents.

Analyze the following text chunk from a legal document. Look for:

1. **Contradictory Statements**: Claims that conflict with each other or with common facts
2. **Evasive Language**: Vague responses, avoiding direct answers, excessive qualifiers
3. **Aggressive Tone**: Hostile, threatening, or confrontational language
4. **Defensive Language**: Over-explaining, preemptive justifications, deflection
5. **Timeline Issues**: Chronological inconsistencies, impossible sequences, date conflicts
6. **Detail Inconsistency**: Varying levels of specificity that seem strategic
7. **Unusual Word Choice**: Legal term misuse, suspicious phrasing, loaded language
8. **Missing Information**: Notable gaps in expected information

For each issue found, provide:
- The specific flag category
- The exact text that triggered the flag
- Why this is concerning in a legal context
- Confidence level (high/medium/low)

Respond in JSON format:
{
    "flags": ["flag1", "flag2"],
    "confidence": 0.85,
    "summary": "Brief 1-2 sentence summary",
    "details": {
        "flag_name": {
            "text": "quoted text",
            "reason": "why concerning",
            "confidence": "high/medium/low"
        }
    }
}

If no issues are found, return:
{
    "flags": [],
    "confidence": 0.95,
    "summary": "No concerning patterns detected",
    "details": {}
}"""


class ToneAnalyzer:
    """
    Analyzes legal documents for tone and manipulation patterns.
    Supports Claude API and local Ollama inference.
    """
    
    def __init__(self):
        self.config = get_config().tone_analysis
        self.logger = get_logger()
        self.audit = get_audit_logger()
        
        self.provider = self.config.provider
        
        if self.provider == "claude":
            api_key = os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError(
                    "ANTHROPIC_API_KEY environment variable not set. "
                    "Either set it or switch to provider: ollama in config."
                )
            self.client = anthropic.Anthropic(api_key=api_key)
            self.model = self.config.claude.model
            self.logger.info("tone_analyzer_initialized", provider="claude", model=self.model)
        
        elif self.provider == "ollama":
            self.client = ollama.Client(host=self.config.ollama.host)
            self.model = self.config.ollama.model
            
            # Verify model is available
            try:
                models = self.client.list()
                available = [m['name'] for m in models.get('models', [])]
                if self.model not in available and f"{self.model}:latest" not in available:
                    self.logger.warning(
                        "ollama_model_not_found",
                        model=self.model,
                        available=available,
                        message=f"Model {self.model} not found. Run: ollama pull {self.model}"
                    )
            except Exception as e:
                self.logger.warning(
                    "ollama_connection_failed",
                    error=str(e),
                    message="Could not connect to Ollama. Ensure it's running."
                )
            
            self.logger.info("tone_analyzer_initialized", provider="ollama", model=self.model)
        
        else:
            raise ValueError(f"Unknown provider: {self.provider}")
    
    def _call_claude(self, text: str) -> str:
        """Call Claude API for analysis."""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=self.config.claude.max_tokens,
            temperature=self.config.claude.temperature,
            system=LEGAL_ANALYSIS_PROMPT,
            messages=[
                {"role": "user", "content": f"Analyze this text:\n\n{text}"}
            ]
        )
        return response.content[0].text
    
    def _call_ollama(self, text: str) -> str:
        """Call Ollama for analysis."""
        response = self.client.chat(
            model=self.model,
            messages=[
                {"role": "system", "content": LEGAL_ANALYSIS_PROMPT},
                {"role": "user", "content": f"Analyze this text:\n\n{text}"}
            ],
            options={
                "temperature": 0.3,
                "num_predict": 2048,
            }
        )
        return response['message']['content']
    
    def _parse_response(self, response: str, chunk_index: int) -> ToneAnalysisResult:
        """Parse LLM response into structured result."""
        try:
            # Try to extract JSON from response
            # Handle cases where LLM adds text before/after JSON
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = response[json_start:json_end]
                data = json.loads(json_str)
                
                return ToneAnalysisResult(
                    chunk_index=chunk_index,
                    flags=data.get("flags", []),
                    confidence=float(data.get("confidence", 0.5)),
                    summary=data.get("summary", ""),
                    details=data.get("details", {}),
                    raw_response=response
                )
            else:
                # No JSON found, create minimal result
                self.logger.warning(
                    "json_parse_failed",
                    chunk_index=chunk_index,
                    response_preview=response[:200]
                )
                return ToneAnalysisResult(
                    chunk_index=chunk_index,
                    flags=[],
                    confidence=0.0,
                    summary="Failed to parse analysis response",
                    details={"parse_error": True},
                    raw_response=response
                )
        
        except json.JSONDecodeError as e:
            self.logger.warning(
                "json_decode_error",
                chunk_index=chunk_index,
                error=str(e)
            )
            return ToneAnalysisResult(
                chunk_index=chunk_index,
                flags=[],
                confidence=0.0,
                summary="JSON decode error in response",
                details={"parse_error": str(e)},
                raw_response=response
            )
    
    def analyze_chunk(self, text: str, chunk_index: int = 0) -> ToneAnalysisResult:
        """
        Analyze a single text chunk for tone and patterns.
        
        Args:
            text: Text to analyze
            chunk_index: Index of this chunk in the document
        
        Returns:
            ToneAnalysisResult with findings
        """
        if not text.strip():
            return ToneAnalysisResult(
                chunk_index=chunk_index,
                flags=[],
                confidence=1.0,
                summary="Empty chunk",
                details={}
            )
        
        try:
            if self.provider == "claude":
                response = self._call_claude(text)
            else:
                response = self._call_ollama(text)
            
            return self._parse_response(response, chunk_index)
        
        except Exception as e:
            self.logger.error(
                "analysis_failed",
                chunk_index=chunk_index,
                error=str(e),
                exc_info=True
            )
            return ToneAnalysisResult(
                chunk_index=chunk_index,
                flags=[],
                confidence=0.0,
                summary=f"Analysis failed: {str(e)}",
                details={"error": str(e)}
            )
    
    def analyze_document(
        self,
        chunks: list[str],
        source_file: str
    ) -> DocumentToneResult:
        """
        Analyze all chunks from a document.
        
        Args:
            chunks: List of text chunks to analyze
            source_file: Source filename for tracking
        
        Returns:
            DocumentToneResult with aggregate findings
        """
        self.logger.info(
            "document_analysis_started",
            source_file=source_file,
            chunk_count=len(chunks),
            provider=self.provider,
            model=self.model
        )
        
        self.audit.log_tone_analysis(
            source_file=source_file,
            status="started",
            provider=self.provider,
            chunks_analyzed=len(chunks)
        )
        
        try:
            # Analyze each chunk
            chunk_results: list[ToneAnalysisResult] = []
            for idx, chunk in enumerate(chunks):
                self.logger.debug(
                    "analyzing_chunk",
                    source_file=source_file,
                    chunk=idx + 1,
                    total=len(chunks)
                )
                result = self.analyze_chunk(chunk, chunk_index=idx)
                chunk_results.append(result)
            
            # Aggregate results
            aggregate_flags: dict[str, int] = {}
            for result in chunk_results:
                for flag in result.flags:
                    aggregate_flags[flag] = aggregate_flags.get(flag, 0) + 1
            
            # Extract specific issues
            contradictions = []
            timeline_issues = []
            
            for result in chunk_results:
                if "contradictory" in result.flags and "contradictory" in result.details:
                    contradictions.append({
                        "chunk_index": result.chunk_index,
                        **result.details["contradictory"]
                    })
                if "timeline_issue" in result.flags and "timeline_issue" in result.details:
                    timeline_issues.append({
                        "chunk_index": result.chunk_index,
                        **result.details["timeline_issue"]
                    })
            
            # Generate summary
            total_flags = sum(aggregate_flags.values())
            if total_flags == 0:
                summary = "No concerning patterns detected in this document."
            else:
                top_flags = sorted(aggregate_flags.items(), key=lambda x: -x[1])[:3]
                flag_summary = ", ".join([f"{f[0]} ({f[1]})" for f in top_flags])
                summary = f"Found {total_flags} flags across {len(chunks)} chunks. Top issues: {flag_summary}"
            
            document_result = DocumentToneResult(
                source_file=source_file,
                provider=self.provider,
                model=self.model,
                chunks_analyzed=len(chunks),
                chunk_results=chunk_results,
                aggregate_flags=aggregate_flags,
                contradictions=contradictions,
                timeline_issues=timeline_issues,
                summary=summary
            )
            
            # Log success
            all_flags = list(aggregate_flags.keys())
            self.logger.info(
                "document_analysis_completed",
                source_file=source_file,
                chunks_analyzed=len(chunks),
                total_flags=total_flags,
                flags_found=all_flags
            )
            
            self.audit.log_tone_analysis(
                source_file=source_file,
                status="completed",
                provider=self.provider,
                flags_detected=all_flags,
                chunks_analyzed=len(chunks)
            )
            
            return document_result
        
        except Exception as e:
            self.logger.error(
                "document_analysis_failed",
                source_file=source_file,
                error=str(e),
                exc_info=True
            )
            
            self.audit.log_tone_analysis(
                source_file=source_file,
                status="failed",
                provider=self.provider,
                error=str(e)
            )
            
            raise

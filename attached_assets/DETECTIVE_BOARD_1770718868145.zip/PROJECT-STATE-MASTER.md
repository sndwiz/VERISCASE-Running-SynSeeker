# LEGAL AI SYSTEM - COMPLETE PROJECT STATE
## Master Document for Continuation

---

# EXECUTIVE SUMMARY

**What We're Building:**
A legal investigation platform disguised as a playful cork board. Underneath: enterprise-grade AI analysis, military-grade security, full case management, and federated processing.

**The Deception:**
```
┌────────────────────────────────────────────────────────────────┐
│                     WHAT THEY SEE                              │
│                                                                │
│     🪵 Cork board    📌 Pins    🧵 String    📝 Sticky notes   │
│                                                                │
│                    "Oh how cute and fun!"                      │
└────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌────────────────────────────────────────────────────────────────┐
│                     WHAT IT IS                                 │
│                                                                │
│  • Full RAG pipeline with AI document analysis                 │
│  • Monday.com-style project/task management backend            │
│  • Git-like version control for legal cases                    │
│  • Military-grade permission system                            │
│  • Informant/source protection vault                           │
│  • Two operating modes (Private / Wash)                        │
│  • Boss-only external processing trigger                       │
│  • Complete audit trail for discovery                          │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

# SYSTEM COMPONENTS

## 1. RAG PIPELINE (BUILT - Phase 1 Complete)

**Location:** `/home/claude/legal-rag-pipeline/` (also in outputs)

**What It Does:**
- Ingests any document format (PDF, images, scans, handwriting)
- OCR via PaddleOCR with confidence scoring
- AI tone analysis (contradictions, evasion, timeline issues)
- Semantic chunking (not arbitrary token splits)
- Vector embeddings stored in Qdrant
- Full metadata preservation (source, page, flags)

**Files:**
```
legal-rag-pipeline/
├── document_pipeline.py    # Main pipeline (FileHandler, OCR, Analysis, Chunking, Embedding)
├── qdrant_manager.py       # Vector DB operations
├── tone_analyzer.py        # AI analysis (Claude/Ollama)
├── query_engine.py         # Search and retrieval
├── config.yaml             # All settings
├── requirements.txt        # Dependencies
└── README.md               # Documentation
```

**Status:** Code complete, ready for testing on Ryzen build.

---

## 2. INVESTIGATION BOARD (Prototype Complete)

**Location:** `/mnt/user-data/outputs/investigation-board-v2.html`

**What It Does:**
- Visual cork board interface
- Drag/drop cards, notes, people, timelines
- Connection strings (red = contradiction, blue = supports)
- 4 zones for med mal elements (Duty, Breach, Causation, Damages)
- AI-generated cards marked with badge
- "What's New" panel showing AI discoveries
- Version history sidebar

**Current State:** Interactive HTML prototype. Needs to become real Electron app.

---

## 3. MONDAY-STYLE BACKEND (SPEC NEEDED)

**What It Should Do:**

### Case Management
```
┌─────────────────────────────────────────────────────────────────┐
│ CASES                                                    [+ New]│
├─────────────────────────────────────────────────────────────────┤
│ ● Doe v. Memorial Hospital     │ Active  │ 67 docs │ Dec 21   │
│ ○ Smith v. Metro Clinic        │ Active  │ 23 docs │ Dec 18   │
│ ○ Johnson Insurance Claim      │ Review  │ 12 docs │ Dec 15   │
│ ○ Williams Wrongful Term.      │ Closed  │ 89 docs │ Nov 30   │
└─────────────────────────────────────────────────────────────────┘
```

### Task Tracking (Per Case)
```
┌─────────────────────────────────────────────────────────────────┐
│ TASKS - Doe v. Memorial Hospital                                │
├─────────────────────────────────────────────────────────────────┤
│ □ Request hospital P&P manual          │ Sarah  │ Due: Dec 23 │
│ □ Schedule Dr. Smith deposition        │ Mike   │ Due: Dec 28 │
│ ■ Review nursing logs                  │ Sarah  │ ✓ Complete  │
│ □ Expert witness - causation           │ Boss   │ Due: Jan 5  │
│ ⚠ FLAGGED: 7-hour gap needs explain   │ AI     │ Priority    │
└─────────────────────────────────────────────────────────────────┘
```

### Workflow Stages
```
Intake → Document Collection → AI Analysis → Review → 
Expert Phase → Discovery → Deposition → Trial Prep → Resolution
```

### Team Assignment
- Assign attorneys, paralegals to cases
- Track hours/activity
- Deadline management
- Calendar integration

---

## 4. INFORMANT/SOURCE VAULT (NEW REQUIREMENT)

**Purpose:** Protect sensitive sources - witnesses who need anonymity, confidential informants, protected parties.

**How It Works:**

### Source Entry
```
┌─────────────────────────────────────────────────────────────────┐
│ 🔒 PROTECTED SOURCE                                    [Vault] │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Codename: CARDINAL                                            │
│  ─────────────────────────────────                             │
│                                                                 │
│  Real Identity: [ENCRYPTED - Boss Only]                        │
│  Contact Method: [ENCRYPTED - Boss Only]                       │
│                                                                 │
│  Relationship to Case: Former employee of defendant            │
│  Information Provided:                                          │
│    • Internal memo re: known monitoring failures               │
│    • Email thread showing cover-up discussion                  │
│    • Timeline of management awareness                          │
│                                                                 │
│  Documents Linked: 3 (anonymized on board)                     │
│  Last Contact: Dec 15, 2024                                    │
│                                                                 │
│  Access Level: 🔴 BOSS ONLY                                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### On The Board
When source info appears on the cork board:
```
┌─────────────────────────────────────────────────────────────────┐
│ 📋 EVIDENCE CARD                                               │
│ ─────────────────                                              │
│ Internal Memo - Monitoring Failures                            │
│                                                                │
│ "Management was aware of staffing shortages affecting          │
│ patient monitoring as early as January 2024..."                │
│                                                                │
│ Source: 🔒 Protected Source [CARDINAL]                         │
│ Date: Jan 15, 2024                                             │
│                                                                │
│ ⚠️ SOURCE PROTECTED - Identity restricted                      │
└─────────────────────────────────────────────────────────────────┘
```

**Security:**
- Real identity encrypted at rest
- Only Boss-level permission can decrypt
- Audit log of every access attempt
- Source info NEVER included in Wash data
- Codenames used everywhere except vault

---

## 5. PERMISSION SYSTEM (NEW REQUIREMENT)

### Permission Levels

| Level | Role | Can Do | Cannot Do |
|-------|------|--------|-----------|
| 👁️ **Viewer** | Client, Outside Counsel | View board (filtered), Export sanitized | Edit, See sources, Run analysis |
| ✏️ **Editor** | Paralegal | Add notes, Edit cards, Upload docs | See protected sources, Run Wash |
| ⚙️ **Analyst** | Associate Attorney | Full board access, Run local AI | See source identities, Run Wash |
| 🔓 **Senior** | Senior Attorney | All above + See source codenames | Decrypt source identity, Run Wash |
| 👑 **Boss** | Partner/Owner | EVERYTHING + Decrypt sources + Run Wash | Nothing restricted |

### The Wash Button

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│     ┌─────────────────────────────────────────────┐            │
│     │                                             │            │
│     │     🔴 RUN EXTERNAL ANALYSIS (WASH)        │            │
│     │                                             │            │
│     │     ⚠️ BOSS AUTHORIZATION REQUIRED         │            │
│     │                                             │            │
│     └─────────────────────────────────────────────┘            │
│                                                                 │
│     This will:                                                  │
│     • Anonymize all case data                                  │
│     • Strip protected source references                        │
│     • Send to external AI processing                           │
│     • Return insights only (no raw data)                       │
│                                                                 │
│     Estimated time: 15-30 minutes                              │
│     Estimated cost: $12.50                                     │
│                                                                 │
│     [Cancel]                    [🔐 Authorize & Run]           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Authorization Flow:**
1. Anyone can REQUEST a Wash run
2. Request goes to Boss for approval
3. Boss reviews what will be sent (anonymized preview)
4. Boss authenticates (password + 2FA)
5. System executes Wash
6. Results return, Boss reviews first
7. Boss releases to team (or holds if sensitive)

---

## 6. TWO OPERATING MODES

### Mode 1: PRIVATE MODE (Default)

**What It Means:**
- All processing happens on local hardware
- No data leaves the building
- Full detail visible (based on permission level)
- Source identities accessible (Boss only)
- AI runs on local Ollama

**Board Appearance:**
```
┌─────────────────────────────────────────────────────────────────┐
│ 🟢 PRIVATE MODE                              [Switch to Wash ▼]│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  All data local. Full detail. Sources protected by permission. │
│                                                                 │
│  [Cork board with full information]                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Mode 2: WASH MODE (Preview / Active)

**What It Means:**
- Shows what WOULD be sent externally
- All names replaced with Party_A, Party_B, etc.
- Protected sources completely hidden
- Addresses, SSNs, identifying info stripped
- Preview before sending OR active during Wash run

**Board Appearance:**
```
┌─────────────────────────────────────────────────────────────────┐
│ 🟡 WASH MODE (Preview)                      [Back to Private ▼]│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ⚠️ Showing anonymized view - what external AI will see        │
│                                                                 │
│  [Cork board with anonymized information]                      │
│                                                                 │
│  Changes:                                                       │
│  • "Dr. James Smith" → "Provider_A"                            │
│  • "Jane Doe" → "Patient_A"                                    │
│  • "Memorial Hospital" → "Facility_A"                          │
│  • Source [CARDINAL] → [REDACTED - Not sent]                   │
│  • "123 Main St" → "[Location_A]"                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Use Cases:**
1. **Preview** - Attorney checks "what would this look like anonymized?" before requesting Wash
2. **Active** - During Wash run, board shows Wash mode to indicate external processing
3. **Training** - Show clients/team how the system protects data

---

## 7. AUDIT TRAIL

**Every action logged:**

```
┌─────────────────────────────────────────────────────────────────┐
│ AUDIT LOG - Doe v. Memorial Hospital                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Dec 21, 3:45 PM │ Sarah (Editor)                               │
│ Added sticky note: "DEPO PREP: Question Smith on gap"          │
│                                                                 │
│ Dec 21, 3:30 PM │ SYSTEM (AI)                                  │
│ Model run complete: +2 contradictions, +3 timeline events      │
│                                                                 │
│ Dec 21, 2:15 PM │ Mike (Analyst)                               │
│ Uploaded document: Smith_Deposition_Transcript.pdf             │
│                                                                 │
│ Dec 21, 2:00 PM │ Boss (Boss)                                  │
│ 🔒 Accessed protected source: CARDINAL                         │
│                                                                 │
│ Dec 20, 4:30 PM │ Boss (Boss)                                  │
│ 🌐 WASH RUN AUTHORIZED - 67 documents sent (anonymized)        │
│                                                                 │
│ Dec 20, 4:15 PM │ Sarah (Editor)                               │
│ Requested Wash run - pending Boss approval                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**What's Logged:**
- Every document upload
- Every edit to board
- Every AI model run
- Every source access (with viewer identity)
- Every Wash request/approval/execution
- Every login/logout
- Every permission change
- Every export

**Why:**
- Legal discovery compliance
- Security audit trail
- Activity reconstruction
- Accountability

---

# TECHNICAL ARCHITECTURE

## Full Stack

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND                                 │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              ELECTRON DESKTOP APP                        │   │
│  │                                                          │   │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐           │   │
│  │  │ Cork Board │ │  Monday    │ │  Source    │           │   │
│  │  │    View    │ │   View     │ │   Vault    │           │   │
│  │  └────────────┘ └────────────┘ └────────────┘           │   │
│  │                                                          │   │
│  │  React + TypeScript + Konva (canvas) + Tailwind         │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              │                                  │
└──────────────────────────────┼──────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                         BACKEND                                 │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    FASTAPI                               │   │
│  │                                                          │   │
│  │  /api/cases         - Case CRUD                         │   │
│  │  /api/elements      - Board element CRUD                │   │
│  │  /api/versions      - Version control                   │   │
│  │  /api/tasks         - Monday-style tasks                │   │
│  │  /api/sources       - Protected source vault            │   │
│  │  /api/documents     - Document upload/management        │   │
│  │  /api/analysis      - Trigger AI runs                   │   │
│  │  /api/wash          - External processing               │   │
│  │  /api/audit         - Audit log access                  │   │
│  │  /api/auth          - Authentication                    │   │
│  │                                                          │   │
│  │  WebSocket: Real-time board updates                     │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              │                                  │
└──────────────────────────────┼──────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DATA LAYER                                 │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  PostgreSQL  │  │    Qdrant    │  │ File Storage │          │
│  │              │  │              │  │              │          │
│  │ • Cases      │  │ • Embeddings │  │ • Documents  │          │
│  │ • Elements   │  │ • Similarity │  │ • OCR text   │          │
│  │ • Versions   │  │   search     │  │ • Thumbnails │          │
│  │ • Tasks      │  │              │  │              │          │
│  │ • Sources    │  │              │  │              │          │
│  │ • Audit log  │  │              │  │              │          │
│  │ • Users      │  │              │  │              │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                    AI / ANALYSIS LAYER                          │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  PaddleOCR   │  │   Ollama     │  │ Claude API   │          │
│  │              │  │   (Local)    │  │  (Wash)      │          │
│  │ • Text       │  │              │  │              │          │
│  │   extraction │  │ • Tone       │  │ • Heavy      │          │
│  │ • Handwriting│  │   analysis   │  │   analysis   │          │
│  │              │  │ • Entity     │  │ • Pattern    │          │
│  │              │  │   extraction │  │   matching   │          │
│  │              │  │ • Local only │  │ • Anonymized │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Database Schema (Extended)

```sql
-- Users & Permissions
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    password_hash VARCHAR(255),
    permission_level ENUM('viewer', 'editor', 'analyst', 'senior', 'boss'),
    created_at TIMESTAMP,
    last_login TIMESTAMP
);

-- Cases
CREATE TABLE cases (
    id UUID PRIMARY KEY,
    name VARCHAR(255),
    case_number VARCHAR(100),
    status ENUM('intake', 'active', 'review', 'discovery', 'trial_prep', 'closed'),
    created_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    current_version_id UUID
);

-- Case Team Assignment
CREATE TABLE case_team (
    case_id UUID REFERENCES cases(id),
    user_id UUID REFERENCES users(id),
    role VARCHAR(100),
    assigned_at TIMESTAMP,
    PRIMARY KEY (case_id, user_id)
);

-- Tasks (Monday-style)
CREATE TABLE tasks (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    title VARCHAR(255),
    description TEXT,
    status ENUM('todo', 'in_progress', 'review', 'done'),
    assigned_to UUID REFERENCES users(id),
    due_date DATE,
    priority ENUM('low', 'medium', 'high', 'urgent'),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP,
    completed_at TIMESTAMP,
    ai_generated BOOLEAN DEFAULT FALSE
);

-- Protected Sources (Vault)
CREATE TABLE protected_sources (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    codename VARCHAR(100),
    real_identity_encrypted BYTEA,  -- Encrypted, Boss-only decrypt
    contact_method_encrypted BYTEA,  -- Encrypted, Boss-only decrypt
    relationship TEXT,
    created_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    last_accessed_at TIMESTAMP,
    last_accessed_by UUID REFERENCES users(id)
);

-- Source Information (What they provided)
CREATE TABLE source_information (
    id UUID PRIMARY KEY,
    source_id UUID REFERENCES protected_sources(id),
    information TEXT,
    document_id UUID,  -- If they provided a document
    received_at TIMESTAMP
);

-- Versions
CREATE TABLE versions (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_number VARCHAR(20),
    parent_version_id UUID,
    created_at TIMESTAMP,
    created_by UUID REFERENCES users(id),
    description TEXT,
    is_branch BOOLEAN DEFAULT FALSE,
    board_state JSONB
);

-- Board Elements
CREATE TABLE elements (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_id UUID REFERENCES versions(id),
    element_type VARCHAR(50),
    position JSONB,  -- {x, y, rotation}
    data JSONB,
    source_document_id UUID,
    protected_source_id UUID REFERENCES protected_sources(id),  -- If from protected source
    ai_generated BOOLEAN DEFAULT FALSE,
    ai_confidence FLOAT,
    created_at TIMESTAMP
);

-- Connections
CREATE TABLE connections (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_id UUID REFERENCES versions(id),
    from_element_id UUID REFERENCES elements(id),
    to_element_id UUID REFERENCES elements(id),
    connection_type VARCHAR(50),
    ai_generated BOOLEAN DEFAULT FALSE
);

-- Wash Runs
CREATE TABLE wash_runs (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    requested_by UUID REFERENCES users(id),
    requested_at TIMESTAMP,
    approved_by UUID REFERENCES users(id),  -- Must be Boss
    approved_at TIMESTAMP,
    status ENUM('pending', 'approved', 'running', 'complete', 'failed', 'rejected'),
    documents_sent INT,
    anonymization_map JSONB,  -- Mapping table (stays local, encrypted)
    results JSONB,
    completed_at TIMESTAMP,
    cost DECIMAL(10,2)
);

-- Audit Log
CREATE TABLE audit_log (
    id UUID PRIMARY KEY,
    case_id UUID,
    user_id UUID REFERENCES users(id),
    action VARCHAR(100),
    target_type VARCHAR(50),  -- 'element', 'source', 'wash', 'document', etc.
    target_id UUID,
    details JSONB,
    ip_address INET,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- Indexes for audit queries
CREATE INDEX idx_audit_case ON audit_log(case_id);
CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_action ON audit_log(action);
CREATE INDEX idx_audit_timestamp ON audit_log(timestamp);
```

---

# SECURITY MODEL

## Encryption

| Data Type | At Rest | In Transit | Key Management |
|-----------|---------|------------|----------------|
| Documents | AES-256 | TLS 1.3 | HSM or secure key store |
| Source identities | AES-256 + additional layer | N/A (never transmitted) | Boss-only key |
| Board state | AES-256 | TLS 1.3 | Per-case key |
| Wash data | Anonymized before encrypt | TLS 1.3 | Ephemeral keys |
| Audit logs | AES-256, append-only | TLS 1.3 | System key |

## Access Control Matrix

| Resource | Viewer | Editor | Analyst | Senior | Boss |
|----------|--------|--------|---------|--------|------|
| View board | ✓ (filtered) | ✓ | ✓ | ✓ | ✓ |
| Edit elements | - | ✓ | ✓ | ✓ | ✓ |
| Upload docs | - | ✓ | ✓ | ✓ | ✓ |
| Run local AI | - | - | ✓ | ✓ | ✓ |
| See source codenames | - | - | - | ✓ | ✓ |
| Decrypt source identity | - | - | - | - | ✓ |
| Request Wash | - | ✓ | ✓ | ✓ | ✓ |
| Approve Wash | - | - | - | - | ✓ |
| View audit log | - | - | - | ✓ | ✓ |
| Manage users | - | - | - | - | ✓ |

---

# IMPLEMENTATION PHASES

## Phase 1: Foundation (COMPLETE)
- [x] RAG pipeline built
- [x] OCR + tone analysis working
- [x] Qdrant storage
- [x] Basic query engine

## Phase 2: Investigation Board (IN PROGRESS)
- [x] Cork board UI prototype
- [x] Element types defined
- [x] Version history concept
- [ ] Real Electron app
- [ ] Backend API
- [ ] Real-time sync

## Phase 3: Monday Backend
- [ ] Case management
- [ ] Task tracking
- [ ] Team assignment
- [ ] Workflow stages
- [ ] Calendar/deadlines

## Phase 4: Security Layer
- [ ] Permission system
- [ ] Source vault
- [ ] Encryption implementation
- [ ] Audit logging

## Phase 5: Wash System
- [ ] Anonymization engine
- [ ] Boss approval flow
- [ ] External API integration
- [ ] Result re-integration
- [ ] Mode switching (Private/Wash)

## Phase 6: Polish & Deploy
- [ ] Full Electron packaging
- [ ] Auto-updates
- [ ] Backup system
- [ ] Documentation
- [ ] Training materials

---

# HARDWARE

## Test System (Ryzen Build)
- Ryzen 9 7900X
- RTX 4060 Ti 8GB
- 64GB RAM
- ~$2,460

## Production System (BIZON X5500 G2)
- 2x RTX 5090 32GB
- Threadripper Pro
- 256GB RAM
- 10GbE NIC
- ~$20K

## Wash Center Options
- Your own cloud (AWS/GCP)
- Private contractor
- Secondary on-prem server

---

# FILES CREATED THIS SESSION

| File | Location | Purpose |
|------|----------|---------|
| RAG Pipeline | `/home/claude/legal-rag-pipeline/` | Full document processing system |
| Investigation Board v2 | `/mnt/user-data/outputs/investigation-board-v2.html` | Polished prototype |
| Architecture Spec | `/mnt/user-data/outputs/investigation-board-architecture.md` | Technical design |
| Vision Document | `/mnt/user-data/outputs/legal-vision-final.pdf` | Client-facing 12-page doc |
| Corkboard Visual | `/mnt/user-data/outputs/legal-corkboard.html` | Murder board concept |
| This Document | Current file | Master state for continuation |

---

# CONTACT

Wesley Thompson
385-461-4164

---

# TO CONTINUE IN NEW CONVERSATION

Provide this document as context. Key points:

1. "We're building a legal investigation platform that looks like a playful cork board but has enterprise security underneath"

2. "RAG pipeline is built, investigation board prototype exists, need to add Monday-style backend, source vault, permission system, and two-mode (Private/Wash) operation"

3. "Boss-only button for external AI processing, everything else stays local"

4. "Medical malpractice focus but extensible"

---

*Last Updated: December 21, 2024*
*Session: Investigation Board System Design*

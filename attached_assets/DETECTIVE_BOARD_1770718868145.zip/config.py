"""
Configuration Management
========================
Loads and validates pipeline configuration from YAML.
Supports environment variable substitution.
"""

import os
import re
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings


class OCRConfig(BaseModel):
    """OCR processing configuration."""
    confidence_threshold: float = Field(default=0.85, ge=0.0, le=1.0)
    languages: list[str] = Field(default=["en"])
    use_gpu: bool = True
    use_angle_cls: bool = True
    det_db_thresh: float = 0.3
    det_db_box_thresh: float = 0.5
    rec_batch_num: int = 6
    max_image_size: int = 4096


class ClaudeConfig(BaseModel):
    """Claude API configuration."""
    model: str = "claude-sonnet-4-20250514"
    max_tokens: int = 4096
    temperature: float = 0.3


class OllamaConfig(BaseModel):
    """Ollama local LLM configuration."""
    model: str = "llama3:70b"
    host: str = "http://localhost:11434"
    timeout: int = 300


class ToneAnalysisConfig(BaseModel):
    """Tone analysis configuration."""
    provider: str = Field(default="claude", pattern="^(claude|ollama)$")
    claude: ClaudeConfig = Field(default_factory=ClaudeConfig)
    ollama: OllamaConfig = Field(default_factory=OllamaConfig)
    flags: list[str] = Field(default=[
        "contradictory", "evasive", "aggressive", "defensive",
        "timeline_issue", "detail_inconsistency", "unusual_word_choice", "missing_info"
    ])


class SemanticChunkConfig(BaseModel):
    """Semantic chunking configuration."""
    target_chunk_size: int = 1000
    max_chunk_size: int = 2000
    min_chunk_size: int = 100
    overlap_sentences: int = 2
    respect_paragraphs: bool = True
    respect_sections: bool = True


class SlidingChunkConfig(BaseModel):
    """Sliding window chunking configuration."""
    window_size: int = 512
    overlap: int = 128


class ChunkingConfig(BaseModel):
    """Chunking configuration."""
    strategy: str = Field(default="semantic", pattern="^(semantic|sliding)$")
    semantic: SemanticChunkConfig = Field(default_factory=SemanticChunkConfig)
    sliding: SlidingChunkConfig = Field(default_factory=SlidingChunkConfig)


class EmbeddingConfig(BaseModel):
    """Embedding configuration."""
    model: str = "BAAI/bge-large-en-v1.5"
    dimension: int = 1024
    batch_size: int = 32
    normalize: bool = True
    use_gpu: bool = True
    query_prefix: str = "Represent this sentence for searching relevant passages: "
    document_prefix: str = ""


class VectorConfig(BaseModel):
    """Qdrant vector configuration."""
    size: int = 1024
    distance: str = "Cosine"


class IndexingConfig(BaseModel):
    """Qdrant indexing configuration."""
    hnsw_m: int = 16
    hnsw_ef_construct: int = 100
    payload_indexes: list[str] = Field(default=[
        "source_file", "tone_flags", "file_type", "upload_date", "confidence_score"
    ])


class QueryConfig(BaseModel):
    """Qdrant query configuration."""
    default_limit: int = 10
    hnsw_ef: int = 128
    score_threshold: float = 0.7


class QdrantConfig(BaseModel):
    """Qdrant configuration."""
    host: str = "localhost"
    port: int = 6333
    grpc_port: int = 6334
    collection_name: str = "legal_documents"
    vector_config: VectorConfig = Field(default_factory=VectorConfig)
    indexing: IndexingConfig = Field(default_factory=IndexingConfig)
    query: QueryConfig = Field(default_factory=QueryConfig)


class FilePathsConfig(BaseModel):
    """File paths configuration."""
    input: str = "./data/input"
    processed: str = "./data/processed"
    archive: str = "./data/archive"
    logs: str = "./logs"


class FileProcessingConfig(BaseModel):
    """File processing configuration."""
    archive_originals: bool = True
    max_file_size_mb: int = 100
    pdf_dpi: int = 300
    max_workers: int = 4


class FilesConfig(BaseModel):
    """Files configuration."""
    supported_types: list[str] = Field(default=[
        ".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".tif", ".bmp", ".docx", ".doc", ".txt", ".rtf"
    ])
    paths: FilePathsConfig = Field(default_factory=FilePathsConfig)
    processing: FileProcessingConfig = Field(default_factory=FileProcessingConfig)


class LogFileConfig(BaseModel):
    """Log file configuration."""
    enabled: bool = True
    path: str = "./logs/pipeline.log"
    rotation: str = "10 MB"
    retention: int = 30


class AuditConfig(BaseModel):
    """Audit trail configuration."""
    enabled: bool = True
    path: str = "./logs/audit.log"
    log_ocr_results: bool = True
    log_tone_analysis: bool = True
    log_embeddings: bool = False
    log_qdrant_operations: bool = True


class LoggingConfig(BaseModel):
    """Logging configuration."""
    level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR)$")
    format: str = Field(default="json", pattern="^(json|console)$")
    file: LogFileConfig = Field(default_factory=LogFileConfig)
    audit: AuditConfig = Field(default_factory=AuditConfig)


class GPUConfig(BaseModel):
    """GPU configuration."""
    device: int = 0
    memory_fraction: float = 0.8


class CacheConfig(BaseModel):
    """Cache configuration."""
    enabled: bool = True
    embeddings: bool = True
    ocr_results: bool = True


class PerformanceConfig(BaseModel):
    """Performance configuration."""
    batch_size: int = 10
    max_memory_gb: int = 32
    gpu: GPUConfig = Field(default_factory=GPUConfig)
    cache: CacheConfig = Field(default_factory=CacheConfig)


class APIKeysConfig(BaseModel):
    """API keys configuration."""
    anthropic: Optional[str] = None


class PipelineConfig(BaseModel):
    """Complete pipeline configuration."""
    ocr: OCRConfig = Field(default_factory=OCRConfig)
    tone_analysis: ToneAnalysisConfig = Field(default_factory=ToneAnalysisConfig)
    chunking: ChunkingConfig = Field(default_factory=ChunkingConfig)
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    qdrant: QdrantConfig = Field(default_factory=QdrantConfig)
    files: FilesConfig = Field(default_factory=FilesConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    performance: PerformanceConfig = Field(default_factory=PerformanceConfig)
    api_keys: APIKeysConfig = Field(default_factory=APIKeysConfig)


def substitute_env_vars(config_dict: dict[str, Any]) -> dict[str, Any]:
    """
    Recursively substitute environment variables in config values.
    Format: ${ENV_VAR_NAME} or ${ENV_VAR_NAME:default_value}
    """
    env_pattern = re.compile(r'\$\{([^}:]+)(?::([^}]*))?\}')
    
    def substitute(value: Any) -> Any:
        if isinstance(value, str):
            def replacer(match):
                var_name = match.group(1)
                default = match.group(2)
                return os.environ.get(var_name, default if default is not None else "")
            return env_pattern.sub(replacer, value)
        elif isinstance(value, dict):
            return {k: substitute(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [substitute(item) for item in value]
        return value
    
    return substitute(config_dict)


def load_config(config_path: Optional[str] = None) -> PipelineConfig:
    """
    Load configuration from YAML file.
    
    Args:
        config_path: Path to config file. Defaults to config/config.yaml
    
    Returns:
        Validated PipelineConfig instance
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        ValidationError: If config validation fails
    """
    if config_path is None:
        # Look for config relative to this file or in current directory
        possible_paths = [
            Path(__file__).parent.parent / "config" / "config.yaml",
            Path("config/config.yaml"),
            Path("config.yaml"),
        ]
        for path in possible_paths:
            if path.exists():
                config_path = str(path)
                break
        else:
            raise FileNotFoundError(
                f"Config file not found. Searched: {[str(p) for p in possible_paths]}"
            )
    
    config_file = Path(config_path)
    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_file, 'r') as f:
        raw_config = yaml.safe_load(f)
    
    # Substitute environment variables
    config_dict = substitute_env_vars(raw_config)
    
    # Validate and return
    return PipelineConfig(**config_dict)


# Global config instance (lazy loaded)
_config: Optional[PipelineConfig] = None


def get_config() -> PipelineConfig:
    """Get the global configuration instance."""
    global _config
    if _config is None:
        _config = load_config()
    return _config


def reload_config(config_path: Optional[str] = None) -> PipelineConfig:
    """Reload configuration from file."""
    global _config
    _config = load_config(config_path)
    return _config

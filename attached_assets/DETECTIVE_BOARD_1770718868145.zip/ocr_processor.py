"""
OCR Processor
=============
Extracts text from images using PaddleOCR.
Handles scans, handwriting, and rotated documents.
Provides confidence scoring for legal defensibility.
"""

from dataclasses import dataclass, field
from typing import Optional
import numpy as np
from PIL import Image

from paddleocr import PaddleOCR

from .config import get_config
from .logger import get_logger, get_audit_logger
from .file_handler import LoadedFile, FileType


@dataclass
class OCRResult:
    """Result from OCR processing of a single page."""
    page_number: int
    text: str
    confidence: float  # Average confidence 0-1
    line_results: list[dict] = field(default_factory=list)  # Individual line details
    low_confidence_regions: list[dict] = field(default_factory=list)


@dataclass
class DocumentOCRResult:
    """Complete OCR result for a document."""
    source_file: str
    file_type: str
    pages: list[OCRResult]
    full_text: str  # Concatenated text from all pages
    average_confidence: float
    low_confidence_pages: list[int]  # Pages below threshold
    
    @property
    def page_count(self) -> int:
        return len(self.pages)


class OCRProcessor:
    """
    Processes images and documents using PaddleOCR.
    Designed for legal documents including scans and handwriting.
    """
    
    def __init__(self):
        self.config = get_config().ocr
        self.logger = get_logger()
        self.audit = get_audit_logger()
        
        # Initialize PaddleOCR
        self.logger.info(
            "initializing_paddleocr",
            use_gpu=self.config.use_gpu,
            languages=self.config.languages
        )
        
        self.ocr = PaddleOCR(
            use_angle_cls=self.config.use_angle_cls,
            lang=self.config.languages[0],  # Primary language
            use_gpu=self.config.use_gpu,
            det_db_thresh=self.config.det_db_thresh,
            det_db_box_thresh=self.config.det_db_box_thresh,
            rec_batch_num=self.config.rec_batch_num,
            show_log=False,  # Suppress paddle logs
        )
        
        self.logger.info("paddleocr_initialized")
    
    def _preprocess_image(self, image: Image.Image) -> np.ndarray:
        """
        Preprocess image for OCR.
        - Resize if too large
        - Convert to numpy array
        """
        # Resize if needed
        max_size = self.config.max_image_size
        if max(image.size) > max_size:
            ratio = max_size / max(image.size)
            new_size = (int(image.width * ratio), int(image.height * ratio))
            image = image.resize(new_size, Image.Resampling.LANCZOS)
        
        # Convert to numpy array (RGB)
        return np.array(image)
    
    def _extract_text_from_result(
        self,
        ocr_result: list,
        page_number: int
    ) -> OCRResult:
        """
        Extract text and confidence from PaddleOCR result.
        
        PaddleOCR returns: [[[box], (text, confidence)], ...]
        """
        if not ocr_result or not ocr_result[0]:
            return OCRResult(
                page_number=page_number,
                text="",
                confidence=0.0,
                line_results=[],
                low_confidence_regions=[]
            )
        
        lines = []
        line_results = []
        low_confidence_regions = []
        confidences = []
        
        for item in ocr_result[0]:
            if len(item) < 2:
                continue
            
            box = item[0]  # Bounding box coordinates
            text_info = item[1]  # (text, confidence)
            
            if isinstance(text_info, tuple) and len(text_info) >= 2:
                text = text_info[0]
                confidence = float(text_info[1])
            else:
                continue
            
            lines.append(text)
            confidences.append(confidence)
            
            line_detail = {
                "text": text,
                "confidence": confidence,
                "box": box,
            }
            line_results.append(line_detail)
            
            # Track low confidence regions
            if confidence < self.config.confidence_threshold:
                low_confidence_regions.append({
                    "text": text,
                    "confidence": confidence,
                    "box": box,
                })
        
        # Calculate average confidence
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        return OCRResult(
            page_number=page_number,
            text="\n".join(lines),
            confidence=avg_confidence,
            line_results=line_results,
            low_confidence_regions=low_confidence_regions
        )
    
    def process_image(self, image: Image.Image, page_number: int = 1) -> OCRResult:
        """
        Process a single image with OCR.
        
        Args:
            image: PIL Image to process
            page_number: Page number for tracking
        
        Returns:
            OCRResult with extracted text and confidence
        """
        # Preprocess
        img_array = self._preprocess_image(image)
        
        # Run OCR
        result = self.ocr.ocr(img_array, cls=self.config.use_angle_cls)
        
        # Extract text and confidence
        return self._extract_text_from_result(result, page_number)
    
    def process_document(self, loaded_file: LoadedFile) -> DocumentOCRResult:
        """
        Process an entire document with OCR.
        
        Args:
            loaded_file: LoadedFile from FileHandler
        
        Returns:
            DocumentOCRResult with all pages processed
        """
        source_file = loaded_file.metadata.filename
        file_type = loaded_file.metadata.file_type.value
        
        self.logger.info(
            "ocr_processing_started",
            file=source_file,
            file_type=file_type,
        )
        
        self.audit.log_ocr(
            source_file=source_file,
            status="started",
        )
        
        pages: list[OCRResult] = []
        low_confidence_pages: list[int] = []
        
        try:
            # If we have pre-extracted text (e.g., from DOCX), validate it
            if loaded_file.text_content:
                self.logger.info(
                    "using_preextracted_text",
                    file=source_file,
                    text_length=len(loaded_file.text_content)
                )
                
                # Create a single "page" result for pre-extracted text
                pages.append(OCRResult(
                    page_number=1,
                    text=loaded_file.text_content,
                    confidence=1.0,  # Pre-extracted text is high confidence
                    line_results=[],
                    low_confidence_regions=[]
                ))
            
            # Process images (from PDF, scans, etc.)
            elif loaded_file.images:
                for idx, image in enumerate(loaded_file.images, start=1):
                    self.logger.debug(
                        "processing_page",
                        file=source_file,
                        page=idx,
                        total_pages=len(loaded_file.images)
                    )
                    
                    page_result = self.process_image(image, page_number=idx)
                    pages.append(page_result)
                    
                    # Track low confidence pages
                    if page_result.confidence < self.config.confidence_threshold:
                        low_confidence_pages.append(idx)
                        self.logger.warning(
                            "low_confidence_page",
                            file=source_file,
                            page=idx,
                            confidence=page_result.confidence,
                            threshold=self.config.confidence_threshold
                        )
            
            else:
                raise ValueError(f"No content to process in {source_file}")
            
            # Combine all text
            full_text = "\n\n".join([p.text for p in pages if p.text])
            
            # Calculate overall confidence
            if pages:
                avg_confidence = sum(p.confidence for p in pages) / len(pages)
            else:
                avg_confidence = 0.0
            
            result = DocumentOCRResult(
                source_file=source_file,
                file_type=file_type,
                pages=pages,
                full_text=full_text,
                average_confidence=avg_confidence,
                low_confidence_pages=low_confidence_pages
            )
            
            # Log success
            self.logger.info(
                "ocr_processing_completed",
                file=source_file,
                pages_processed=len(pages),
                avg_confidence=avg_confidence,
                low_confidence_pages=len(low_confidence_pages),
                text_length=len(full_text)
            )
            
            self.audit.log_ocr(
                source_file=source_file,
                status="completed",
                pages_processed=len(pages),
                confidence_scores=[p.confidence for p in pages],
                low_confidence_pages=low_confidence_pages
            )
            
            return result
        
        except Exception as e:
            self.logger.error(
                "ocr_processing_failed",
                file=source_file,
                error=str(e),
                exc_info=True
            )
            
            self.audit.log_ocr(
                source_file=source_file,
                status="failed",
                error=str(e)
            )
            
            raise
    
    def validate_result(self, result: DocumentOCRResult) -> dict:
        """
        Validate OCR result quality.
        
        Returns:
            Dict with validation status and any issues found
        """
        issues = []
        
        # Check overall confidence
        if result.average_confidence < self.config.confidence_threshold:
            issues.append({
                "type": "low_overall_confidence",
                "value": result.average_confidence,
                "threshold": self.config.confidence_threshold
            })
        
        # Check for empty pages
        empty_pages = [p.page_number for p in result.pages if not p.text.strip()]
        if empty_pages:
            issues.append({
                "type": "empty_pages",
                "pages": empty_pages
            })
        
        # Check for very short text (might indicate failed OCR)
        if len(result.full_text) < 50 and result.page_count > 0:
            issues.append({
                "type": "insufficient_text",
                "text_length": len(result.full_text),
                "page_count": result.page_count
            })
        
        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "confidence": result.average_confidence,
            "page_count": result.page_count,
            "text_length": len(result.full_text)
        }

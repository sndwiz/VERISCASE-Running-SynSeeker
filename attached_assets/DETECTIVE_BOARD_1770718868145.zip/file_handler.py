"""
File Handler
============
Detects file types and loads documents uniformly regardless of format.
Handles PDFs, images, scans, Word docs, and text files.
"""

import io
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional, Union
import hashlib

from PIL import Image
from pdf2image import convert_from_path
from docx import Document as DocxDocument

from .config import get_config
from .logger import get_logger, get_audit_logger


class FileType(Enum):
    """Supported file types."""
    PDF = "pdf"
    IMAGE = "image"
    DOCX = "docx"
    DOC = "doc"
    TEXT = "text"
    RTF = "rtf"
    UNKNOWN = "unknown"


@dataclass
class FileMetadata:
    """Metadata extracted from a file."""
    original_path: str
    filename: str
    file_type: FileType
    file_size_bytes: int
    file_hash: str  # SHA-256 for integrity
    created_at: Optional[datetime] = None
    modified_at: Optional[datetime] = None
    page_count: Optional[int] = None
    mime_type: Optional[str] = None


@dataclass
class LoadedFile:
    """A loaded file ready for processing."""
    metadata: FileMetadata
    images: list[Image.Image] = field(default_factory=list)  # For OCR
    text_content: Optional[str] = None  # Pre-extracted text (if available)
    raw_bytes: Optional[bytes] = None  # Original file bytes


class FileHandler:
    """
    Handles file detection, loading, and validation.
    Produces uniform output regardless of input format.
    """
    
    # Extension to FileType mapping
    EXTENSION_MAP = {
        ".pdf": FileType.PDF,
        ".png": FileType.IMAGE,
        ".jpg": FileType.IMAGE,
        ".jpeg": FileType.IMAGE,
        ".tiff": FileType.IMAGE,
        ".tif": FileType.IMAGE,
        ".bmp": FileType.IMAGE,
        ".docx": FileType.DOCX,
        ".doc": FileType.DOC,
        ".txt": FileType.TEXT,
        ".rtf": FileType.RTF,
    }
    
    # MIME type mapping
    MIME_MAP = {
        FileType.PDF: "application/pdf",
        FileType.IMAGE: "image/*",
        FileType.DOCX: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        FileType.DOC: "application/msword",
        FileType.TEXT: "text/plain",
        FileType.RTF: "application/rtf",
    }
    
    def __init__(self):
        self.config = get_config().files
        self.logger = get_logger()
        self.audit = get_audit_logger()
        
        # Ensure directories exist
        for path_name in ["input", "processed", "archive"]:
            path = Path(getattr(self.config.paths, path_name))
            path.mkdir(parents=True, exist_ok=True)
    
    def detect_file_type(self, file_path: Union[str, Path]) -> FileType:
        """
        Detect file type from extension.
        
        Args:
            file_path: Path to the file
        
        Returns:
            Detected FileType enum
        """
        path = Path(file_path)
        extension = path.suffix.lower()
        return self.EXTENSION_MAP.get(extension, FileType.UNKNOWN)
    
    def _compute_hash(self, file_path: Path) -> str:
        """Compute SHA-256 hash of file."""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    def _get_file_metadata(self, file_path: Path) -> FileMetadata:
        """Extract metadata from file."""
        stat = file_path.stat()
        file_type = self.detect_file_type(file_path)
        
        return FileMetadata(
            original_path=str(file_path.absolute()),
            filename=file_path.name,
            file_type=file_type,
            file_size_bytes=stat.st_size,
            file_hash=self._compute_hash(file_path),
            created_at=datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc),
            modified_at=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
            mime_type=self.MIME_MAP.get(file_type),
        )
    
    def _validate_file(self, file_path: Path, metadata: FileMetadata) -> None:
        """
        Validate file before processing.
        
        Raises:
            ValueError: If file fails validation
        """
        # Check file exists
        if not file_path.exists():
            raise ValueError(f"File not found: {file_path}")
        
        # Check file type is supported
        if metadata.file_type == FileType.UNKNOWN:
            raise ValueError(
                f"Unsupported file type: {file_path.suffix}. "
                f"Supported: {list(self.EXTENSION_MAP.keys())}"
            )
        
        # Check file size
        max_size = self.config.processing.max_file_size_mb * 1024 * 1024
        if metadata.file_size_bytes > max_size:
            raise ValueError(
                f"File too large: {metadata.file_size_bytes / 1024 / 1024:.1f}MB. "
                f"Max: {self.config.processing.max_file_size_mb}MB"
            )
    
    def _load_pdf(self, file_path: Path) -> tuple[list[Image.Image], int]:
        """Convert PDF pages to images for OCR."""
        images = convert_from_path(
            file_path,
            dpi=self.config.processing.pdf_dpi,
            fmt='RGB',
        )
        return images, len(images)
    
    def _load_image(self, file_path: Path) -> list[Image.Image]:
        """Load image file."""
        image = Image.open(file_path)
        # Convert to RGB if necessary (e.g., RGBA, grayscale)
        if image.mode != 'RGB':
            image = image.convert('RGB')
        return [image]
    
    def _load_docx(self, file_path: Path) -> tuple[Optional[str], int]:
        """
        Load DOCX file and extract text.
        Also counts "pages" based on section breaks or paragraph count.
        """
        doc = DocxDocument(file_path)
        
        # Extract all paragraphs
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text)
        
        # Extract text from tables too
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if cell.text.strip():
                        paragraphs.append(cell.text)
        
        text_content = "\n\n".join(paragraphs)
        
        # Estimate page count (rough: ~3000 chars per page)
        estimated_pages = max(1, len(text_content) // 3000)
        
        return text_content, estimated_pages
    
    def _load_text(self, file_path: Path) -> str:
        """Load text file."""
        # Try common encodings
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    return f.read()
            except UnicodeDecodeError:
                continue
        
        # Fallback: read as binary and decode with errors ignored
        with open(file_path, 'rb') as f:
            return f.read().decode('utf-8', errors='ignore')
    
    def load(self, file_path: Union[str, Path]) -> LoadedFile:
        """
        Load a file and prepare it for processing.
        
        Args:
            file_path: Path to the file to load
        
        Returns:
            LoadedFile with images and/or text ready for processing
        
        Raises:
            ValueError: If file validation fails
            IOError: If file cannot be read
        """
        path = Path(file_path)
        self.logger.info("loading_file", file_path=str(path))
        
        # Get metadata
        metadata = self._get_file_metadata(path)
        
        # Validate
        self._validate_file(path, metadata)
        
        # Load based on type
        loaded = LoadedFile(metadata=metadata)
        
        try:
            if metadata.file_type == FileType.PDF:
                loaded.images, metadata.page_count = self._load_pdf(path)
                self.logger.info(
                    "pdf_loaded",
                    file_path=str(path),
                    pages=metadata.page_count
                )
            
            elif metadata.file_type == FileType.IMAGE:
                loaded.images = self._load_image(path)
                metadata.page_count = 1
                self.logger.info("image_loaded", file_path=str(path))
            
            elif metadata.file_type == FileType.DOCX:
                loaded.text_content, metadata.page_count = self._load_docx(path)
                self.logger.info(
                    "docx_loaded",
                    file_path=str(path),
                    estimated_pages=metadata.page_count
                )
            
            elif metadata.file_type == FileType.TEXT:
                loaded.text_content = self._load_text(path)
                metadata.page_count = 1
                self.logger.info("text_loaded", file_path=str(path))
            
            elif metadata.file_type == FileType.DOC:
                # .doc files need conversion - for now, treat as binary and OCR
                self.logger.warning(
                    "doc_legacy_format",
                    file_path=str(path),
                    message="Legacy .doc format - will attempt OCR on converted content"
                )
                # Would need antiword or LibreOffice conversion
                raise NotImplementedError(
                    "Legacy .doc format requires conversion. "
                    "Please convert to .docx or PDF first."
                )
            
            elif metadata.file_type == FileType.RTF:
                # RTF files - read as text with stripping
                loaded.text_content = self._load_text(path)
                metadata.page_count = 1
                self.logger.info("rtf_loaded", file_path=str(path))
            
            # Log audit entry
            self.audit.log(
                operation="file_load",
                status="completed",
                source_file=str(path),
                details={
                    "file_type": metadata.file_type.value,
                    "file_size": metadata.file_size_bytes,
                    "page_count": metadata.page_count,
                    "file_hash": metadata.file_hash,
                }
            )
            
            return loaded
        
        except Exception as e:
            self.audit.log(
                operation="file_load",
                status="failed",
                source_file=str(path),
                details={"file_type": metadata.file_type.value},
                error=str(e)
            )
            raise
    
    def archive(self, file_path: Union[str, Path]) -> Path:
        """
        Archive a processed file.
        
        Args:
            file_path: Path to file to archive
        
        Returns:
            Path to archived file
        """
        source = Path(file_path)
        archive_dir = Path(self.config.paths.archive)
        
        # Create dated subdirectory
        date_dir = archive_dir / datetime.now().strftime("%Y/%m/%d")
        date_dir.mkdir(parents=True, exist_ok=True)
        
        # Copy to archive with hash suffix for uniqueness
        file_hash = self._compute_hash(source)[:8]
        dest = date_dir / f"{source.stem}_{file_hash}{source.suffix}"
        
        shutil.copy2(source, dest)
        
        self.logger.info(
            "file_archived",
            source=str(source),
            destination=str(dest)
        )
        
        return dest
    
    def list_input_files(self) -> list[Path]:
        """List all files in the input directory."""
        input_dir = Path(self.config.paths.input)
        files = []
        
        for ext in self.config.supported_types:
            files.extend(input_dir.glob(f"**/*{ext}"))
            files.extend(input_dir.glob(f"**/*{ext.upper()}"))
        
        return sorted(files)

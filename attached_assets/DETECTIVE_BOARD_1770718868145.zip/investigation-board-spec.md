# INVESTIGATION BOARD
## Interactive Case Building Application for Medical Malpractice

---

## PRODUCT VISION

A digital corkboard where attorneys build cases visually. Drag evidence, connect threads, map timelines. Like Freeform or Miro, but purpose-built for legal investigation with AI-powered analysis from the RAG pipeline.

**Target User:** Medical malpractice attorneys building cases

**Core Metaphor:** Detective's murder board - pins, string, photos, notes, evidence tags

---

## THE 4 ZONES (Medical Malpractice Elements)

Every med mal case requires proving 4 elements. The board is organized around these:

### ZONE 1: DUTY
*Did a doctor-patient relationship exist?*

**Evidence Types:**
- Admission documents
- Signed consent forms
- Appointment records
- Insurance/billing records
- Referral documentation

**What to Prove:**
- Patient sought treatment
- Provider agreed to treat
- Relationship was established

**Board Elements:**
- 📋 Consent form cards
- 📅 Appointment timeline
- 🏥 Facility relationship map

---

### ZONE 2: BREACH (Standard of Care)
*Did the provider deviate from accepted practice?*

**Evidence Types:**
- Medical records (notes, orders, charts)
- Imaging/test results
- Clinical practice guidelines
- Expert witness opinions
- Hospital protocols
- Peer-reviewed literature

**What to Prove:**
- What the standard of care WAS
- What the provider actually DID
- The GAP between them

**Board Elements:**
- 📊 Standard of Care reference cards
- ⚠️ Deviation flags (from AI analysis)
- 👨‍⚕️ Expert opinion cards
- 📑 Protocol comparison charts

---

### ZONE 3: CAUSATION
*Did the breach directly cause the injury?*

**Evidence Types:**
- Medical timeline
- Before/after documentation
- Expert causation opinions
- Alternative cause analysis
- Progression of injury records

**What to Prove:**
- Direct link between breach and harm
- Injury would NOT have occurred without breach
- No intervening causes

**Board Elements:**
- ⏰ Causation timeline
- 🔗 Cause-effect connection strings
- ❌ Alternative causes ruled out
- 📈 Injury progression chart

---

### ZONE 4: DAMAGES
*What harm did the patient suffer?*

**Evidence Types:**
- Medical bills
- Lost wage documentation
- Future care estimates
- Pain/suffering journals
- Therapy/mental health records
- Life impact statements

**What to Prove:**
- Economic damages (calculable)
- Non-economic damages (pain, suffering)
- Future damages (ongoing care)

**Board Elements:**
- 💰 Economic damage cards
- 😢 Impact statement notes
- 📊 Damage calculation summary
- 🏥 Future care projection

---

## BOARD ELEMENT TYPES

### 1. EVIDENCE CARD
```
┌─────────────────────────────┐
│ 📌 [colored pin]            │
├─────────────────────────────┤
│ EVIDENCE TYPE               │
│ ─────────────────           │
│ Title/Description           │
│                             │
│ Source: [document name]     │
│ Page: [#]                   │
│ Date: [date]                │
│                             │
│ [AI FLAGS if any]           │
│ ⚠️ Contradiction detected   │
└─────────────────────────────┘
```

### 2. STICKY NOTE
```
┌─────────────────────────────┐
│ [handwritten style text]    │
│                             │
│ Attorney notes, questions,  │
│ reminders, theories         │
│                             │
└─────────────────────────────┘
Colors: Yellow, Pink, Blue, Green, Orange
```

### 3. PHOTO/DOCUMENT THUMBNAIL
```
┌─────────────────────────────┐
│ ┌───────────────────────┐   │
│ │                       │   │
│ │   [document preview]  │   │
│ │                       │   │
│ └───────────────────────┘   │
│ filename.pdf                │
│ "Admission Records 3/15"    │
└─────────────────────────────┘
```

### 4. TIMELINE NODE
```
●───────●───────●───────●
│       │       │       │
Date1   Date2   Date3   Date4
Event1  Event2  Event3  Event4
```

### 5. PERSON CARD
```
┌─────────────────────────────┐
│      👤                     │
│   [Name]                    │
│   [Role: Patient/Doctor/    │
│    Nurse/Expert]            │
│                             │
│   Key involvement:          │
│   • [action/statement]      │
│   • [action/statement]      │
└─────────────────────────────┘
```

### 6. CONNECTION STRING
- Red string: Contradiction
- Blue string: Supports
- Yellow string: Related
- Green string: Proves element
- Dashed: Weak/needs verification

### 7. EVIDENCE TAG
```
┌─────────────────┐
│ EXHIBIT A-001   │
│ [description]   │
└─────────────────┘
```

### 8. QUOTE CARD
```
┌─────────────────────────────┐
│ "                           │
│ [exact quote from document] │
│                           " │
│                             │
│ - [Source], p.[#]           │
│ - [Date]                    │
└─────────────────────────────┘
```

### 9. QUESTION CARD
```
┌─────────────────────────────┐
│ ❓ OPEN QUESTION            │
│ ─────────────────           │
│ [question to investigate]   │
│                             │
│ Status: 🔴 Unresolved       │
│         🟡 Investigating    │
│         🟢 Answered         │
└─────────────────────────────┘
```

### 10. CONTRADICTION FLAG
```
┌─────────────────────────────┐
│ ⚡ CONTRADICTION            │
│ ─────────────────           │
│ Statement A: "[quote]"      │
│ Source: [doc], p.[#]        │
│                             │
│ vs.                         │
│                             │
│ Statement B: "[quote]"      │
│ Source: [doc], p.[#]        │
│                             │
│ Confidence: 94%             │
└─────────────────────────────┘
```

---

## AI INTEGRATION (From RAG Pipeline)

The board connects to our existing RAG system:

### Auto-Population
When documents are processed through the pipeline:
1. Entities extracted → Person cards created
2. Dates extracted → Timeline nodes created
3. Contradictions found → Contradiction flags created
4. Key quotes identified → Quote cards created
5. Evidence categorized → Placed in appropriate zone

### On-Demand Analysis
Right-click any card → "Analyze with AI"
- Find related evidence
- Check for contradictions
- Generate questions
- Suggest connections

### Search Integration
Search bar queries the vector database:
- "Show all evidence about [topic]"
- "Find contradictions about [subject]"
- "Timeline of [person]'s involvement"

---

## INVESTIGATION METHODOLOGY

Based on established legal/investigative frameworks:

### Phase 1: Evidence Collection
- Import documents into RAG pipeline
- AI extracts and categorizes evidence
- Cards auto-populate on board
- Attorney reviews and organizes

### Phase 2: Relationship Mapping
- Connect evidence with strings
- Identify gaps in each zone
- Flag contradictions
- Map person involvement

### Phase 3: Timeline Construction
- Build chronological sequence
- Identify impossible sequences
- Map cause → effect chains
- Find delay patterns

### Phase 4: Element Verification
- Check each zone has sufficient evidence
- Identify weak points
- Document what's missing
- Prioritize next steps

### Phase 5: Case Theory Development
- Draw connections across zones
- Build narrative flow
- Prepare for expert review
- Export for presentation

---

## TEMPLATES

### Medical Malpractice - Surgical Error
Pre-built zones with:
- Pre-op assessment section
- Intra-operative timeline
- Post-op complication tracking
- Standard of care reference cards
- Common surgical error flags

### Medical Malpractice - Diagnostic Failure
Pre-built zones with:
- Symptom presentation timeline
- Test/imaging sequence
- Referral tracking
- Delay analysis
- Outcome comparison

### Medical Malpractice - Medication Error
Pre-built zones with:
- Prescription chain
- Administration records
- Interaction analysis
- Adverse event timeline
- Protocol violation flags

### Medical Malpractice - Birth Injury
Pre-built zones with:
- Prenatal care timeline
- Labor & delivery sequence
- Fetal monitoring analysis
- Intervention decisions
- Outcome documentation

---

## TECHNICAL ARCHITECTURE

### Frontend
- React with TypeScript
- React-DnD for drag/drop
- Canvas-based rendering (Fabric.js or Konva)
- Real-time collaboration (optional)

### Backend
- FastAPI (Python)
- Connects to existing RAG pipeline
- Qdrant for vector search
- PostgreSQL for board state

### Storage
- Board state: JSON in PostgreSQL
- Documents: Existing file storage
- Exports: PDF, PNG, JSON

---

## USER INTERACTIONS

### Drag & Drop
- Drag elements from palette
- Drop anywhere on board
- Snap to grid (optional)
- Free rotation

### Connections
- Click + drag from pin to pin
- String follows cursor
- Color selection on connection
- Label connections

### Zoom & Pan
- Mouse wheel zoom
- Click + drag to pan
- Minimap navigation
- Fit to screen

### Context Menu (Right-click)
- Edit element
- Delete element
- Duplicate
- Analyze with AI
- Connect to...
- Add to zone
- Export element

### Keyboard Shortcuts
- Delete: Remove selected
- Ctrl+C/V: Copy/paste
- Ctrl+Z: Undo
- Space+drag: Pan
- +/-: Zoom

---

## EXPORT OPTIONS

### For Trial
- High-res PNG/PDF of full board
- Individual zone exports
- Timeline exports
- Evidence list with citations

### For Expert Review
- Zone-specific views
- Evidence summary by element
- Question list
- Gap analysis report

### For Client
- Simplified overview
- Key findings summary
- Timeline visualization
- Damage summary

---

## COLLABORATION (Future)

- Multiple users on same board
- Role-based permissions (attorney, paralegal, expert)
- Comment threads on elements
- Version history
- Activity log

---

## SECURITY

- All data stays on-premises
- Board state encrypted at rest
- User authentication required
- Audit trail of all changes
- Export logging

---

## MVP SCOPE

### Phase 1 MVP (4 weeks)
- [ ] Canvas with drag/drop
- [ ] Basic element types (cards, notes, strings)
- [ ] 4 zone structure
- [ ] Save/load board state
- [ ] Manual element creation
- [ ] PDF export

### Phase 2 (4 weeks)
- [ ] AI integration (auto-populate from RAG)
- [ ] Search within board
- [ ] Templates
- [ ] Timeline visualization
- [ ] Contradiction highlighting

### Phase 3 (4 weeks)
- [ ] Collaboration features
- [ ] Advanced exports
- [ ] Mobile view
- [ ] Presentation mode

---

## SUCCESS METRICS

- Time to build case visualization: 80% reduction
- Evidence gaps identified: Track %
- Contradictions found via AI: Count
- User adoption: Active boards per attorney
- Case outcomes: Win rate correlation (long term)

---

## COMPETITIVE LANDSCAPE

| Product | What It Does | Gap We Fill |
|---------|--------------|-------------|
| Miro | General whiteboard | No legal methodology, no AI |
| Canva | Design tool | No investigation structure |
| Freeform | Apple whiteboard | No legal focus |
| CaseMap | Legal case management | Not visual, not AI-powered |
| Relativity | eDiscovery | Complex, expensive, not visual |

**Our Advantage:**
- Built specifically for medical malpractice
- AI-powered evidence analysis
- Methodology baked in (4 elements)
- Connects to RAG pipeline
- Affordable, on-premises

---

## NEXT STEPS

1. Build interactive prototype (React)
2. Test with sample case
3. Get attorney feedback
4. Iterate on UX
5. Integrate with RAG pipeline
6. Beta with real cases

---

*Document Version: 1.0*
*Last Updated: December 2024*

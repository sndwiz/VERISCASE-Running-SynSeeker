# INVESTIGATION BOARD - FULL SYSTEM ARCHITECTURE
## "Dashboard for Lawyers, Catching Criminals, Cork Board Style"

---

## THE PHILOSOPHY

**What They See:** Charming cork board with pins, string, sticky notes. Approachable. Fun even.

**What's Underneath:** Enterprise-grade AI case analysis with full version control, real-time model updates, and forensic-level audit trails.

**Why:** Lawyers aren't tech people. They don't want to see databases and vector embeddings. They want to *catch the bad guys*. Give them a tool that feels familiar (detective board) but does the heavy lifting invisibly.

---

## CORE ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           PRESENTATION LAYER                            │
│                                                                         │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │                     CORK BOARD UI                                │   │
│   │  • Drag/drop cards, notes, photos                               │   │
│   │  • Draw connections (string)                                     │   │
│   │  • Pan/zoom infinite canvas                                      │   │
│   │  • Visual zones (4 elements)                                     │   │
│   │  • Timeline view toggle                                          │   │
│   │  • Search overlay                                                │   │
│   └─────────────────────────────────────────────────────────────────┘   │
│                                    │                                    │
│                                    ▼                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                           APPLICATION LAYER                             │
│                                                                         │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────┐   │
│   │    State     │  │   Version    │  │   Search     │  │  Export  │   │
│   │   Manager    │  │   Control    │  │   Engine     │  │  Engine  │   │
│   │              │  │              │  │              │  │          │   │
│   │ • Board state│  │ • Snapshots  │  │ • Full-text  │  │ • PDF    │   │
│   │ • Undo/redo  │  │ • Branches   │  │ • Vector     │  │ • PNG    │   │
│   │ • Real-time  │  │ • Diff view  │  │ • Filters    │  │ • JSON   │   │
│   │   sync       │  │ • Restore    │  │              │  │ • Print  │   │
│   └──────────────┘  └──────────────┘  └──────────────┘  └──────────┘   │
│                                    │                                    │
│                                    ▼                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                           INTELLIGENCE LAYER                            │
│                                                                         │
│   ┌──────────────────────────────────────────────────────────────────┐  │
│   │                      AI ANALYSIS ENGINE                          │  │
│   │                                                                  │  │
│   │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐ │  │
│   │  │Contradiction│  │  Timeline  │  │   Tone     │  │  Entity   │ │  │
│   │  │ Detection  │  │  Analysis  │  │  Analysis  │  │ Extraction│ │  │
│   │  └────────────┘  └────────────┘  └────────────┘  └────────────┘ │  │
│   │                                                                  │  │
│   │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐ │  │
│   │  │  Pattern   │  │   Gap      │  │  Standard  │  │  Causation │ │  │
│   │  │  Matching  │  │  Analysis  │  │  of Care   │  │  Mapping   │ │  │
│   │  └────────────┘  └────────────┘  └────────────┘  └────────────┘ │  │
│   │                                                                  │  │
│   └──────────────────────────────────────────────────────────────────┘  │
│                                    │                                    │
│                                    ▼                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                              DATA LAYER                                 │
│                                                                         │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────┐   │
│   │   Document   │  │   Vector     │  │    Case      │  │  Audit   │   │
│   │   Storage    │  │   Database   │  │   Database   │  │   Log    │   │
│   │              │  │              │  │              │  │          │   │
│   │ • Originals  │  │ • Qdrant     │  │ • PostgreSQL │  │ • Every  │   │
│   │ • OCR text   │  │ • Embeddings │  │ • Board state│  │   action │   │
│   │ • Metadata   │  │ • Similarity │  │ • Versions   │  │ • Who    │   │
│   │              │  │   search     │  │ • Elements   │  │ • When   │   │
│   └──────────────┘  └──────────────┘  └──────────────┘  └──────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## VERSION CONTROL SYSTEM

### Why This Matters

"Sometimes you're deep in a case and realize old information is relevant again."

Legal cases evolve. What seemed irrelevant on Day 1 becomes the smoking gun on Day 30. We need:
- **Full history** of every change
- **Ability to revert** to any point
- **Branching** for "what if" scenarios
- **Diff views** to see what changed

### Implementation

```
Case: Doe v. Memorial Hospital
│
├── v1.0 (Initial upload) ─────────────────────────── 2024-03-15
│   └── 12 documents, 3 persons, 0 contradictions
│
├── v1.1 (Model run #1) ───────────────────────────── 2024-03-16
│   └── +2 contradictions detected, +5 timeline nodes
│
├── v1.2 (Added expert report) ────────────────────── 2024-03-20
│   └── +1 document, standard of care mapped
│
├── v2.0 (Major discovery) ────────────────────────── 2024-04-01
│   │   └── +47 documents from subpoena
│   │
│   ├── v2.1 (Model run #2) ───────────────────────── 2024-04-02
│   │   └── +8 contradictions, +3 persons
│   │
│   └── v2.2-branch (Alternative theory) ──────────── 2024-04-05
│       └── Exploring medication error angle
│
├── v3.0 (Deposition transcripts) ─────────────────── 2024-05-01
│   └── +6 documents, timeline refined
│
└── CURRENT ───────────────────────────────────────── 2024-05-15
    └── 67 documents, 12 persons, 14 contradictions
```

### Database Schema

```sql
-- Cases
CREATE TABLE cases (
    id UUID PRIMARY KEY,
    name VARCHAR(255),
    case_number VARCHAR(100),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    current_version_id UUID
);

-- Versions (snapshots)
CREATE TABLE versions (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_number VARCHAR(20),
    parent_version_id UUID,
    created_at TIMESTAMP,
    created_by UUID,
    description TEXT,
    is_branch BOOLEAN DEFAULT FALSE,
    board_state JSONB  -- Full snapshot of board
);

-- Elements (cards, notes, etc.)
CREATE TABLE elements (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_id UUID REFERENCES versions(id),
    element_type VARCHAR(50),
    position_x FLOAT,
    position_y FLOAT,
    rotation FLOAT,
    data JSONB,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    source_document_id UUID,
    ai_generated BOOLEAN DEFAULT FALSE,
    confidence_score FLOAT
);

-- Connections (strings between elements)
CREATE TABLE connections (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    version_id UUID REFERENCES versions(id),
    from_element_id UUID,
    to_element_id UUID,
    connection_type VARCHAR(50),
    label TEXT,
    ai_generated BOOLEAN DEFAULT FALSE
);

-- Audit log
CREATE TABLE audit_log (
    id UUID PRIMARY KEY,
    case_id UUID REFERENCES cases(id),
    user_id UUID,
    action VARCHAR(100),
    element_id UUID,
    old_value JSONB,
    new_value JSONB,
    timestamp TIMESTAMP DEFAULT NOW()
);
```

---

## DATA FLOW: DOCUMENT TO BOARD

### Step 1: Document Ingestion
```
User uploads: deposition.pdf
         │
         ▼
┌─────────────────┐
│  File Handler   │ ─── Detect type: PDF
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   OCR Engine    │ ─── Extract text (PaddleOCR)
│                 │ ─── Confidence: 0.94
└────────┬────────┘
         │
         ▼
Document stored + text indexed
```

### Step 2: AI Analysis
```
Extracted text
         │
         ▼
┌─────────────────────────────────────────────────┐
│              ANALYSIS ENGINE                     │
│                                                  │
│  ┌──────────────┐      ┌──────────────┐         │
│  │   Entity     │      │   Timeline   │         │
│  │  Extraction  │      │  Extraction  │         │
│  │              │      │              │         │
│  │ • Names      │      │ • Dates      │         │
│  │ • Places     │      │ • Sequences  │         │
│  │ • Orgs       │      │ • Durations  │         │
│  └──────────────┘      └──────────────┘         │
│                                                  │
│  ┌──────────────┐      ┌──────────────┐         │
│  │    Tone      │      │ Contradiction │         │
│  │   Analysis   │      │   Detection   │         │
│  │              │      │              │         │
│  │ • Evasive    │      │ • Cross-ref  │         │
│  │ • Aggressive │      │ • Conflicts  │         │
│  │ • Defensive  │      │ • Gaps       │         │
│  └──────────────┘      └──────────────┘         │
│                                                  │
└─────────────────────────────────────────────────┘
         │
         ▼
Analysis results stored
```

### Step 3: Board Population
```
Analysis results
         │
         ▼
┌─────────────────────────────────────────────────┐
│           BOARD ELEMENT GENERATOR                │
│                                                  │
│  Entities found:                                 │
│  • "Dr. Smith" → Person card (Duty zone)        │
│  • "Jane Doe" → Person card (Duty zone)         │
│                                                  │
│  Timeline events:                                │
│  • "3/15 8pm admitted" → Timeline node          │
│  • "3/16 6am unresponsive" → Timeline node      │
│                                                  │
│  Contradictions:                                 │
│  • Statement A vs B → Contradiction card        │
│    (auto-connect with red string)               │
│                                                  │
│  Evidence:                                       │
│  • Key quotes → Evidence cards                  │
│  • Flagged sections → Evidence cards w/ flags   │
│                                                  │
└─────────────────────────────────────────────────┘
         │
         ▼
Board updated, version incremented
```

---

## REAL-TIME MODEL UPDATES

When AI runs (on new docs or re-analysis):

```
┌─────────────────────────────────────────────────┐
│              MODEL RUN STARTED                   │
│                                                  │
│  Analyzing 47 new documents...                  │
│  ████████████░░░░░░░░ 60%                       │
│                                                  │
│  LIVE UPDATES:                                   │
│  ✓ 3 new persons identified                     │
│  ✓ 12 timeline events extracted                 │
│  ⚡ 2 NEW CONTRADICTIONS FOUND                   │
│  ⚠️ 1 potential gap in causation chain          │
│                                                  │
└─────────────────────────────────────────────────┘
```

Board updates in real-time:
- New cards fade in with glow effect
- Contradiction cards pulse to draw attention
- Connections animate when established
- "What's New" badge shows changes since last view

---

## ELEMENT TYPES (Full Spec)

### 1. Evidence Card
```
┌─────────────────────────────────────┐
│ 📌 [pin color = zone]               │
├─────────────────────────────────────┤
│ EVIDENCE TYPE                       │
│ ─────────────────────               │
│ Content/quote                       │
│                                     │
│ Source: [doc] • Page: [#]          │
│ Date: [date]                        │
│                                     │
│ [AI FLAGS if any]                   │
│ ⚠️ Flag description                 │
├─────────────────────────────────────┤
│ 🤖 AI: 94% confidence               │
│ 📅 Added: v2.1 (2024-04-02)        │
└─────────────────────────────────────┘

Fields:
- id: UUID
- title: string
- content: text
- source_document: FK
- page_number: int
- date_mentioned: date
- zone: enum (duty, breach, causation, damages)
- ai_flags: array
- confidence: float
- version_added: FK
- position: {x, y, rotation}
```

### 2. Person Card
```
┌─────────────────────────────────────┐
│ 📌                                  │
├─────────────────────────────────────┤
│          👤                         │
│       [Name]                        │
│       [Role]                        │
│                                     │
│  Key facts:                         │
│  • Fact 1                           │
│  • Fact 2                           │
│                                     │
│  Mentions: 47                       │
│  Contradictions: 2                  │
├─────────────────────────────────────┤
│ 🔗 Click to see all references     │
└─────────────────────────────────────┘

Fields:
- id: UUID
- name: string
- role: enum (patient, defendant_physician, nurse, expert, witness, etc.)
- avatar: string (emoji or image)
- facts: array
- mention_count: int (computed)
- contradiction_count: int (computed)
- first_seen: version FK
```

### 3. Contradiction Card
```
┌─────────────────────────────────────┐
│ 📌 (always red)                     │
├─────────────────────────────────────┤
│ ⚡ CONTRADICTION                    │
│ ─────────────────────               │
│                                     │
│ Statement A:                        │
│ "[quote]"                           │
│ - Source, page                      │
│                                     │
│        ≠ VS ≠                       │
│                                     │
│ Statement B:                        │
│ "[quote]"                           │
│ - Source, page                      │
│                                     │
├─────────────────────────────────────┤
│ Confidence: 94%                     │
│ Status: 🔴 Unresolved               │
└─────────────────────────────────────┘

Fields:
- id: UUID
- statement_a: {text, source, page, date}
- statement_b: {text, source, page, date}
- confidence: float
- status: enum (unresolved, investigating, explained, key_evidence)
- notes: text
- related_persons: array of FK
```

### 4. Timeline Node
```
┌─────────────────────────────────────┐
│ 📌                                  │
├─────────────────────────────────────┤
│     📅 March 15, 2024               │
│         8:00 PM                     │
│                                     │
│   Patient admitted with             │
│   chest pain                        │
│                                     │
│   Source: Admission records, p.1    │
├─────────────────────────────────────┤
│ ⏱️ Gap to next: 7 HOURS ⚠️          │
└─────────────────────────────────────┘

Fields:
- id: UUID
- datetime: timestamp
- event_description: text
- source_document: FK
- page: int
- gap_to_next: interval (computed)
- gap_flagged: boolean
```

### 5. Sticky Note
```
┌─────────────────────────────────────┐
│ 📌                                  │
├─────────────────────────────────────┤
│                                     │
│   [Handwritten-style text]          │
│                                     │
│   Attorney notes, questions,        │
│   theories, reminders               │
│                                     │
├─────────────────────────────────────┤
│ By: [user] • [date]                │
└─────────────────────────────────────┘

Colors: Yellow, Pink, Blue, Green, Orange
Fields:
- id: UUID
- text: text
- color: enum
- created_by: user FK
- created_at: timestamp
```

### 6. Document Thumbnail
```
┌─────────────────────────────────────┐
│ 📌                                  │
├─────────────────────────────────────┤
│  ┌─────────────────────────────┐    │
│  │                             │    │
│  │    [Document preview]       │    │
│  │    or icon                  │    │
│  │                             │    │
│  └─────────────────────────────┘    │
│                                     │
│  filename.pdf                       │
│  "Description"                      │
│  47 pages • Uploaded 3/15           │
├─────────────────────────────────────┤
│ 📊 12 evidence cards generated     │
│ ⚡ 2 contradictions found          │
└─────────────────────────────────────┘

Fields:
- id: UUID
- document: FK to document storage
- thumbnail: image path
- description: text
- page_count: int
- evidence_count: int (computed)
- contradiction_count: int (computed)
```

### 7. Gap Indicator
```
┌─────────────────────────────────────┐
│ 📌 (yellow/warning)                 │
├─────────────────────────────────────┤
│ ⚠️ EVIDENCE GAP                     │
│ ─────────────────────               │
│                                     │
│ Missing evidence for:               │
│ [Element: Causation]                │
│                                     │
│ Need: Documentation linking         │
│ breach to patient injury            │
│                                     │
├─────────────────────────────────────┤
│ Status: 🔴 Not addressed            │
│ Priority: HIGH                      │
└─────────────────────────────────────┘

Fields:
- id: UUID
- gap_type: enum (duty, breach, causation, damages)
- description: text
- suggested_evidence: text
- status: enum
- priority: enum
```

---

## CONNECTION TYPES

| Type | Color | Meaning | Example |
|------|-------|---------|---------|
| Contradiction | 🔴 Red | These conflict | Statement A ↔ Statement B |
| Supports | 🔵 Blue | This proves that | Evidence → Element proved |
| Related | 🟡 Yellow | Same topic/person | Person ↔ Evidence about them |
| Timeline | 🟢 Green | Sequence | Event 1 → Event 2 |
| Causes | 🟣 Purple | Causation chain | Breach → Injury |
| Questions | ⚪ White dashed | Needs investigation | Gap → Potential source |

---

## ZONE BEHAVIOR

Each zone has:

1. **Auto-categorization** - AI places evidence in appropriate zone
2. **Completeness indicator** - "Duty: 85% documented"
3. **Gap detection** - Highlights missing elements
4. **Zone summary** - Collapsible summary of all zone evidence

```
┌─────────────────────────────────────────────────────────────────┐
│ ZONE: BREACH (Standard of Care)                    [Collapse ▼] │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Completeness: ████████░░ 80%                                   │
│                                                                 │
│  ✓ Standard of care established (expert report)                │
│  ✓ Deviation documented (4 evidence cards)                     │
│  ⚠️ Missing: Hospital protocol manual                          │
│                                                                 │
│  Evidence: 12 cards                                             │
│  Contradictions: 3                                              │
│  Key witnesses: Dr. Smith, Nurse Johnson                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## UI INTERACTIONS

### Drag & Drop
- Drag from palette OR from within board
- Drop anywhere (free positioning)
- Snap to grid (optional toggle)
- Smart guides (align with other elements)

### Connections
- Click pin → drag to another pin
- Line follows cursor with physics
- Color picker on connection
- Label connections (optional)
- AI-suggested connections (dashed until confirmed)

### Context Menu (Right-click)
```
┌─────────────────────────┐
│ ✏️ Edit                 │
│ 📋 Duplicate            │
│ 🔗 Connect to...        │
│ ─────────────────────── │
│ 🤖 AI: Find related     │
│ 🤖 AI: Check conflicts  │
│ 📄 View source document │
│ ─────────────────────── │
│ 📌 Change pin color     │
│ 🏷️ Add to zone          │
│ ─────────────────────── │
│ 📜 View history         │
│ ↩️ Restore previous     │
│ ─────────────────────── │
│ 🗑️ Delete               │
└─────────────────────────┘
```

### Search
```
┌─────────────────────────────────────────────────────────────────┐
│ 🔍 Search: "cardiac monitoring"                           [X]  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Found 7 results:                                               │
│                                                                 │
│  📋 Evidence: "No monitoring ordered" (Breach zone)            │
│  📋 Evidence: "Standard requires continuous..." (Breach)       │
│  👤 Person: Nurse Johnson (mentioned in 3 docs)                │
│  📅 Timeline: 3/15 11pm - Last check before gap                │
│  ⚡ Contradiction: Monitoring claims conflict                   │
│  📄 Document: Nursing_Notes.pdf (12 mentions)                  │
│  📄 Document: Hospital_Protocol.pdf (4 mentions)               │
│                                                                 │
│  [Highlight all on board] [Filter to results]                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Version History
```
┌─────────────────────────────────────────────────────────────────┐
│ 📜 VERSION HISTORY                                    [Close X] │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ● CURRENT - May 15, 2024                                      │
│  │  67 documents, 14 contradictions                            │
│  │                                                              │
│  ○ v3.0 - May 1, 2024 - "Deposition transcripts"              │
│  │  [View] [Compare to current] [Restore]                      │
│  │                                                              │
│  ○ v2.2 - Apr 5, 2024 - "Alternative theory branch" 🔀        │
│  │  [View] [Merge into current]                                │
│  │                                                              │
│  ○ v2.1 - Apr 2, 2024 - "Model run after subpoena"            │
│  │  +8 contradictions, +3 persons                              │
│  │  [View] [Compare] [Restore]                                 │
│  │                                                              │
│  ○ v2.0 - Apr 1, 2024 - "Major discovery"                     │
│  │  47 documents added                                         │
│  │                                                              │
│  ○ v1.2 - Mar 20, 2024 - "Expert report"                      │
│  │                                                              │
│  ○ v1.1 - Mar 16, 2024 - "First model run"                    │
│  │                                                              │
│  ○ v1.0 - Mar 15, 2024 - "Initial upload"                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## TECH STACK

### Frontend
```
React 18 + TypeScript
├── State: Zustand (lightweight, perfect for complex UI)
├── Canvas: React-Konva (2D canvas, great for infinite board)
├── Drag/Drop: Built into Konva
├── Routing: React Router
├── Styling: Tailwind CSS + custom cork board theme
└── Build: Vite
```

### Desktop Wrapper
```
Electron (or Tauri for lighter weight)
├── Cross-platform: Windows, Mac, Linux
├── Local file access
├── System tray
├── Auto-updates
└── Offline capability
```

### Backend
```
FastAPI (Python)
├── REST API for CRUD
├── WebSocket for real-time updates
├── Background tasks for AI processing
├── File handling
└── Authentication (future)
```

### Database
```
PostgreSQL
├── Case data
├── Board state (JSONB)
├── Version history
├── Audit logs
└── User management (future)

Qdrant
├── Vector embeddings
├── Similarity search
└── Document chunks
```

### AI Layer
```
Existing RAG Pipeline
├── PaddleOCR
├── Claude API / Ollama
├── Sentence Transformers
└── Custom analysis modules
```

---

## FILE STRUCTURE

```
investigation-board/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Board/
│   │   │   │   ├── CorkBoard.tsx
│   │   │   │   ├── Element.tsx
│   │   │   │   ├── Connection.tsx
│   │   │   │   ├── Zone.tsx
│   │   │   │   └── Minimap.tsx
│   │   │   ├── Elements/
│   │   │   │   ├── EvidenceCard.tsx
│   │   │   │   ├── PersonCard.tsx
│   │   │   │   ├── ContradictionCard.tsx
│   │   │   │   ├── TimelineNode.tsx
│   │   │   │   ├── StickyNote.tsx
│   │   │   │   └── DocumentThumb.tsx
│   │   │   ├── Toolbar/
│   │   │   ├── Search/
│   │   │   ├── VersionHistory/
│   │   │   └── Modals/
│   │   ├── stores/
│   │   │   ├── boardStore.ts
│   │   │   ├── caseStore.ts
│   │   │   └── uiStore.ts
│   │   ├── hooks/
│   │   ├── utils/
│   │   ├── types/
│   │   └── App.tsx
│   ├── public/
│   └── package.json
│
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── cases.py
│   │   │   ├── elements.py
│   │   │   ├── versions.py
│   │   │   ├── documents.py
│   │   │   └── analysis.py
│   │   ├── models/
│   │   ├── services/
│   │   │   ├── ai_engine.py
│   │   │   ├── version_control.py
│   │   │   └── board_generator.py
│   │   ├── db/
│   │   └── main.py
│   └── requirements.txt
│
├── electron/
│   ├── main.js
│   ├── preload.js
│   └── package.json
│
├── shared/
│   └── types/
│
└── docker-compose.yml
```

---

## NEXT STEPS

### Phase 1: Core Board (2 weeks)
- [ ] React + Konva canvas setup
- [ ] Element components (all types)
- [ ] Drag/drop/connect
- [ ] Basic save/load

### Phase 2: Backend Integration (2 weeks)
- [ ] FastAPI endpoints
- [ ] PostgreSQL schema
- [ ] Version control system
- [ ] Real-time sync

### Phase 3: AI Integration (2 weeks)
- [ ] Connect to RAG pipeline
- [ ] Auto-generate elements from documents
- [ ] Contradiction detection → cards
- [ ] Real-time analysis updates

### Phase 4: Polish (2 weeks)
- [ ] Electron wrapper
- [ ] Export (PDF, PNG)
- [ ] Search
- [ ] Keyboard shortcuts
- [ ] Cork board aesthetics perfected

---

## SUCCESS VISION

Attorney uploads 500 pages of case documents.

**5 minutes later:**

Cork board populated with:
- 12 key people identified and placed
- 47 timeline events mapped
- 8 contradictions flagged with red string
- Evidence cards organized by zone
- Gaps in causation highlighted

Attorney drags, connects, annotates. Saves.

**2 weeks later:**

47 more documents from discovery.

Model re-runs. Board updates.
- 3 new contradictions found
- Old "irrelevant" evidence now connected to new smoking gun
- Version saved, old version still accessible

**In court:**

Export → PDF of the board
"Your Honor, as you can see on this timeline..."

---

*This is the system. Cork board on top. Beast underneath.*

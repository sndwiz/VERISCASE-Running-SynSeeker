import { DbStorage } from "./dbStorage";
export const storage = new DbStorage();
